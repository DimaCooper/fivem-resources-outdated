

local cfg = {}

-- define transformers randomly placed on the map
cfg.hidden_transformers = {
  ["Конопля"] = {
    def = {
      title="Конопля", -- menu name
      color={57,42,92}, -- color
      max_units=30,
      units_per_minute=5,
      position={0,0,0},
      radius=5, height=1.8, -- area
      recipes = {
        ["Собрать шишки"] = { -- action name
          description="Душистое растение.", -- action description
          reagents={}, -- items taken per unit
          products={ -- items given per unit
            items = {
              ["edible|weed"] = 1
            }
          }
        }
      }
    },
    positions = {
      {1694.7025146484,-2658.1667480469,30.670087814331},
      {3153.0080566406,-76.105690002441,17.539470672607},
      {2130.1279296875,5578.2495117188,75.365615844727},
	  {-1424.7015380859,4406.1030273438,47.165168762207},
	  {-1881.1149902344,2155.7387695313,119.19639587402}
    }
  },
  ["LSD"] = {
    def = {
      title="Закладка", -- menu name
      color={57,42,92}, -- color
      max_units=30,
      units_per_minute=5,
      position={0,0,0},
      radius=5, height=1.8, -- area
      recipes = {
        ["Собрать закладку"] = { -- action name
          description="Несколько странных конвертов.", -- action description
          reagents={}, -- items taken per unit
          products={ -- items given per unit
            items = {
              ["edible|lsd"] = 1
            }
          }
        }
      }
    },
    positions = {
      {-1398.1964111328,-657.26214599609,28.673387527466},
      {148.74746704102,321.55627441406,112.13858795166},
      {1242.3946533203,-3323.1281738281,6.0287680625916},
	  {1549.1180419922,3517.0451660156,35.994686126709},
	  {-202.51040649414,6097.9321289063,31.495275497437}
    }
  },
  ["Кокаин"] = {
    def = {
      title="Закладка", -- menu name
      color={57,42,92}, -- color
      max_units=30,
      units_per_minute=5,
      position={0,0,0},
      radius=5, height=1.8, -- area
      recipes = {
        ["Забрать кокаин"] = { -- action name
          description="Стиральный порошок???", -- action description
          reagents={}, -- items taken per unit
          products={ -- items given per unit
            items = {
              ["edible|coca"] = 1
            }
          }
        }
      }
    },
    positions = {
      {-1101.9547119141,2724.4018554688,18.800407409668},
      {1644.8746337891,4839.6489257813,42.028968811035},
      {2490.9482421875,3445.0656738281,49.999496459961},
	  {998.16497802734,-1487.0064697266,31.412370681763},
	  {-2947.2270507813,450.39404296875,15.302410125732}
    }
  },
 --[[ ["Weed processing"] = {
    def = {
      title="Weed processing", -- menu name
      color={0,200,0}, -- color
      max_units=1000,
      units_per_minute=1000,
      position={0,0,0},
      radius=8, height=1.8, -- area
      recipes = {
        ["Process"] = { -- action name
          description="Process weed.", -- action description
          reagents={
            items = {
              ["weed"] = 2,
              ["demineralized_water"] = 1
            }
          }, -- items taken per unit
          products={ -- items given per unit
            items = {
              ["weed_processed"] = 1
            }
          }
        }
      },
      permissions = {
        "!aptitude.science.chemicals.>4"
      }
    },
    positions = {
      {1443.16345214844,6332.486328125,23.981897354126},
      {1581.90747070313,2910.68334960938,56.9333839416504},
      {2154.8515625,3386.4052734375,45.5702743530273}
    }
  },]]
--[[  ["Weed resale"] = {
    def = {
      title="Weed resale", -- menu name
      color={0,200,0}, -- color
      max_units=1000,
      units_per_minute=1000,
      position={0,0,0}, -- pos
      radius=5, height=1.8, -- area
      recipes = {
        ["Sell"] = { -- action name
          description="Sell processed weed.", -- action description
          reagents={
            items = {
              ["weed_processed"] = 10
            }
          }, -- items taken per unit
          products={ -- items given per unit
            items = {
              ["dirty_money"] = 5000
            }
          }
        }
      }
    },
    positions = {
      {-410.352722167969,447.736328125,112.580322265625},
      {-1907.70776367188,292.63720703125,88.6077499389648},
      {-970.378356933594,-1121.73522949219,2.17184591293335},
      {340.481842041016,-1856.76635742188,27.3206825256348},
      {-585.191833496094,-1606.83642578125,27.010814666748},
      {238.181610107422,-2021.85290527344,18.3191604614258}
    }
  }]]
}

-- time in minutes before hidden transformers are relocated (min is 5 minutes)
cfg.hidden_transformer_duration = 1*1*60 -- 5 days

-- configure the information reseller (can sell hidden transformers positions)
cfg.informer = {
  infos = {
    ["Конопля"] = 30000 , 
	["LSD"] = 30000 ,
	["Кокаин"] = 30000
  },
  positions = {
    {273.05599975586,-740.47283935547,34.639865875244},
    {-18.439241409302,-1220.5180664063,29.432819366455},
	{1135.2502441406,-1402.6146240234,34.594562530518},
	{713.83935546875,-717.62414550781,26.112325668335},
	{1025.2130126953,-121.75198364258,74.189353942871},
  {-54.094306945801,-1442.0126953125,32.07642364502},
	{40.31058883667,-1845.6574707031,23.670875549316},
	{234.58801269531,-2727.1228027344,6.0001978874207},
	{1045.0906982422,-2509.8154296875,28.459651947021},
	{979.85223388672,-1981.9855957031,30.669504165649},
  },
  interval = 30, -- interval in minutes for the reseller respawn
  duration = 30, -- duration in minutes of the spawned reseller
  map_entity = {"PoI", {marker_id = 1}} -- {ent,cfg} will fill cfg.title, cfg.pos
}

return cfg
