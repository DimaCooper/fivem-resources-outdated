
local cfg = {}

cfg.remove_interval = 100 -- number of milliseconds between two remove check

-- Ped model blacklist, names (string) or hashes (number)
cfg.ped_models = {
  -- cops
  "s_m_y_cop_01",
  "s_f_y_cop_01",
  "s_f_y_sheriff_01",
  "s_m_y_sheriff_01",
  "s_m_y_hwaycop_01",
  "s_m_y_swat_01",
  "s_m_m_snowcop_01",
  "s_m_m_paramedic_01",
}

return cfg
