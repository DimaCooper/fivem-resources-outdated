-- this file is used to define additional additional static map entities
-- blips list: https://wiki.gtanet.work/index.php?title=Blips

local cfg = {}

-- list of entities
-- {ent, cfg}
cfg.entities = {
  {"PoI", {blip_id = 311, blip_color = 17, title = "Спортзал", pos = {-1202.96252441406,-1566.14086914063,4.61040639877319}}},
  {"PoI", {blip_id = 61, blip_color = 65, title = "Больница", pos = {290.66766357422,-1436.9829101563,29.542446136475}}},
  {"PoI", {blip_id = 61, blip_color = 49, title = "Больница", pos = {364.37600708008,-590.09399414062,28.157587051392}}},
  {"PoI", {blip_id = 61, blip_color = 49, title = "Больница", pos = {1815.4322509766,3687.2609863282,33.694690704346}}},
  {"PoI", {blip_id = 60, blip_color = 29, title = "ПД", pos = {425.04983520508,-979.98223876954,30.710832595826}}},
  {"PoI", {blip_id = 60, blip_color = 29, title = "ШД Сенди", pos = {1857.1260986328,3680.4279785156,33.810180664062}}},
  {"PoI", {blip_id = 60, blip_color = 29, title = "ШД Палето", pos = {-441.49325561524,6026.3759765625,30.810354232788}}},
  {"PoI", {blip_id = 365, blip_color = 13, title = "Лесоповал", pos = {-489.47,5575.41,71.11}}},
  {"PoI", {blip_id = 365, blip_color = 13, title = "Лесоповал", pos = {-352.68,5946.57,44.39}}},
  {"PoI", {blip_id = 365, blip_color = 13, title = "Лесоповал", pos = {-572.08,5603.60,43.18}}},
  {"PoI", {blip_id = 365, blip_color = 13, title = "Лесоповал", pos = {-608.98,5515.54,50.02}}},
  {"PoI", {blip_id = 365, blip_color = 13, title = "Лесоповал", pos = {-676.74,5482.24,49.42}}},
    {"PoI", {blip_id = 365, blip_color = 13, title = "Лесоповал vip", pos = {-819.32537841796,5409.8295898438,34.304954528808}}},
  {"PoI", {blip_id = 365, blip_color = 13, title = "Лесоповал vip", pos = {-796.92803955078,5436.0698242188,34.891242980958}}},
  {"PoI", {blip_id = 365, blip_color = 13, title = "Пилорама", pos = {-513.56,5257.23,80.61}}},
  {"PoI", {blip_id = 365, blip_color = 13, title = "Склад древесины", pos = {58.43,6467.78,31.42}}},
  {"PoI", {blip_id = 365, blip_color = 12, title = "Прием драг.металлов", pos = {-1212.04,-336.17,37.79}}},
  {"PoI", {blip_id = 365, blip_color = 11, title = "Карьер", pos = {2926.49,2802.59,41.78}}},
  {"PoI", {blip_id = 365, blip_color = 11, title = "Завод минералов", pos = {2891.65,4380.42,50.33}}},
  {"PoI", {blip_id = 365, blip_color = 11, title = "Завод удобрений", pos = {2705.41,2865.29,37.50}}},
  {"PoI", {blip_id = 365, blip_color = 11, title = "Склад удобрений", pos = {406.48,6461.24,28.80}}},
  {"PoI", {blip_id = 365, blip_color = 10, title = "Рыбное место", pos = {1282.52,4117.04,29.18}}},
  {"PoI", {blip_id = 365, blip_color = 10, title = "Рыбное место", pos = {4260.57,4760.21,0.0}}},
  {"PoI", {blip_id = 365, blip_color = 10, title = "Рыбзавод", pos = {1303.59,4321.35,38.18}}},
  {"PoI", {blip_id = 365, blip_color = 10, title = "Рыбзавод", pos = {-271.59,-2723.32,1.00}}},
  {"PoI", {blip_id = 365, blip_color = 9, title = "Завод семян", pos = {2902.71,4415.30,48.82}}},
  {"PoI", {blip_id = 365, blip_color = 9, title = "Источник воды", pos = {2049.42,3953.46,31.00}}},
  {"PoI", {blip_id = 365, blip_color = 9, title = "Поле", pos = {270.04,6651.87,29.82}}},
  {"PoI", {blip_id = 365, blip_color = 9, title = "Мясокомбинат", pos = {-65.49,6240.96,31.08}}},
  {"PoI", {blip_id = 365, blip_color = 8, title = "Нефтяная вышка", pos = {585.44,2935.80,40.96}}},
  {"PoI", {blip_id = 365, blip_color = 8, title = "Нефтяная вышка", pos = {234.60,-2209.40,7.88}}},
  {"PoI", {blip_id = 365, blip_color = 8, title = "Нефтяная вышка", pos = {1726.94,-1669.44,112.56}}},
  {"PoI", {blip_id = 365, blip_color = 8, title = "Нефтяная вышка", pos = {1532.51,-2071.15,77.25}}},
  {"PoI", {blip_id = 365, blip_color = 8, title = "Нефтяная вышка", pos = {1427.53,-2304.35,66.99}}},
    {"PoI", {blip_id = 365, blip_color = 8, title = "Нефтяная вышка vip", pos = {1025.6014,3600.5732,33.2422}}},
  {"PoI", {blip_id = 365, blip_color = 8, title = "Нефтяная вышка vip", pos = {1120.4757,3603.8537,32.9969}}},
  {"PoI", {blip_id = 365, blip_color = 8, title = "Нефтепереработка", pos = {509.19,-2269.78,5.96}}},
   {"PoI", {blip_id = 365, blip_color = 8, title = "Склад нефтепродуктов", pos = {2677.73,1558.88,24.50}}},
   {"PoI", {blip_id = 267, blip_color = 14, title = "Почтовое отделение", pos = {-422.71075439454,-2786.2272949218,6.0003824234008}}},
   {"PoI", {blip_id = 446, blip_color = 47, title = "Механики", pos = {490.53518676758,-1327.9981689454,28.733518600464}}},
   {"PoI", {blip_id = 446, blip_color = 47, title = "Механики", pos = {1176.219116211,2649.0969238282,37.274696350098}}},
   {"PoI", {blip_id = 36, blip_color = 24, title = "Канатная дорога", pos = {-768.29327392578,5583.083984375,33.015594482422}}},
   {"PoI", {blip_id = 93, blip_color = 48, title = "Бар Единорог", pos = {127.89412689208,-1285.3159179688,29.280626296998}}},
   {"PoI", {blip_id = 93, blip_color = 48, title = "Бар Текила", pos = {-560.24505615234,285.35144042968,82.176330566406}}},
   {"PoI", {blip_id = 93, blip_color = 48, title = "Бар Багама", pos = {-1380.3229980468,-628.81329345704,30.81955909729}}},
   {"PoI", {blip_id = 93, blip_color = 48, title = "Бар Жемчужина", pos = {-1833.4576416016,-1200.252319336,14.309076309204}}},
   {"PoI", {blip_id = 93, blip_color = 48, title = "Бар Кас", pos = {1323.8221435546,-2719.2875976562,2.3126528263092}}},
   {"PoI", {blip_id = 93, blip_color = 48, title = "Бар Койот", pos = {1985.003540039,3051.8774414062,47.215118408204}}},
   {"PoI", {blip_id = 93, blip_color = 48, title = "Бар Чилл", pos = {-357.56954956054,156.15740966796,87.107208251954}}},
   {"PoI", {blip_id = 419, blip_color = 4, title = "Губернатор", pos = {-62.71715927124,-795.29150390625,44.225143432618}}},

    --{"PoI", {blip_id = , blip_color = , title = "", pos = {}}},
	 
}

return cfg
