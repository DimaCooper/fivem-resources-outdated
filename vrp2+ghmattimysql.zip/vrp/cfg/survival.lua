

local cfg = {
  vital_display = false,
  vital_display_anchor = "minimap",
  water_per_minute = 0.004,
  food_per_minute = 0.003,
  overflow_damage_factor = 3,
  pvp = true,
  police = false
}

return cfg
