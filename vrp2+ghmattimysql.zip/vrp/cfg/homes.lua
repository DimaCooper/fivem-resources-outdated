
local cfg = {}

-- example of study transformer
local transformer_study = {
  title="Книги", -- menu name
  color={0,255,0}, -- color
  max_units=15,
  units_per_minute=1,
  position = {0,0,0}, -- doesn't matter as home component
  radius=1.1, height=1.5, -- area
  recipes = {
    ["Химия"] = { -- action name
      description="Изучать химию", -- action description
      reagents={}, -- items taken per unit
      products={
        aptitudes={
          ["science.chemicals"] = 1 -- "group.aptitude", give 1 exp per unit
        }
      }
    },
    ["Математика"] = { -- action name
      description="Изучать математику", -- action description
      reagents={}, -- items taken per unit
      products={
        aptitudes={
          ["science.mathematics"] = 1 -- "group.aptitude", give 1 exp per unit
        }
      }
    },
	["Биология"] = { -- action name
      description="Изучать биологию", -- action description
      reagents={}, -- items taken per unit
      products={
        aptitudes={
          ["science.biology"] = 1 -- "group.aptitude", give 1 exp per unit
        }
      }
    },
		["Механик"] = { -- action name
      description="Изучать технику", -- action description
      reagents={}, -- items taken per unit
      products={
        aptitudes={
          ["science.mechanic"] = 1 -- "group.aptitude", give 1 exp per unit
        }
      }
    },
	["Первая помощь"] = { -- action name
      description="Изучать первую помощь", -- action description
      reagents={}, -- items taken per unit
      products={
        aptitudes={
          ["science.medic"] = 1 -- "group.aptitude", give 1 exp per unit
        }
      }
    },
  }
}

-- example of radio stations
local radio_stations = {
  ["Radio 1"] = "http://stream.radioreklama.bg/radio1.ogg",
  ["RADIO 1 ROCK"] = "http://stream.radioreklama.bg:80/radio1rock.ogg",
  ["TechnoBase.FM"] = "http://mp3.stream.tb-group.fm:80/tt.ogg",
  ["Phate Radio"] = "http://phate.io/listen.ogg",
  ["R 247drumandbass.com"] = "http://stream.247drumandbass.com:8000/256k.ogg",
}

-- default flats positions from https://github.com/Nadochima/HomeGTAV/blob/master/List

-- define the home slots (each entry coordinate should be unique for ALL types)
-- each slots is a list of home components
--- {component,x,y,z} (optional _config)
--- the entry component is required
cfg.slot_types = {
  ["Eclipse_House_1"] = {
  {
      {"entry",-774.171,333.589,207.621},
      {"chest",-783.16363525391,330.98727416992,207.62951660156, _config = {weight=1000}},
      {"wardrobe",-795.118469238281,331.631256103516,201.42431640625},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -797.94372558594,341.71633911133,206.21838378906},
	   {"radio", -800.45275878906,326.40014648438,206.21838378906, _config = { stations = radio_stations}}
    }
	},
   ["Eclipse_House_2"] = {
  {
      {"entry",-773.84558105469,341.95455932617,196.68647766113},
      {"chest",-761.01940917969,319.4111328125,199.49110412598, _config = {weight=1000}},
      {"wardrobe",-763.11419677734,329.6982421875,199.48873901367},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -779.16833496094,324.46490478516,196.0859375},
	   {"radio", -800.45275878906,326.40014648438,206.21838378906, _config = { stations = radio_stations}}
    },
	},
  
  ["Eclipse_House_3"] = {
    {
      {"entry",-782.171,324.589,223.258},
      {"chest",-773.718078613281,325.144409179688,223.266357421875, _config = {weight=1000}},
      {"wardrobe",-760.885437011719,325.457153320313,217.061080932617},
      --{"gametable",-755.40185546875,318.263214111328,221.875823974609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -758.670104980469,315.048156738281,221.854904174805},
	  {"radio", -779.39703369141,319.14166259766,195.89340209961, _config = { stations = radio_stations}}
    }
	},
  ["Basic_Housing_1"] = {
  {
      {"entry",-603.47766113281,58.976711273193,98.200218200684},
      {"chest",-622.41076660156,54.866096496582,97.599502563477, _config = {weight=1000}},
      {"wardrobe",-594.66290283203,56.656440734863,96.999633789063},
      --{"gametable",-798.123046875,180.058746337891,72.8452529907227},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -609.00738525391,49.086273193359,97.400062561035},
	  {"radio", -601.84210205078,44.679416656494,97.400062561035, _config = { stations = radio_stations}}
    }
  },
  ["Basic_Housing_2"] = {
  {
      {"entry",-1452.4895019532,-540.37615966796,74.044326782226},
      {"chest",-1467.3134765625,-526.78283691406,73.443656921387, _config = {weight=1000}},
      {"wardrobe",-1463.1820068359,-549.58618164063,73.244178771973},
      --{"gametable",-798.123046875,180.058746337891,72.8452529907227},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -1463.8154296875,-541.5220336914,73.24420928955},
	  {"radio", -1463.9866943359,-541.14715576172,73.244186401367, _config = { stations = radio_stations}}
    }
  },
  ["Ranch_main"] = {
    {
      {"entry",1391.9423828125,1132.10913085938,114.433587646484},
      {"chest",1401.99426269531,1132.26867675781,114.333648681641, _config = {weight=500}},
      {"wardrobe",1397.39868164063,1163.96044921875,114.333587646484},
     -- {"gametable",1397.07739257813,1132.19274902344,114.333572387695},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, 1403.88098144531,1144.57775878906,114.333587646484}
    }
  },
  ["beach_app"] = {
    {
      {"entry",-1397.0375976563,-1008.4737548828,24.704580307007},
      {"chest",-1400.5489501953,-1010.1401367188,24.704555511475, _config = {weight=1000}},
      {"wardrobe",-1401.7979736328,-1014.4714355469,24.704582214355},
      --{"gametable",-798.123046875,180.058746337891,72.8452529907227},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -1403.1657714844,-1013.1846313477,24.064052581787},
	  {"radio", -1421.6682128906,-1001.1646728516,19.380445480347, _config = { stations = radio_stations}}
    }
  },
  ["michael"] = {
    {
      {"entry",-815.78173828125,178.653060913086,72.1531295776367},
      {"chest",-803.31463623046,185.48680114746,72.60294342041, _config = {weight=1000}},
      {"wardrobe",-811.6137084961,175.26013183594,76.745376586914},
     -- {"gametable",-798.123046875,180.058746337891,72.8452529907227},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -806.27770996094,171.36041259766,72.844055175782},

    }
  },
  ["franklin"] = {
    {
      {"entry",-14.2774753570557,-1440.33703613281,31.1015491485596},
      {"chest",-17.1449108123779,-1430.34619140625,31.1015338897705, _config = {weight=500}},
      {"wardrobe",-18.4449443817139,-1439.01623535156,31.1015453338623},
      {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -12.4790229797363,-1436.97229003906,31.1015453338623}
    }
  },
  ["franklin_winewood"] = {
    {
      {"entry",7.7537579536438,538.27252197266,176.0281677246},
      {"chest",-6.2132396697998,530.44805908204,175.03512573242, _config = {weight=500}},
      {"wardrobe",8.6570930480958,528.6474609375,170.6350402832},
      --{"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -1.2572077512742,535.98425292968,175.34225463868},
	  {"radio", 3.9626519680024,526.90399169922,174.62796020508, _config = { stations = radio_stations}}
    }
  },
  ["Down_town_1"] = {
    {
      {"entry",-467.72384643554,-708.5830078125,77.086975097656},
      {"chest",-467.44360351562,-700.47021484375,77.095191955566, _config = {weight=500}},
      {"wardrobe",-466.85235595704,-687.41033935546,70.890419006348},
    --  {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -457.0485534668,-692.56591796875,75.68433380127},
	  {"radio", -472.2149963379,-682.61853027344,75.684349060058, _config = { stations = radio_stations}}
    }
  },
  ["Down_town_2"] = {
    {
      {"entry",-262.7922668457,-713.27453613282,71.032722473144},
      {"chest",-268.64611816406,-710.99853515625,74.13069152832, _config = {weight=500}},
      {"wardrobe",-265.21194458008,-712.27862548828,74.131080627442},
     -- {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -274.05987548828,-709.73834228516,74.130294799804},
	  {"radio", -262.3937072754,-706.17395019532,69.073219299316, _config = { stations = radio_stations}}
    }
  },
  ["Down_town_3"] = {
    {
      {"entry",-31.357364654542,-595.11785888672,80.030883789062},
      {"chest",-32.500442504882,-583.23016357422,78.865524291992, _config = {weight=500}},
      {"wardrobe",-38.281532287598,-589.55395507812,78.83031463623},
     -- {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -21.951665878296,-587.9658203125,79.230766296386},
	  {"radio", -27.57230758667,-581.39294433594,79.230758666992, _config = { stations = radio_stations}}
    }
  },
  ["Down_town_4"] = {
    {
      {"entry",-18.476385116578,-591.52764892578,90.114799499512},
      {"chest",-26.163759231568,-588.44909667968,90.123168945312, _config = {weight=500}},
      {"wardrobe",-37.736045837402,-583.53234863282,83.918319702148},
     -- {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},  -29.847631454468,-575.74310302734,88.712272644042},
	  {"radio", -44.712818145752,-586.89135742188,88.712272644042, _config = { stations = radio_stations}}
    }
  },
  ["Down_town_5"] = {
    {
      {"entry",-922.9927368164,-378.4207458496,85.480476379394},
      {"chest",-915.67932128906,-375.12280273438,85.488822937012, _config = {weight=500}},
      {"wardrobe",-903.98168945312,-369.72247314454,79.283981323242},
     -- {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -903.8735961914,-380.6245727539,84.077919006348},
	  {"radio", -901.82135009766,-362.43768310546,84.077919006348, _config = { stations = radio_stations}}
    }
  },
  ["Down_town_6"] = {
    {
      {"entry",-922.91625976562,-378.70788574218,85.48048400879},
      {"chest",-915.62841796875,-374.96936035156,85.488746643066, _config = {weight=500}},
      {"wardrobe",-903.79223632812,-369.70321655274,79.283988952636},
     -- {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -904.05883789062,-380.80029296875,84.077919006348},
	  {"radio", -901.77661132812,-362.46353149414,84.077919006348, _config = { stations = radio_stations}}
    }
  },
  ["Mission_Row"] = {
    {
      {"entry",270.87063598632,-1111.3525390625,77.266807556152},
      {"chest",268.13327026368,-1105.7784423828,77.26683807373, _config = {weight=500}},
      {"wardrobe",271.0521850586,-1106.0041503906,77.266822814942},
     -- {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, 270.97274780274,-1109.5694580078,77.266807556152},
	  {"radio", 267.1862487793,-1111.5725097656,77.307327270508, _config = { stations = radio_stations}}
    }
  },
  ["VineWood_1"] = {
  {
      {"entry",-682.2958984375,592.43841552734,145.39302062988},
      {"chest",-680.21844482422,588.54681396484,137.76974487304, _config = {weight=1000}},
      {"wardrobe",-671.4740600586,587.30291748046,141.56985473632},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -682.3060913086,595.57440185546,137.76626586914},
	   {"radio", -671.7431640625,581.85632324218,144.9702758789, _config = { stations = radio_stations}}
    }
	},
	["VineWood_2"] = {
  {
      {"entry",-758.58709716796,618.93017578125,144.15391540528},
      {"chest",-762.67004394532,618.75415039062,136.53062438964, _config = {weight=1000}},
      {"wardrobe",-767.31860351562,610.94830322266,140.33070373536},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -755.69610595704,617.84893798828,136.5272064209},
	   {"radio", -772.45104980468,613.36901855468,143.73114013672, _config = { stations = radio_stations}}
    }
	},
	["VineWood_3"] = {
  {
      {"entry",-571.8623046875,661.90496826172,145.83982849122},
      {"chest",-568.50714111328,667.96606445312,138.23210144042, _config = {weight=1000}},
      {"wardrobe",-571.3236694336,649.82958984375,142.03224182128},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -574.17572021484,665.24243164062,138.232131958},
	   {"radio", -576.0640258789,646.99450683594,145.43252563476, _config = { stations = radio_stations}}
    }
	},
		["VineWood_4"] = {
  {
      {"entry",-859.88262939454,691.06414794922,152.86074829102},
      {"chest",-858.37927246094,698.06243896484,145.25297546386, _config = {weight=1000}},
      {"wardrobe",-855.32275390625,679.82623291016,149.05311584472},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -852.19689941406,678.89074707032,152.65270996094},
	   {"radio", -851.67150878906,674.40270996094,152.48039245606, _config = { stations = radio_stations}}
    }
	},
			["VineWood_5"] = {
  {
      {"entry",-174.27375793458,497.56399536132,137.66700744628},
      {"chest",-174.53489685058,492.95928955078,130.0436553955, _config = {weight=1000}},
      {"wardrobe",-167.49087524414,487.74771118164,133.84379577636},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, -164.53750610352,487.0255432129,137.44345092774},
	   {"radio", -167.4490814209,487.83554077148,133.84376525878, _config = { stations = radio_stations}}
    }
	},		
	["VineWood_6"] = {
  {
      {"entry",341.73538208008,437.73196411132,149.39405822754},
      {"chest",337.65029907226,436.65423583984,141.77075195312, _config = {weight=1000}},
      {"wardrobe",334.2377319336,428.29699707032,145.5708618164},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, 334.46774291992,425.18365478516,149.17071533204},
	   {"radio", 330.72790527344,423.00848388672,148.9917602539, _config = { stations = radio_stations}}
    }
	},	
	["VineWood_7"] = {
  {
      {"entry",373.46032714844,423.52224731446,145.907913208},
      {"chest",377.19375610352,429.33947753906,138.30012512208, _config = {weight=1000}},
      {"wardrobe",374.3814086914,411.68447875976,142.1002960205},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, 376.91418457032,409.6509399414,145.70001220704},
	   {"radio", 376.07067871094,405.21008300782,145.52751159668, _config = { stations = radio_stations}}
    }
	},
	["Motel_1"] = {
  {
      {"entry",330.06198120118,-223.83169555664,39.32995223999},
      {"chest",334.88955688476,-224.06050109864,39.345859527588, _config = {weight=1000}},
      {"wardrobe",333.4126586914,-218.77114868164,39.397705078125},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}}, 331.17449951172,-218.5961151123,39.391078948974},
	   {"radio",327.09765625,-218.27114868164,39.379070281982 , _config = { stations = radio_stations}}
    }
	},
	["Motel_2"] = {
  {
      {"entry",316.71737670898,-215.89514160156,39.328258514404},
      {"chest",321.63027954102,-216.16807556152,39.344036102294, _config = {weight=1000}},
      {"wardrobe",320.4049987793,-210.9545135498,39.396034240722},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},318.17431640625,-210.5474243164,39.391971588134},
	   {"radio",313.9771118164,-210.2281036377,39.379543304444 , _config = { stations = radio_stations}}
    }
	},
	["Motel_3"] = {
  {
      {"entry",326.8451538086,-205.9842224121,39.327869415284},
      {"chest",331.70028686524,-206.16743469238,39.344345092774, _config = {weight=1000}},
      {"wardrobe",330.22912597656,-201.11437988282,39.393630981446},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",323.89453125,-200.23138427734,39.37911605835 , _config = { stations = radio_stations}}
    }
	},
	["Motel_4"] = {
  {
      {"entry",334.50939941406,-228.67085266114,54.205619812012},
      {"chest",332.94369506836,-232.52801513672,54.205619812012, _config = {weight=1000}},
      {"wardrobe",331.32006835938,-234.0231628418,54.205619812012},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",331.47021484375,-228.699508667,54.205619812012 , _config = { stations = radio_stations}}
    }
	},
	["Motel_5"] = {
  {
      {"entry",347.9793395996,-200.30923461914,54.19868850708},
      {"chest",351.9951171875,-201.81552124024,54.198684692382, _config = {weight=1000}},
      {"wardrobe",353.32220458984,-203.25267028808,54.198684692382},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",348.08514404296,-203.1450805664,54.198684692382 , _config = { stations = radio_stations}}
    }
	},
	["Motel_6"] = {
  {
      {"entry",334.46588134766,-228.53717041016,58.002449035644},
      {"chest",332.65969848632,-232.31872558594,58.002445220948, _config = {weight=1000}},
      {"wardrobe",331.36340332032,-233.79161071778,58.002445220948},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",331.4596862793,-228.59759521484,58.002445220948, _config = { stations = radio_stations}}
    }
	},
	["Motel_7"] = {
  {
      {"entry",312.39776611328,-219.96789550782,54.201526641846},
      {"chest",310.93615722656,-223.81117248536,54.220191955566, _config = {weight=1000}},
      {"wardrobe",309.36563110352,-225.58885192872,54.22025680542},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",309.69439697266,-220.07447814942,54.201503753662, _config = { stations = radio_stations}}
    }
	},
	["Motel_8"] = {
  {
      {"entry",306.77520751954,-217.88568115234,54.189769744874},
      {"chest",305.23217773438,-221.80267333984,54.220237731934, _config = {weight=1000}},
      {"wardrobe",303.77645874024,-223.23080444336,54.220245361328},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",303.86227416992,-218.09539794922,54.189762115478, _config = { stations = radio_stations}}
    }
	},
	["Motel_9"] = {
  {
      {"entry",306.22137451172,-212.77738952636,54.213603973388},
      {"chest",302.32348632812,-211.4458618164,54.213603973388, _config = {weight=1000}},
      {"wardrobe",300.87344360352,-209.9204864502,54.213603973388},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",306.10986328125,-209.92990112304,54.213603973388, _config = { stations = radio_stations}}
    }
	},
	["Motel_10"] = {
  {
      {"entry",308.44049072266,-207.42240905762,54.21541595459},
      {"chest",304.31045532226,-206.04457092286,54.21541595459, _config = {weight=1000}},
      {"wardrobe",302.88305664062,-204.55937194824,54.215412139892},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",308.15603637696,-204.73320007324,54.21541595459, _config = { stations = radio_stations}}
    }
	},
	["Motel_11"] = {
  {
      {"entry",312.03515625,-197.61010742188,54.215911865234},
      {"chest",308.05209350586,-196.22004699708,54.215911865234, _config = {weight=1000}},
      {"wardrobe",306.69177246094,-194.62594604492,54.215911865234},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",312.0852355957,-194.62969970704,54.215911865234, _config = { stations = radio_stations}}
    }
	},	
	["Motel_12"] = {
  {
      {"entry",316.35488891602,-193.61233520508,54.197593688964},
      {"chest",317.7737121582,-189.51950073242,54.19758605957, _config = {weight=1000}},
      {"wardrobe",319.40042114258,-188.203125,54.19758605957},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",318.97900390625,-193.61190795898,54.197593688964, _config = { stations = radio_stations}}
    }
	},
		["Motel_13"] = {
  {
      {"entry",312.30850219726,-220.08367919922,58.010974884034},
      {"chest",310.9691772461,-224.1202697754,58.010974884034, _config = {weight=1000}},
      {"wardrobe",309.41076660156,-225.36940002442,58.010974884034},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",310.14651489258,-220.46485900878,58.010974884034, _config = { stations = radio_stations}}
    }
	},	
	["Motel_14"] = {
  {
      {"entry",306.80334472656,-217.85507202148,58.018466949462},
      {"chest",305.3989868164,-221.7794494629,58.018466949462, _config = {weight=1000}},
      {"wardrobe",303.7964477539,-223.29837036132,58.018466949462},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",304.20568847656,-218.03411865234,58.018466949462, _config = { stations = radio_stations}}
    }
	},
	["Motel_15"] = {
  {
      {"entry",306.3369140625,-212.77020263672,58.009998321534},
      {"chest",302.33758544922,-211.48037719726,58.009998321534, _config = {weight=1000}},
      {"wardrobe",301.01281738282,-209.88052368164,58.009998321534},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",306.0724182129,-209.92933654786,58.009998321534, _config = { stations = radio_stations}}
    }
	},
	["Motel_16"] = {
  {
      {"entry",308.3020324707,-207.49844360352,58.00548171997},
      {"chest",304.31484985352,-206.1752319336,58.00548171997, _config = {weight=1000}},
      {"wardrobe",302.81158447266,-204.6526184082,58.00548171997},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",308.0773010254,-204.95645141602,58.00548171997, _config = { stations = radio_stations}}
    }
	},
	["Motel_17"] = {
  {
      {"entry",312.07611083984,-197.6275177002,58.018867492676},
      {"chest",308.1357421875,-196.25929260254,58.018867492676, _config = {weight=1000}},
      {"wardrobe",306.84475708008,-194.61459350586,58.018867492676},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",311.92205810546,-195.1866607666,58.018867492676, _config = { stations = radio_stations}}
    }
	},
	["Motel_18"] = {
  {
      {"entry",316.39727783204,-193.4852142334,57.99016571045},
      {"chest",317.54531860352,-189.60453796386,57.99016571045, _config = {weight=1000}},
      {"wardrobe",319.12329101562,-188.32489013672,57.99016571045},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},328.16131591796,-200.46342468262,39.392818450928},
	   {"radio",318.94473266602,-193.40425109864,57.99016571045, _config = { stations = radio_stations}}
    }
	},
	["VineWood_Plaza_1"] = {
  {
      {"entry",176.35836791992,-81.201629638672,77.427774047852},
      {"chest",171.49449157714,-76.250442504882,76.827857971192, _config = {weight=1000}},
      {"wardrobe",171.95654296875,-69.836685180664,76.827766418458},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
      {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},168.02226257324,-77.499702453614,76.827827453614},
	   {"radio",176.38024902344,-71.831604003906,76.864608764648 , _config = { stations = radio_stations}}
    }
	},
	["beach_chip_1"] = {
  {
      {"entry",1247.1440429688,-2683.5930175782,2.8671703338624},
      {"chest",1248.8162841796,-2679.154296875,2.8672046661376, _config = {weight=500}},
      {"wardrobe",1251.9744873046,-2678.6228027344,2.867167711258},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},168.02226257324,-77.499702453614,76.827827453614},
	   {"radio",1239.28125,-2679.6088867188,2.8671674728394 , _config = { stations = radio_stations}}
    }
	},
	["beach_chip_2"] = {
  {
      {"entry",1382.4389648438,-2711.2954101562,3.919154882431},
      {"chest",1387.572265625,-2707.9562988282,3.9186005592346, _config = {weight=500}},
      {"wardrobe",1387.2490234375,-2705.2302246094,3.918603181839},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},168.02226257324,-77.499702453614,76.827827453614},
	   {"radio",1379.3979492188,-2703.4877929688,3.918586730957 , _config = { stations = radio_stations}}
    }
	},
	
	["beach_chip_tent"] = {
  {
      {"entry",1344.552368164,-2700.6086425782,2.5390474796296},
      {"chest",1348.3038330078,-2700.8984375,2.6303851604462, _config = {weight=500}},
      {"wardrobe",1346.4107666016,-2699.8500976562,2.6041340827942},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},168.02226257324,-77.499702453614,76.827827453614},
	 --  {"radio",1379.3979492188,-2703.4877929688,3.918586730957 , _config = { stations = radio_stations}}
    }
	},
	
	["bridge_chip_tent"] = {
  {
      {"entry",454.63134765625,-857.81884765625,27.670593261718},
      {"chest",453.78201293946,-855.64764404296,27.737657546998, _config = {weight=500}},
      {"wardrobe",452.54748535156,-853.86474609375,27.864219665528},
      --{"gametable",-800.763427734375,338.574951171875,206.239105224609},
     -- {"transformer", _config = {cfg = transformer_study, map_entity = {"PoI", {marker_id = 1}}},168.02226257324,-77.499702453614,76.827827453614},
	 --  {"radio",1379.3979492188,-2703.4877929688,3.918586730957 , _config = { stations = radio_stations}}
    }
	},
  ["Ballas"] = {
    {
      {"entry",121.27383422852,-1920.0834960938,21.370656967164},
      {"chest",121.84362792968,-1911.4619140625,21.365762710572, _config = {weight=500}},
      {"wardrobe",123.57834625244,-1913.3322753906,21.37943649292},
     -- {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      --{"itemtr", _config = itemtr_study, -904.05883789062,-380.80029296875,84.077919006348},
	  --{"radio", -901.77661132812,-362.46353149414,84.077919006348, _config = { stations = radio_stations}}
    }
  },
  ["travor"] = {
    {
      {"entry",1973.0703125,3816.3200683594,33.428733825684},
      {"chest",1977.971069336,3819.8234863282,33.450099945068, _config = {weight=500}},
      {"wardrobe", 1969.4880371094,3814.8813476562,33.428722381592},
     -- {"gametable",-10.9005508422852,-1440.69470214844,31.1015453338623},
      --{"itemtr", _config = itemtr_study, -904.05883789062,-380.80029296875,84.077919006348},
	  --{"radio", -901.77661132812,-362.46353149414,84.077919006348, _config = { stations = radio_stations}}
    }
  },
}

-- define home clusters
-- map of name => {.slot, .entry_point, .buy_price, .sell_price, .max, .map_entity}
--- map_entity: {ent,cfg} will fill cfg.title, cfg.pos
cfg.homes = {
  ["Beach Appartment"] = {
    slot = "beach_app",
    entry_point = {-1430.0045166016,-1007.7329101563,4.9703125953674},
    buy_price = 350000,
    sell_price = 280000,
    max = 1,
    map_entity = {"PoI", { marker_id = 1}}
  },
  ["Basic Housing 1"] = {
    slot = "Basic_Housing_1",
    entry_point = {-635.665,44.155,42.697},
    buy_price = 80000,
    sell_price = 60000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 69, marker_id = 1}}
  },
  ["Basic Housing 2"] = {
    slot = "Basic_Housing_2",
    entry_point = {-1446.769,-538.531,34.740},
    buy_price = 80000,
    sell_price = 60000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 69, marker_id = 1}}
  },
  
  ["Downtown 1"] = {
    slot = "Down_town_1",
    entry_point = {-467.20751953125,-678.8042602539,32.714065551758 },
    buy_price = 120000,
    sell_price = 80000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
  ["Downtown 2"] = {
    slot = "Down_town_2",
    entry_point = {-270.9938659668,-706.51538085938,38.276954650878},
    buy_price = 140000,
    sell_price = 100000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
  ["Downtown 3"] = {
    slot = "Down_town_3",
    entry_point = {-59.428318023682,-616.33819580078,37.356777191162},
    buy_price = 80000,
    sell_price = 60000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 69, marker_id = 1}}
  },
  ["Downtown 4"] = {
    slot = "Down_town_4",
    entry_point = {-47.278354644776,-584.6226196289,37.953063964844},
    buy_price = 140000,
    sell_price = 90000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
  ["Downtown 5"] = {
    slot = "Down_town_5",
    entry_point = {-936.80627441406,-379.70526123046,38.961318969726},
    buy_price = 180000,
    sell_price = 160000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
  ["Downtown 6"] = {
    slot = "Down_town_6",
    entry_point = {-902.37548828125,-378.29296875,38.96129989624},
    buy_price = 170000,
    sell_price = 150000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
  ["Mission Row"] = {
    slot = "Mission_Row",
    entry_point = {289.1696472168,-1095.1647949218,29.419660568238},
    buy_price = 20000,
    sell_price = 15000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 69, marker_id = 1}}
  },
  ["Ghetto"] = {
    slot = "Ballas",
    entry_point = { 118.14134979248,-1920.8905029296,21.323404312134},
    buy_price = 8000,
    sell_price = 3000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Eclipse House 1"] = {
    slot = "Eclipse_House_1",
    entry_point = {-772.74188232422,312.46725463867,85.698127746582},
    buy_price = 280000,
    sell_price = 230000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 68, marker_id = 1}}
  },
  ["Eclipse House 2"] = {
    slot = "Eclipse_House_2",
    entry_point = {-775.11077880859,312.50839233398,85.698127746582},
    buy_price = 270000,
    sell_price = 220000,
    max = 99,
   map_entity = {"PoI", {blip_id = 40, blip_color = 68, marker_id = 1}}
  },
  ["Eclipse House 3"] = {
    slot = "Eclipse_House_3",
    entry_point = {-777.34490966797,312.50717163086,85.698127746582},
    buy_price = 300000,
    sell_price = 250000,
    max = 99,
    map_entity = {"PoI", {blip_id = 40, blip_color = 68, marker_id = 1}}
  },
  ["Vinewood 1"] = {
    slot = "VineWood_1",
    entry_point = {-686.35577392578,596.62365722656,143.6420135498},
    buy_price = 140000,
    sell_price = 100000,
    max = 1,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
  ["Vinewood 2"] = {
    slot = "VineWood_2",
    entry_point = {-752.95642089844,620.55865478516,142.63279724122},
    buy_price = 140000,
    sell_price = 100000,
    max = 1,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
  ["Vinewood 3"] = {
    slot = "VineWood_3",
    entry_point = {-559.24420166016,664.29431152344,145.45643615722},
    buy_price = 140000,
    sell_price = 100000,
    max = 1,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
    ["Vinewood 4"] = {
    slot = "VineWood_4",
    entry_point = {-853.09704589844,695.77349853516,148.78678894042},
    buy_price = 140000,
    sell_price = 100000,
    max = 1,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
      ["Vinewood 5"] = {
    slot = "VineWood_5",
    entry_point = {-175.0181274414,502.41888427734,137.42016601562},
    buy_price = 140000,
    sell_price = 100000,
    max = 1,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
        ["Vinewood 6"] = {
    slot = "VineWood_6",
    entry_point = {346.8351135254,440.73358154296,147.70216369628},
    buy_price = 200000,
    sell_price = 150000,
    max = 1,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },     
  ["Vinewood 7"] = {
    slot = "VineWood_7",
    entry_point = {373.60733032226,427.89331054688,145.6842956543},
    buy_price = 200000,
    sell_price = 140000,
    max = 1,
    map_entity = {"PoI", {blip_id = 40, blip_color = 70, marker_id = 1}}
  },
 -- ["Rich Housing 2"] = {
   --[[ slot = "other_flat",
    entry_point = {-84.2591705322266,-822.232788085938,36.0280227661133},
    buy_price = 500000,
    sell_price = 300000,
    max = 25,
    blipid=40,
    blipcolor=5
  },]]
  ["Ranch Main"] = {
    slot = "ranch_main",
    entry_point = {1394.48278808594,1141.74035644531,114.606857299805},
    buy_price = 500000,
    sell_price = 300000,
    max = 10,
    map_entity = {"PoI", {blip_id = 40, blip_color = 68, marker_id = 1}}
  },
 
  
  ["Regular House 1"] = {
    slot = "michael",
    entry_point = {-817.214721679688,177.902770996094,72.2278060913086},
    buy_price = 700000,
    sell_price = 500000,
    max = 1,
    map_entity = {"PoI", { marker_id = 1}}
  },
  
  ["Regular House 2"] = {
    slot = "franklin",
    entry_point = {-14.1632394790649,-1442.03454589844,31.1011180877686},
    buy_price = 13000,
    sell_price = 5000,
    max = 30,
   map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Regular House 3"] = {
    slot = "franklin_winewood",
    entry_point = {8.7491970062256,540.1841430664,176.02702331542},
    buy_price = 290000,
    sell_price = 240000,
    max = 1,
    map_entity = {"PoI", {blip_id = 40, blip_color = 68, marker_id = 1}}
  },
  
  ["Regular House 4"] = {
    slot = "travor",
    entry_point = {1973.9990234375,3815.0498046875,33.424030303956},
    buy_price = 4000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Motel 1"] = {
    slot = "Motel_1",
    entry_point = {342.72644042968,-209.43942260742,54.221767425538},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Motel 2"] = {
    slot = "Motel_2",
    entry_point = {340.59942626954,-214.58619689942,54.221767425538},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Motel 3"] = {
    slot = "Motel_3",
    entry_point = {336.69290161132,-224.49577331542,54.222984313964},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
    ["Motel 4"] = {
    slot = "Motel_4",
    entry_point = {335.15252685546,-227.0700378418,54.222988128662},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
      ["Motel 5"] = {
    slot = "Motel_5",
    entry_point = {346.47326660156,-199.56712341308,54.222980499268},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
    ["Motel 6"] = {
    slot = "Motel_6",
    entry_point = {335.16180419922,-226.93978881836,58.017963409424},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Motel 7"] = {
    slot = "Motel_7",
    entry_point = {313.07678222656,-218.4373474121,54.221801757812},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
    ["Motel 8"] = {
    slot = "Motel_8",
    entry_point = {307.47665405274,-216.27073669434,54.223003387452},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Motel 9"] = {
    slot = "Motel_9",
    entry_point = {307.97814941406,-213.46495056152,54.223014831542},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
    ["Motel 10"] = {
    slot = "Motel_10",
    entry_point = {310.09628295898,-208.193069458,54.223022460938},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
      ["Motel 11"] = {
    slot = "Motel_11",
    entry_point = {313.67050170898,-198.30502319336,54.223007202148},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
    ["Motel 12"] = {
    slot = "Motel_12",
    entry_point = {315.76889038086,-194.92280578614,54.22636795044},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
 ["Motel 13"] = {
    slot = "Motel_13",
    entry_point = {312.97549438476,-218.55238342286,58.019351959228},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
   ["Motel 14"] = {
    slot = "Motel_14",
    entry_point = {307.37313842774,-216.28575134278,58.018672943116},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
     ["Motel 15"] = {
    slot = "Motel_15",
    entry_point = {307.8037109375,-213.44024658204,58.01802444458},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
       ["Motel 16"] = {
    slot = "Motel_16",
    entry_point = {309.98574829102,-208.23120117188,58.01798248291},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
         ["Motel 17"] = {
    slot = "Motel_17",
    entry_point = {313.7228088379,-198.251953125,58.017990112304},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
           ["Motel 18"] = {
    slot = "Motel_18",
    entry_point = {315.61953735352,-195.14825439454,58.018016815186},
    buy_price = 5000,
    sell_price = 1000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["VineWood Plaza 1"] = {
    slot = "VineWood_Plaza_1",
    entry_point = {176.0669708252,-82.901969909668,76.79214477539},
    buy_price = 35000,
    sell_price = 25000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 69, marker_id = 1}}
  },
  ["Beach House 1"] = {
    slot = "beach_chip_1",
    entry_point = {1246.2927246094,-2685.5187988282,2.6400871276856},
    buy_price = 6000,
    sell_price = 4000,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Beach House 2"] = {
    slot = "beach_chip_2",
    entry_point = {1382.4106445312,-2714.3884277344,3.5253920555114},
    buy_price = 7500,
    sell_price = 5700,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Beach tent"] = {
    slot = "beach_chip_tent",
    entry_point = {1346.0740966796,-2705.5654296875,2.503557920456},
    buy_price = 200,
    sell_price = 100,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  ["Bridge tent"] = {
    slot = "bridge_chip_tent",
    entry_point = {458.7308959961,-858.1439819336,27.359870910644},
    buy_price = 300,
    sell_price = 100,
    max = 30,
    map_entity = {"PoI", {blip_id = 40, blip_color = 4, marker_id = 1}}
  },
  
}

-- {ent,cfg} will fill cfg.pos
cfg.entry_map_entity = {"PoI", {marker_id = 1}}

return cfg