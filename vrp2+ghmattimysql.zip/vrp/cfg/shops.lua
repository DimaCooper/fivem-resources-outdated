local cfg = {}

-- define shop types
-- _config: {.map_entity, .permissions}
--- map_entity: {ent,cfg} will fill cfg.title, cfg.pos
--- permissions: (optional)

cfg.shop_types = {
  ["Продукты"] = {
    _config = {map_entity = {"PoI", {blip_id = 52, blip_color = 2, marker_id = 1}}},

    -- list itemid => price
    -- Drinks
    
  ["edible|milk"] = 2,
    ["edible|water"] = 2,
    ["edible|coffee"] = 4,
    ["edible|tea"] = 4,
    ["edible|icetea"] = 8,
    ["edible|orangejuice"] = 8,
    ["edible|gocagola"] = 9,
    ["edible|redgull"] = 12,
    ["edible|lemonlimonad"] = 11,
    ["edible|vodka"] = 30,
	["edible|beer"] = 25,
	
	["edible|minwater"] = 4,
	["edible|wine"] = 50,


    --Food
    ["edible|bread"] = 2,
    ["edible|donut"] = 2,
    ["edible|tacos"] = 8,
    ["edible|sandwichchease"] = 15,
	["edible|sandwichbecon"] = 17,
    ["edible|kebab"] = 20,
    ["edible|pdonut"] = 25,
	["edible|cheaps"] = 7,
--["edible|spagetti"] = 15,
--["edible|spagettibecon"] = 16,
--["edible|chikensoup"] = 40,
--["edible|borsh"] = 80,
["edible|gamburger"] = 15,
--["edible|naggets"] = 13,
--["edible|pizzaananas"] = 45,
--["edible|pizza4"] = 60,
["edible|cheasesnek"] = 40,
["edible|yogurt"] = 15,
--["edible|chezar"] = 60,
--["edible|grecheskii"] = 65,
["edible|fri"] = 10,
  },
  ["Торговый центр"] = {
    _config = {map_entity = {"PoI", {blip_id = 52, blip_color = 38, marker_id = 1}}},

    -- list itemid => price
    -- Drinks
    
  ["phoneitem"] = 100,
  ["scone"] = 150,
  ["worklight"] = 250,
  ["gazebo"] = 200,
 -- ["bbox"] = 100,
--["sign3"] = 500,
["burger"] = 2000,
["coffin"] = 500,
["dummy"] = 100,
["fireex"] = 100,
["target"] = 200,
["box"] = 50,
["radio"] = 100,


   
  },
  
   ["Для дома и сада"] = {
    _config = {map_entity = {"PoI", {blip_id = 285, blip_color = 11, marker_id = 1}}},

    -- list itemid => price
    -- Drinks
    
  ["chair"] = 80,
  ["bfire"] = 50,
  ["gazebo"] = 400,
["barrier2"] = 600,
["barrier21"] = 3000,
["barrier3"] = 300,
["barrier5"] = 300,
["bbq1"] = 200,
["bbq2"] = 400,
["lilo1"] = 20,
["lilo2"] = 20,
["ring"] = 30,
["parasol1"] = 300,
["ball1"] = 50,
["ball2"] = 50,
["ball3"] = 50,
["bong"] = 50,
["pin"] = 50,
["vedro"] = 50,
["bench"] = 100,
["chair2"] = 100,
["flamingo"] = 200,
["flat"] = 620,
["gas"] = 2000,
["gnome1"] = 100,
["gnome2"] = 100,
["gnome3"] = 100,
["patio"] = 250,
["parasol2"] = 400,
["stove"] = 50,
["tent"] = 150,
["ball4"] = 50,
["telescope"] = 200,
["corpse"] = 100,
["worklight3"] = 300,
["plant1"] = 100,
["plant2"] = 100,
["plant3"] = 100,
["plant4"] = 100,
["plant5"] = 100,
["plant6"] = 100,
["plant7"] = 100,
["plant8"] = 100,
["plant9"] = 100,
["plant10"] = 100, 
["plant11"] = 100,
["plant12"] = 100,
["plant13"] = 100,
   
  },
  
  ["Телефон"] = {
    _config = {map_entity = {"PoI", {blip_id = 52, blip_color = 38, marker_id = 1}}},

    -- list itemid => price
    -- Drinks
    
  ["phoneitem"] = 100,
  
   
  },
  
  ["Напитки"] ={
  _config = {map_entity = {"PoI", {}}},
  ["edible|water"] = 2,
  ["edible|icetea"] = 7,
  ["edible|gocagola"] = 10,
  ["edible|redgull"] = 13,
  ["edible|lemonlimonad"] = 13,
  ["edible|minwater"] = 5,
  },
  ["Кофе"] = {
  _config = {map_entity = {"PoI", {}}},
  ["edible|coffee"] = 5,
  ["edible|americano"] = 8,
  ["edible|espresso"] = 9,
  ["edible|rastvorcoffe"] = 2,
  },
  ["Бойлер"] = {
  _config = {map_entity = {"PoI", {}}},
  ["edible|water"] = 1, 
  },
  ["Снеки"] = {
  _config = {map_entity = {"PoI", {}}},
  ["edible|donut"] = 4,
  ["edible|cheaps"] = 8,
  ["edible|icetea"] = 9,
  ["edible|sandwichchease"] = 20,
  ["edible|sandwichbecon"] = 20,
  ["edible|yogurt"] = 16,
  
  },
  ["Мороженое"] = {
 _config = {map_entity = {"PoI", { }}},
  ["edible|plombir"] = 7,
  ["edible|plombirbrown"] = 8,
  ["edible|plombiryellow"] = 8,
  ["edible|plombirgreen"] = 10,
  ["edible|plombirextra"] = 15,
  },
  ["Фрукты и овощи"] = {
  _config = {map_entity = {"PoI", {}}},
  ["edible|orange"] = 2,
["edible|apple"] = 2,
["edible|banana"] = 2,
["edible|pears"] = 2,
["edible|grape"] = 3,
["edible|pineapple"] = 7,
["edible|potato"] = 2,
["edible|carrot"] = 2,
["edible|kale"] = 5,
["edible|mashrooms"] = 6,
["edible|barrys"] = 8
  },
  ["Бар"] = {
  _config = {map_entity = {"PoI", { marker_id = 1}}},
  ["edible|pinakolada"] = 12,
["edible|daikiri"] = 14,
["edible|oazis"] = 12,
["edible|b52"] = 15,
["edible|mohito"] = 10, 
["edible|otvertka"] = 15, 
["edible|strawliker"] = 20,
["edible|djin"] = 10,
["edible|djintonik"] = 15, 
["edible|vodka"] = 35, 
["edible|strawkiss"] = 22
  },
  ["Бизнес Центр"] = {
  _config = {map_entity = {"PoI", {blip_id = 108, blip_color = 2, marker_id = 1}}},
  ["Noogle"] = 500000,
  ["MacroSoft"] = 400000,
  ["YouCube"] = 325000,
  ["LanFlix"] = 250000,
  ["PonrBuh"] = 175000,
  ["Odnokyrsniki"] = 125000,
  ["Somy"] = 75000,
  ["FiveN"] = 50000,
  ["AmazingAndCorp"] = 5000,

  },
  ["Медикоменты"] = {
  _config = {map_entity = {"PoI", {  marker_id = 1}}, permissions = {"emergency.shop"}},
   -- _config = {permissions={"emergency.shop"}, map_entity = {"PoI", {marker_id = 1}}},
    ["medkit"] = 1,
    ["edible|pills"] = 1,
	["spirt"] = 1,
	["licenseinv"] = 1,
	["licenseweed"] = 1,
	["licensemed"] = 1,
	["radio"] = 1,
  },
  ["Таблетки"] = {
 _config = {map_entity = {"PoI", { blip_id = 51, blip_color = 75, marker_id = 1}}},
   -- _config = {permissions={"emergency.shop"}, map_entity = {"PoI", {marker_id = 1}}},
    
    ["edible|pills"] = 200,
    ["medkit"] = 400,
	
  },
  ["Служебный склад"] = {
  _config = {map_entity = {"PoI", { marker_id = 1}}, permissions = {"police.pc"}},
  --_config = {permissions={"police.pc"}, map_entity = {"PoI", {marker_id = 1}}},
  ["bulletproof_vest"] = 1,
  ["licensegun"] = 1,
  ["license"] = 1,
  ["licensecom"] = 1,
  ["licensepilot"] = 1,
  ["radio"] = 1,
  ["sign1"] = 1,
  ["sign2"] = 1,
  ["sign3"] = 1,
  ["barrier4"] = 1,
    ["barrier"] = 1,
  
  },
  ["surgery"] = {
  _config = {map_entity = {"PoI", { marker_id = 1}},permissions = {"emergency.shop"}},
  --_config = {permissions = {"emergency.service"}, map_entity = {"PoI", {marker_id = 1}}},
  ["surgkit"] = 1
  },
  ["Инструменты"] = {
  _config = {map_entity = {"PoI", { marker_id = 1}}, permissions = {"vehicle.repair"}},
    --_config = {permissions = {"vehicle.repair"}, map_entity = {"PoI", {marker_id = 1}}},
    ["repairkit"] = 10,
	["radio"] = 1,
  },
  ["Марихуана"] = {
 _config = {map_entity = {"PoI", {}}},
  ["edible|Legalweed"] = 100,
  },
  ---
  
  
 
  -- weapons
  -- for the native name, see https://wiki.fivem.net/wiki/Weapons (not all of them will work, look at client/player_state.lua for the real weapon list)
  ["sandyshores1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
    
	
	["wbody|WEAPON_BOTTLE"] = 50,
    ["wbody|WEAPON_BAT"] = 100,
    ["wbody|WEAPON_KNUCKLE"] = 300,
    ["wbody|WEAPON_KNIFE"] = 400,
	["wbody|WEAPON_PETROLCAN"] = 4700,
	["wammo|WEAPON_PETROLCAN"] = 1,
	["wbody|WEAPON_HAMMER"] = 300,
    ["wbody|WEAPON_HATCHET"] = 300,
	["wbody|WEAPON_MARKSMANPISTOL"] = 5000,
  },

  ["vinewood1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
    ["wbody|WEAPON_MARKSMANPISTOL"] = 5000,
  
    ["wbody|WEAPON_VINTAGEPISTOL"] = 10500,
    ["wbody|WEAPON_PISTOL"] = 4500,
    
    ["wbody|WEAPON_HEAVYREVOLVER"] = 15000,
   ["wammo|WEAPON_MARKSMANPISTOL"] = 5,
  
    ["wammo|WEAPON_VINTAGEPISTOL"] = 5,
    ["wammo|WEAPON_PISTOL"] = 5,
    
    ["wammo|WEAPON_HEAVYREVOLVER"] = 5,
    

    ["wbody|WEAPON_DAGGER"] = 200,
    ["wbody|WEAPON_HAMMER"] = 250,
    ["wbody|WEAPON_HATCHET"] = 300,
	["wbody|WEAPON_PETROLCAN"] = 5500,
	["wammo|WEAPON_PETROLCAN"] = 1,
  },

  ["vespuccibeach1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
    
    ["wbody|WEAPON_CROWBAR"] = 200,
    ["wbody|WEAPON_GOLFCLUB"] = 300,
    ["wbody|WEAPON_SWITCHBLADE"] = 400,
    ["wbody|WEAPON_MACHETE"] = 500,
  },

  ["paletobay1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
	
	["wbody|WEAPON_MARKSMANPISTOL"] = 4500,
	["wbody|WEAPON_HATCHET"] = 1500,
  ["wbody|WEAPON_DAGGER"] = 600,
    ["wbody|WEAPON_FLARE"] = 200,
	["wbody|WEAPON_PETROLCAN"] = 4000,
	["wammo|WEAPON_PETROLCAN"] = 1,
    
    ["wammo|WEAPON_MARKSMANPISTOL"] = 5,
  
    ["wammo|WEAPON_FLARE"] = 20
  },

  ["tataviammountains1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 2, marker_id = 1}}},
    ["wbody|WEAPON_GUSENBERG"] = 200000,
    ["wbody|WEAPON_MG"] = 250000,
    ["wbody|WEAPON_COMBATMG"] = 500000,
    ["wammo|WEAPON_GUSENBERG"] = 50,
    ["wammo|WEAPON_MG"] = 50,
    ["wammo|WEAPON_COMBATMG"] = 70
  },

  ["chumash1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
	["wbody|WEAPON_MARKSMANPISTOL"] = 5500,
	["wbody|WEAPON_MACHETE"] = 900,
	["wbody|WEAPON_KNIFE"] = 400,
	["wbody|WEAPON_PETROLCAN"] = 5000,
	["wammo|WEAPON_PETROLCAN"] = 1,
    ["wammo|WEAPON_MARKSMANPISTOL"] = 5,
    
  },

  ["eastlossantos1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
	
    ["wbody|WEAPON_FLARE"] = 300,
	["wbody|WEAPON_MACHETE"] = 600,
	["wbody|WEAPON_PISTOL"] = 5500,
	["wammo|WEAPON_PISTOL"] = 5,
	
    ["wammo|WEAPON_FLARE"] = 20
  },

  ["midlossantosrange"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
	["wbody|WEAPON_FIREEXTINGUISHER"] = 100,
    ["wbody|WEAPON_FIREWORK"] = 20000,
	["wbody|WEAPON_MACHETE"] = 800,
	["wbody|WEAPON_PETROLCAN"] = 5000,
	["wammo|WEAPON_PETROLCAN"] = 1,
	["wammo|WEAPON_FIREEXTINGUISHER"] = 1,
    ["wammo|WEAPON_FIREWORK"] = 200,
	
  },

  ["greatchaparral1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
	["wbody|WEAPON_FIREEXTINGUISHER"] = {"Fire Extinguisher",100,0,""},
    ["wbody|WEAPON_FIREWORK"] = 20000,
   
    ["wbody|WEAPON_FLASHLIGHT"] = 300,
    ["wbody|WEAPON_STUNGUN"] = 1000,
    ["wbody|WEAPON_MUSKET"] = 20000,
    ["wbody|WEAPON_FLAREGUN"] = 5000,
	
	["wammo|WEAPON_FIREEXTINGUISHER"] = 1,
    ["wammo|WEAPON_FIREWORK"] = 200,
   
    ["wammo|WEAPON_MUSKET"] = 20,
    ["wammo|WEAPON_FLAREGUN"] = 20,
	
   
  },

  ["cypressflatsrange1"] = {
    _config = {map_entity = {"PoI", {blip_id = 154, blip_color = 1, marker_id = 1}}},
	
	["wbody|WEAPON_MARKSMANPISTOL"] = 5500,
    ["wbody|WEAPON_PETROLCAN"] = 5500,
	["wbody|WEAPON_KNIFE"] = 400,
	
["wammo|WEAPON_PETROLCAN"] = 1,
    ["wammo|WEAPON_MARKSMANPISTOL"] = 5,

  },
  
  ["illegal"] = {
    _config = {map_entity = {"PoI", { marker_id = 1}}, permissions = {"guns.guns"}},
	
   -- ["wbody|WEAPON_HEAVYPISTOL"] = 2000, не работает не сохраняется 
	
	-- ["wammo|WEAPON_HEAVYPISTOL"] = 3,
	["wbody|WEAPON_PISTOL"] = 1500,
	["wammo|WEAPON_PISTOL"] = 3,
	
	["wbody|WEAPON_SMG"] = 5000,
	["wammo|WEAPON_SMG"] = 5,
	["wbody|WEAPON_MICROSMG"] = 4500,
	["wammo|WEAPON_MICROSMG"] = 5, 
	["wbody|WEAPON_PDW"] = 7500,
	["wammo|WEAPON_PDW"] = 5, 
	["wbody|WEAPON_PISTOL50"] = 3500,
	["wammo|WEAPON_PISTOL50"] = 3, 
	
	["wbody|WEAPON_DAGGER"] = 100,
   
   
  },
  
  ["police_weapons"] = {
    _config = {map_entity = {"PoI", { marker_id = 1}}, permissions = {"police.cloakroom"}},
	
	["wbody|WEAPON_STUNGUN"] = 15,
	["wammo|WEAPON_COMBATPISTOL"] = 1,
	["wbody|WEAPON_PUMPSHOTGUN"] = 15,
	["wbody|WEAPON_CARBINERIFLE"] = 15,
	["wbody|WEAPON_FLASHLIGHT"] = 15,
		["wammo|WEAPON_PUMPSHOTGUN"] = 1,
	["wammo|WEAPON_CARBINERIFLE"] = 1,
	
	
  },
  
  ["adminweap"] = {
    _config = {map_entity = {"PoI", { marker_id = 1}}, permissions = {"player.noclip"}},
	
	
     ["wbody|WEAPON_KNIFE"] = 5,
  ["wbody|WEAPON_STUNGUN"] = 5,
  ["wbody|WEAPON_FLASHLIGHT"] = 5,
  ["wbody|WEAPON_NIGHTSTICK"] = 5,
  ["wbody|WEAPON_HAMMER"] = 5,
  ["wbody|WEAPON_BAT"] = 5,
  ["wbody|WEAPON_GOLFCLUB"] = 5,
  ["wbody|WEAPON_CROWBAR"] = 5,
  ["wbody|WEAPON_PISTOL"] = 5,
  ["wbody|WEAPON_COMBATPISTOL"] = 5,
  ["wbody|WEAPON_APPISTOL"] = 5,
  ["wbody|WEAPON_PISTOL50"] = 5,
  ["wbody|WEAPON_MICROSMG"] = 5,
  ["wbody|WEAPON_SMG"] = 5,
  ["wbody|WEAPON_ASSAULTSMG"] = 5,
  ["wbody|WEAPON_ASSAULTRIFLE"] = 5,
  ["wbody|WEAPON_CARBINERIFLE"] = 5,
  ["wbody|WEAPON_ADVANCEDRIFLE"] = 5,
  ["wbody|WEAPON_MG"] = 5,
  ["wbody|WEAPON_COMBATMG"] = 5,
  ["wbody|WEAPON_PUMPSHOTGUN"] = 5,
  ["wbody|WEAPON_SAWNOFFSHOTGUN"] = 5,
  ["wbody|WEAPON_ASSAULTSHOTGUN"] = 5,
  ["wbody|WEAPON_BULLPUPSHOTGUN"] = 5,
  ["wbody|WEAPON_STUNGUN"] = 5,
  ["wbody|WEAPON_SNIPERRIFLE"] = 5,
  ["wbody|WEAPON_HEAVYSNIPER"] = 5,
  ["wbody|WEAPON_REMOTESNIPER"] = 5,
  ["wbody|WEAPON_GRENADELAUNCHER"] = 5,
  ["wbody|WEAPON_GRENADELAUNCHER_SMOKE"] = 5,
  ["wbody|WEAPON_RPG"] = 5,
  ["wbody|WEAPON_PASSENGER_ROCKET"] = 5,
  ["wbody|WEAPON_AIRSTRIKE_ROCKET"] = 5,
  ["wbody|WEAPON_STINGER"] = 5,
  ["wbody|WEAPON_MINIGUN"] = 5,
  ["wbody|WEAPON_GRENADE"] = 5,
  ["wbody|WEAPON_STICKYBOMB"] = 5,
  ["wbody|WEAPON_SMOKEGRENADE"] = 5,
  ["wbody|WEAPON_BZGAS"] = 5,
  ["wbody|WEAPON_MOLOTOV"] = 5,
  ["wbody|WEAPON_FIREEXTINGUISHER"] = 5,
  ["wbody|WEAPON_PETROLCAN"] = 5,
  ["wbody|WEAPON_DIGISCANNER"] = 5,
  ["wbody|WEAPON_BRIEFCASE"] = 5,
  ["wbody|WEAPON_BRIEFCASE_02"] = 5,
  ["wbody|WEAPON_BALL"] = 5,
  ["wbody|WEAPON_FLARE"] = 5,
  
 ["wbody|WEAPON_RAILGUN"] = 5,
["wbody|WEAPON_TEC9"] = 5,
["wbody|WEAPON_SPECIALCARBINE"] = 5,
["wbody|WEAPON_COMBATPDW"] = 5,
["wbody|WEAPON_CARBINERIFLEMK2"] = 5,
["wbody|WEAPON_SNSPISTOL"] = 5,
["wbody|WEAPON_ASSAULTRIFLEMK2"] = 5,
["wbody|WEAPON_HEAVYPISTOL"] = 5,
["wbody|WEAPON_BULLPUPRIFLE"] = 5,
["wbody|WEAPON_MACHINEPISTOL"] = 5,
["wbody|WEAPON_MINISMG"] = 5,
["wbody|WEAPON_COMPACTRIFLE"] = 5,
["wbody|WEAPON_DOUBLEBARRELSHOTGUN"] = 5,
["wbody|WEAPON_HEAVYSHOTGUN"] = 5,
["wbody|WEAPON_AUTOSHOTGUN"] = 5,
["wbody|WEAPON_PROXMINE"] = 5,
["wbody|WEAPON_PIPEBOMB"] = 5,
["wbody|WEAPON_COMPACTGRENADELAUNCHER"] = 5,
["wbody|WEAPON_DOUBLE-ACTIONREVOLVER"] = 5,


   
  },
    ["adminammo"] = {
    _config = {map_entity = {"PoI", { marker_id = 1}}, permissions = {"player.noclip"}},
	
	
     ["wbody|WEAPON_KNIFE"] = 5,
  ["wammo|WEAPON_STUNGUN"] = 5,
  ["wammo|WEAPON_FLASHLIGHT"] = 5,
  ["wammo|WEAPON_NIGHTSTICK"] = 5,
  ["wammo|WEAPON_HAMMER"] = 5,
  ["wammo|WEAPON_BAT"] = 5,
  ["wammo|WEAPON_GOLFCLUB"] = 5,
  ["wammo|WEAPON_CROWBAR"] = 5,
  ["wammo|WEAPON_PISTOL"] = 5,
  ["wammo|WEAPON_COMBATPISTOL"] = 5,
  ["wammo|WEAPON_APPISTOL"] = 5,
  ["wammo|WEAPON_PISTOL50"] = 5,
  ["wammo|WEAPON_MICROSMG"] = 5,
  ["wammo|WEAPON_SMG"] = 5,
  ["wammo|WEAPON_ASSAULTSMG"] = 5,
  ["wammo|WEAPON_ASSAULTRIFLE"] = 5,
  ["wammo|WEAPON_CARBINERIFLE"] = 5,
  ["wammo|WEAPON_ADVANCEDRIFLE"] = 5,
  ["wammo|WEAPON_MG"] = 5,
  ["wammo|WEAPON_COMBATMG"] = 5,
  ["wammo|WEAPON_PUMPSHOTGUN"] = 5,
  ["wammo|WEAPON_SAWNOFFSHOTGUN"] = 5,
  ["wammo|WEAPON_ASSAULTSHOTGUN"] = 5,
  ["wammo|WEAPON_BULLPUPSHOTGUN"] = 5,
  ["wammo|WEAPON_STUNGUN"] = 5,
  ["wammo|WEAPON_SNIPERRIFLE"] = 5,
  ["wammo|WEAPON_HEAVYSNIPER"] = 5,
  ["wammo|WEAPON_REMOTESNIPER"] = 5,
  ["wammo|WEAPON_GRENADELAUNCHER"] = 5,
  ["wammo|WEAPON_GRENADELAUNCHER_SMOKE"] = 5,
  ["wammo|WEAPON_RPG"] = 5,
  ["wammo|WEAPON_PASSENGER_ROCKET"] = 5,
  ["wammo|WEAPON_AIRSTRIKE_ROCKET"] = 5,
  ["wammo|WEAPON_STINGER"] = 5,
  ["wammo|WEAPON_MINIGUN"] = 5,
  ["wammo|WEAPON_GRENADE"] = 5,
  ["wammo|WEAPON_STICKYBOMB"] = 5,
  ["wammo|WEAPON_SMOKEGRENADE"] = 5,
  ["wammo|WEAPON_BZGAS"] = 5,
  ["wammo|WEAPON_MOLOTOV"] = 5,
  ["wammo|WEAPON_FIREEXTINGUISHER"] = 5,
  ["wammo|WEAPON_PETROLCAN"] = 5,
  ["wammo|WEAPON_DIGISCANNER"] = 5,
  ["wammo|WEAPON_BRIEFCASE"] = 5,
  ["wammo|WEAPON_BRIEFCASE_02"] = 5,
  ["wammo|WEAPON_BALL"] = 5,
  ["wammo|WEAPON_FLARE"] = 5,
  
   ["wammo|WEAPON_RAILGUN"] = 5,
["wammo|WEAPON_TEC9"] = 5,
["wammo|WEAPON_SPECIALCARBINE"] = 5,
["wammo|WEAPON_COMBATPDW"] = 5,
["wammo|WEAPON_SNSPISTOL"] = 5,
["wammo|WEAPON_HEAVYPISTOL"] = 5,
["wammo|WEAPON_BULLPUPRIFLE"] = 5,
["wammo|WEAPON_MACHINEPISTOL"] = 5,
["wammo|WEAPON_COMPACTRIFLE"] = 5,
["wammo|WEAPON_DOUBLEBARRELSHOTGUN"] = 5,
["wammo|WEAPON_HEAVYSHOTGUN"] = 5,
["wammo|WEAPON_AUTOSHOTGUN"] = 5,
["wammo|WEAPON_PROXMINE"] = 5,
["wammo|WEAPON_PIPEBOMB"] = 5,
["wammo|WEAPON_COMPACTGRENADELAUNCHER"] = 5,
["wammo|WEAPON_DOUBLE-ACTIONREVOLVER"] = 5,

   
  },
    ["Componentes"] = {
    _config = {map_entity = {"PoI", {blip_id = 175, blip_color = 1, marker_id = 23}}},
    ["bulletproof_vest"] = 750,
    ["wcomp|COMPONENT_AT_PI_SUPP"] = 20,
    ["wcomp|COMPONENT_AT_AR_FLSH"] = 20,
    ["wcomp|COMPONENT_AT_PI_FLSH"] = 20,
    ["wcomp|COMPONENT_AT_PI_RAIL"] = 20,
    ["wcomp|COMPONENT_AT_PI_RAIL_02"] = 20,
    ["wcomp|COMPONENT_COMBATPISTOL_VARMOD_LOWRIDER"] = 20,
    ["wcomp|COMPONENT_COMBATPISTOL_CLIP_02"] = 20,
    ["wtint|TINT_Green"] = 10,
    ["wtint|TINT_Gold"] = 10,
    ["wtint|TINT_Pink"] = 10,
    ["wtint|TINT_Army"] = 10,
    ["wtint|TINT_LSPD"] = 10,
    ["wtint|TINT_Orange"] = 10,
    ["wtint|TINT_Platinum"] = 10
  }
 
  
}

-- list of shops {type,x,y,z}

cfg.shops = {
  {"Продукты",-47.522762298584,-1756.85717773438,29.4210109710693},
  {"Продукты",25.7454013824463,-1345.26232910156,29.4970207214355}, 
  {"Продукты",1135.57678222656,-981.78125,46.4157981872559}, 
  {"Продукты",1163.53820800781,-323.541320800781,69.2050552368164}, 
  {"Продукты",374.190032958984,327.506713867188,103.566368103027}, 
  {"Продукты",2555.35766601563,382.16845703125,108.622947692871}, 
  {"Продукты",2676.76733398438,3281.57788085938,55.2411231994629}, 
  {"Продукты",1960.50793457031,3741.84008789063,32.3437385559082},
  {"Продукты",1393.23828125,3605.171875,34.9809303283691}, 
  {"Продукты",1166.18151855469,2709.35327148438,38.15771484375}, 
  {"Продукты",547.987609863281,2669.7568359375,42.1565132141113}, 
  {"Продукты",1698.30737304688,4924.37939453125,42.0636749267578}, 
  {"Продукты",1729.54443359375,6415.76513671875,35.0372200012207}, 
  {"Продукты",-3243.9013671875,1001.40405273438,12.8307056427002}, 
  {"Продукты",-2967.8818359375,390.78662109375,15.0433149337769}, 
  {"Продукты",-3041.17456054688,585.166198730469,7.90893363952637}, 
  {"Продукты",-1820.55725097656,792.770568847656,138.113250732422}, 
  {"Продукты",-1486.76574707031,-379.553985595703,40.163387298584}, 
  {"Продукты",-1223.18127441406,-907.385681152344,12.3263463973999}, 
  {"Продукты",-707.408996582031,-913.681701660156,19.2155857086182},
  {"Продукты",-302.31271362304,6211.7978515625,31.41788482666},
  {"Продукты",-948.17950439454,-169.08801269532,46.26721572876},

 -- {"Бойлер",-444.20028686523,6011.3256835938,31.716394424438},
  --{"Бойлер",1850.6268310547,3685.3898925781,34.267078399658},
  {"Бойлер",259.6354675293,-1375.6336669922,39.534336090088},
  {"Бойлер",269.65216064453,-1354.7806396484,24.537809371948},
  {"Бойлер",454.60443115234,-981.57006835938,26.668560028076 },
  {"Бойлер",470.24951171875,-983.93334960938,24.914716720582},
  {"Бойлер",435.76016235352,-991.48095703125,35.930862426758},
  {"Бойлер",450.65460205078,-981.79211425782,35.931106567382 },
  {"Бойлер",345.32446289062,-590.66650390625,28.79146194458 },
  {"Бойлер",348.49169921875,-582.72955322266,28.791458129882 },
  {"Бойлер",-1694.8345947266,-1125.2596435546,13.152289390564},
  {"Бойлер",1848.8190917968,3687.9287109375,34.286613464356},
  {"Бойлер",-444.06170654296,6011.31640625,31.71633720398 },
  {"Бойлер",-438.4126586914,6006.498046875,31.716320037842 },
  {"Бойлер",-439.2576599121,6005.2280273438,31.716318130494},
  {"Бойлер",-430.9794921875,5992.1831054688,31.716175079346 },
  {"Бойлер",-254.62335205078,6328.6123046875,32.436408996582},
  
  
  {"Напитки",-208.07670593262,-1341.7344970703,34.894374847412},
  {"Напитки",19.799161911011,-1114.2030029297,29.797025680542},
  {"Напитки",260.27841186523,-1376.5655517578,39.534343719482},
  {"Напитки",-2549.4504394531,2317.1530761719,33.215705871582},
  {"Напитки",-1251.3841552734,-1450.2940673828,4.3497819900512},
  {"Напитки",-1695.5456542968,-1127.3781738282,13.152289390564},
  {"Напитки",-1710.1632080078,-1134.1557617188,13.133447647094},
  {"Напитки",473.2103881836,-105.9882888794,63.157901763916},
  {"Напитки",-341.41119384766,-1481.122680664,30.677816390992},
  {"Напитки",62.374633789062,-1576.0600585938,29.597791671752},
  {"Напитки",566.3794555664,-1750.8209228516,29.287540435792},
  {"Напитки",816.55554199218,-2971.6633300782,6.020658493042},
  {"Напитки",1084.8486328125,-775.39849853516,58.219619750976},
  {"Напитки",913.3076171875,3643.4970703125,32.661563873292},
  {"Напитки",1193.3673095704,2701.4013671875,38.159439086914},
  {"Напитки",171.34573364258,-1724.937133789,29.310695648194},
  {"Напитки",2753.6059570312,3478.2292480468,55.671211242676},
  {"Напитки",2558.9934082032,2601.931640625,38.074703216552},
  {"Напитки",436.69540405274,-986.97399902344,30.689331054688},
  {"Напитки",1848.5333251954,3689.345703125,34.286628723144},
  {"Напитки",-443.63931274414,6004.326171875,31.716230392456},
  {"Напитки",-258.99102783204,6326.3754882812,32.435264587402},
  {"Напитки",1834.4298095704,3673.5036621094,34.271015167236},
  {"Кофе",814.31689453125,-2974.1923828125,6.020658493042},
  {"Кофе",-38.155616760254,-1094.5216064453,26.422369003296},
  {"Кофе",436.35913085938,-985.29345703125,30.689334869384},
  {"Кофе",452.9373474121,-987.68090820312,26.674165725708},
  {"Кофе",469.9646911621,-982.30181884766,24.914714813232},
  {"Кофе",430.40252685546,-996.97149658204,35.736896514892},
  {"Кофе",-442.62628173828,6009.5571289062,31.74209022522},
  {"Кофе",-257.5433959961,6327.4116210938,32.43641281128},
  {"Кофе",261.20309448242,-1376.9896240234,39.534343719482},
  {"Кофе",1832.8803710938,3681.3762207032,10.759064674378},
  {"Кофе",-936.53015136718,-161.65644836426,46.250564575196},
  
  {"Снеки",-1693.3669433594,-1123.38671875,13.152285575866},
  {"Снеки",-1707.8107910156,-1135.333618164,13.14672088623},
  {"Снеки",472.01162719726,-105.39163970948,63.157901763916},
  {"Снеки",565.24688720704,-1750.3719482422,29.283292770386},
  {"Снеки",814.75952148438,-2972.1057128906,6.020658493042},
  {"Снеки",1083.6064453125,-775.34149169922,58.19571685791},
  {"Снеки",1999.7958984375,3777.5236816406,32.180786132812},
  {"Снеки",1047.5369873046,2662.962890625,39.551105499268},
  {"Снеки",436.43405151368,-979.70208740234,30.689334869384},
  {"Снеки",463.33651733398,-994.49743652344,30.034156799316},
  {"Снеки",430.6271057129,-998.90710449218,35.739974975586},
  {"Снеки",-441.01657104492,1595.2247314454,358.46807861328},
  
  {"Бар",127.89412689208,-1285.3159179688,29.280626296998},
  {"Бар",-1380.3229980468,-628.81329345704,30.81955909729},
  {"Бар",-1377.3513183594,-627.0230102539,30.819568634034},
  {"Бар",-1393.3544921875,-606.38189697266,30.319557189942},
  {"Бар",-560.24505615234,285.35144042968,82.176330566406},
  {"Бар",1323.8221435546,-2719.2875976562,2.3126528263092},
  {"Бар",-1833.4576416016,-1200.252319336,14.309076309204},
  {"Бар",-357.56954956054,156.15740966796,87.107208251954},
  {"Бар",-452.1481628418,284.32113647461,78.521537780762},
  {"Бар",1985.003540039,3051.8774414062,47.215118408204},
  {"Бар",988.44458007812,-94.584777832032,74.845268249512},
  {"Бар",1122.9624023438,-3144.978515625,-37.06273651123},
  {"Фрукты и овощи",150.00285339356,1667.714477539,228.81231689454},
  {"Фрукты и овощи",1474.7111816406,2724.0207519532,37.635643005372},
  {"Фрукты и овощи",-456.89562988282,2862.0092773438,35.172359466552},
  {"Фрукты и овощи",1089.6256103516,6508.6411132812,21.07953453064},
  {"Фрукты и овощи",163.46774291992,6633.0581054688,31.608974456788},
  {"Фрукты и овощи",-1045.689086914,5326.9643554688,44.679611206054},
  {"Фрукты и овощи",-2507.8024902344,3616.4479980468,13.76732635498},
  {"Фрукты и овощи",-3023.4377441406,370.4165649414,14.700011253356},
  {"Фрукты и овощи",-1555.703125,1374.5729980468,127.00662994384},
  {"Фрукты и овощи",-1381.8568115234,736.830078125,182.97389221192},
  {"Фрукты и овощи",1042.6241455078,696.86810302734,158.85453796386},
  {"Фрукты и овощи",2529.3645019532,2039.4194335938,19.841341018676},
  {"Фрукты и овощи",1265.0458984375,3545.7434082032,35.172229766846},
  {"Фрукты и овощи",2476.3393554688,4447.0659179688,35.349792480468},
  {"Фрукты и овощи",1674.1827392578,4880.8715820312,42.024684906006},
  {"Фрукты и овощи",1790.3001708984,4589.9389648438,37.682960510254},
  {"Фрукты и овощи",-1161.9656982422,-725.1943359375,20.65403175354},
  {"Фрукты и овощи",-1156.293334961,-712.48419189454,21.268203735352},
  {"Фрукты и овощи",1800.3166503906,4590.1118164062,37.652862548828},
  {"Фрукты и овощи",1793.7365722656,4590.720703125,37.682884216308},
  {"Фрукты и овощи",1785.6505126954,4591.0478515625,37.683010101318},
  --{"Фрукты и овощи",},
  
  
  {"Мороженое",-1194.1954345704,-1543.8718261718,4.3725023269654},
  {"Мороженое",-1687.8735351562,-1105.1015625,13.152269363404},
  {"Мороженое",-1644.3243408204,-1101.1813964844,13.019724845886},
  {"Мороженое",-1659.8618164062,-1044.0595703125,13.152775764466},
  {"Мороженое",-1350.1198730468,-1218.3625488282,5.9435262680054},
  {"Мороженое",-944.1162109375,-165.99281311036,46.348514556884},
  
  
  {"Медикоменты",248.30725097656,-1375.0035400391,39.534374237061},
  {"Медикоменты",268.29156494141,-1365.7015380859,24.537788391113},
  {"Медикоменты",1836.2126464844,3668.1779785156,10.685396194458},
  {"Медикоменты",337.501953125,-586.38287353516,28.791479110718},
  {"Медикоменты",-262.74926757812,6311.9365234375,32.436374664306},
  {"Медикоменты",1822.917602539,3667.0886230468,34.271030426026},
  {"Таблетки",-448.29446411132,-340.85754394532,34.501781463624},
  {"Таблетки",-243.53190612792,6325.6489257812,32.426231384278},
  {"Таблетки",591.20245361328,2744.6628417968,42.042812347412},
  {"surgery",245.75833129883,-1354.7580566406,24.537786483765},
  {"surgery",1831.6007080078,3675.6711425782,10.685396194458},
  {"surgery",332.11529541016,-573.63146972656,28.791471481324},
  {"surgery",338.6432800293,-576.55010986328,28.791481018066},
  {"surgery",354.47457885742,-576.66357421875,28.791481018066},
  {"surgery",-259.13952636718,6319.1884765625,32.436374664306},
  {"surgery",-252.59170532226,6327.5825195312,32.43378829956},
  {"surgery",1828.8896484375,3672.9946289062,34.271030426026},
  
  {"Инструменты",479.48031616211,-1326.1010742188,29.207496643066},
  {"Инструменты",737.60699462891,-1078.4658203125,22.168661117554},
  {"Инструменты",-228.02519226074,-1333.2927246094,30.890380859375},
  {"Инструменты",-1158.5455322266,-2025.3530273438,13.146605491638},
  {"Инструменты",1172.6064453125,2635.9685058594,37.791862487793},
  {"Инструменты",109.49509429932,6631.2241210938,31.78723526001},
  {"Инструменты",1110.259765625,-3150.5249023438,-37.518592834472},
  
 -- {"Служебный склад",1850.0501708984,3686.6088867188,34.267082214356},
 -- {"Служебный склад",-445.37161254882,6010.1796875,31.716394424438},
  {"Служебный склад",114.97501373292,-741.98181152344,258.15243530274},
  {"Служебный склад",452.1155090332,-981.15557861328,30.689317703248},
  {"Служебный склад",1851.456665039,3697.4609375,34.2866897583},
  {"Служебный склад",-446.56643676758,6008.8798828125,31.71633720398},
  
  {"Марихуана",-1172.1994628906,-1571.9560546875,4.6636247634888},
  {"Марихуана",-87.736335754394,-83.058319091796,57.816585540772},
  {"Марихуана",169.60191345214,-222.46687316894,54.23733139038},
  {"Торговый центр",-234.21244812012,-333.50311279297,30.081279754639},
  {"Торговый центр",2747.9736328125,3472.5534667969,55.673843383789},
  {"Торговый центр",-913.87475585938,-151.29510498046,46.272212982178},
  {"Для дома и сада",338.7571105957,-777.03076171875,29.266494750976},
  {"Для дома и сада",2476.7744140625,4087.0952148438,38.118999481202},
  {"Для дома и сада",1785.6505126954,4591.0478515625,37.683010101318},
  {"Для дома и сада",-389.8444519043,6050.3564453125,31.500108718872},
  {"Телефон",-1040.112915039,-2741.4272460938,20.169282913208},
  
  {"Бизнес Центр",5.1562628746032,-707.19738769532,45.973045349122},
  

  -- weapons
  
  {"sandyshores1", 1692.41, 3758.22, 34.7053},
  {"vinewood1", 252.696, -48.2487, 69.941},
  {"eastlossantos1", 844.299, -1033.26, 28.1949},
  {"paletobay1", -331.624, 6082.46, 31.4548},
  {"vespuccibeach1", -664.147, -935.119, 21.8292},
  
  {"illegal", 1240.2083740234,-3179.4904785156,7.1048622131348},
  {"police_weapons", 452.21130371094,-979.19903564454,30.689317703248},
  {"police_weapons", 1841.3957519532,3691.5029296875,34.286613464356},
  {"police_weapons", -437.74365234375,5988.6127929688,31.716173171998},
  {"adminammo", -2458.716796875,3301.4821777344,32.977840423584},
  {"adminweap", -2460.6423339844,3303.3999023438,32.977840423584},
  
  {"greatchaparral1", -1119.48803710938,2697.08666992188,18.5541591644287},
  {"tataviammountains1", 2569.62, 294.453, 108.735},
  {"chumash1", -3172.60375976563,1085.74816894531,20.8387603759766},
  {"Componentes", 21.70, -1107.41, 29.79},
  {"cypressflatsrange1", 810.15, -2156.88, 29.61},
  {"Bikerweapon", 988.28186035156,-141.16577148438,73.090789794922}
 

}

return cfg