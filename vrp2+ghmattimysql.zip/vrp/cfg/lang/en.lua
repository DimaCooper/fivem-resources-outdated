
-- define all language properties

local lang = {

 -- ADD THIS 
  component = {
    -- weapon translation by GTA 5 weapon name 
    AT_PI_SUPP = "Silenciador Pistola",
    AT_AR_FLSH = "Lanterna Rifles",
    AT_PI_FLSH = "Lanterna Pistolas"
  },  
  tint = {
    green = "Verde",
    gold = "Dourada",
    pink = "Rosa",
    army = "Exército",
    lspd = "Policial",
    orange = "Laranja",
    platinum = "Cromada"
  },  
--------------------------
  -- ITEM ALREADY EXIST
-----------------------

 ---------------
 -------ADD THIS AFTER
----------------

    wcomp = {
      name = "{1} Component",
      description = "Component {1}.",
      equip = {
        title = "Equip"
      }
    },    
    wtint = {
      name = "Tint {1}",
      description = "Color {1}.",
      equip = {
        title = "Paint"
      }
    },
  common = {
    welcome = "Здравствуйте. Нажмите Ё для вызова меню.~n~: {1}",
    no_player_near = "~r~Нет игроков рядом.",
    invalid_value = "~r~Неверное значение.",
    invalid_name = "~r~Неверное имя .",
    not_found = "~r~Не найдено.",
    request_refused = "~r~Запрос отклонен.",
    wearing_uniform = "~r~Вы в униформе.",
    not_allowed = "~r~Запрещено.",
    must_wait = "~r~Подождите {1} с. перед выполнением действия.",
    menu = {
      title = "Меню"
    }
  },
  hunger = {
  nohunger = "~g~[Потребности]~g~ Полностью сыт.",
    lithunger = "~o~[Потребности]~g~ Чувствую голод!",
	midhunger = "~r~[Потребности]~o~ Сильный голод!!!",
	deathhunger = "~r~[Потребности]~r~ СМЕРТЕЛЬНЫЙ ГОЛОД!!!!!"
  },
   thirst = {
   nothirst = "~g~[Потребности]~g~ Не хочу пить.",
    litthirst = "~o~[Потребности]~g~ Чувствую жажду!",
	midthirst = "~r~[Потребности]~o~ Сильная жажда!!!",
	deaththirst = "~r~[Потребности]~r~ СМЕРТЕЛЬНАЯ ЖАЖДА!!!!!"
  },
  characters = {
    title = "[Персонажи]",
    character = {
      title = "#{1}: {2} {3}",
      error = "~r~Invalid character."
    },
    create = {
      title = "Создать",
      error = "~r~Не удалось создать нового персонажа."
    },
    delete = {
      title = "Удалить",
      prompt = "Идентификатор персонажа для удаления id ?",
      error = "~r~Не удалось удалить персонажа #{1}."
    }
  },
  admin = {
    title = "Admin",
	actions = "Действия",
    call_admin = {
      title = "Call admin",
      prompt = "Describe your problem: ",
      notify_taken = "An admin took your ticket.",
      notify_already_taken = "Ticket already taken.",
      request = "Admin ticket (user_id = {1}) take/TP to ?: {2}"
    },
    tptocoords = {
      title = "TpToCoords",
      prompt = "Coords x,y,z: "
    },
    tptomarker = {
      title = "TpToMarker"
    },
    noclip = {
      title = "Noclip"
    },
    coords = {
      title = "Coords",
      hint = "Copy the coordinates using Ctrl-A Ctrl-C"
    },
    custom_upper_emote = {
      title = "Custom upper emote",
      prompt = "Animation sequence ('dict anim optional_loops' per line): "
    },
    custom_full_emote = {
      title = "Custom full emote"
    },
    custom_emote_task = {
      title = "Custom emote task",
      prompt = "Task name: "
    },
    custom_sound = {
      title = "Custom sound",
      prompt = "Sound 'dict name': "
    },
    custom_model = {
      title = "Custom model",
      prompt = "Model hash or name: "
    },
    custom_audiosource = {
      title = "Custom AudioSource",
      prompt = "Audio source: name=url, omit url to delete the named source."
    },
    users = {
      title = "Users",
      by_id = {
        title = "> By id",
        prompt = "User id: "
      },
      user = {
        title = "#{1}: {2}",
        info = {
          title = "Info",
          description = "<em>Endpoint: </em>{1}<br /><em>Source: </em>{2}<br /><em>Last login: </em>{3}<br /><em>Character id: </em>{4}<br /><em>Banned: </em>{5}<br /><em>Whitelisted: </em>{6}<br /><br />(valid to update)"
        },
        kick = {
          title = "Kick",
          prompt = "Reason: "
        },
        ban = {
          title = "Ban",
          prompt = "Reason: "
        },
        unban = {
          title = "Unban"
        },
        whitelist = {
          title = "Whitelist user"
        },
        unwhitelist = {
          title = "Un-whitelist user"
        },
        tptome = {
          title = "TpToMe"
        },
        tpto = {
          title = "TpTo"
        },
        groups = {
          title = "Groups",
          description = "{1}<br /><br />(valid to update)"
        },
        group_add = {
          title = "Add group",
          prompt = "Group to add: "
        },
        group_remove = {
          title = "Remove group",
          prompt = "Group to remove: "
        },
        give_money = {
          title = "Give money",
          prompt = "Amount: "
        },
        give_item = {
          title = "Give item",
          prompt = "Full id: ",
          prompt_amount = "Amount: ",
          notify_failed = "Invalid item or inventory is full."
        }
      }
    }
  },
  weapon = {
    -- weapon translation by GTA 5 weapon name (lower case)
    knife = "Нож",
stungun = "Тазер", 
flashlight = "Фонарик", 
nightstick = "Дубинка",
hammer = "Молоток", 
bat = "Бита", 
golfclub = "Клюшка для гольфа", 
crowbar = "Гвоздодёр", 
pistol = "Пистолет", 
combatpistol = "Боевой пистолет", 
appistol = "Бронебойный пистолет", 
pistol50 = "Пустынный орел", 
microsmg = "Микро СМГ", 
smg = "СМГ", 
assaultsmg = "Штурмовой СМГ", 
assaultrifle = "Штурмовая винтовка", 
carbinerifle = "Карабин", 
advancedrifle = "Улучш. винтовка", 
mg = "Пулемёт", 
combatmg = "Боевой пулемёт", 
pumpshotgun = "Помповый дробовик",
sawnoffshotgun = "Обрез", 
assaultshotgun = "Штурмовой дробовик", 
bullpupshotgun = "Буллпап дробовик", 
sniperrifle = "Снайперская винтовка", 
heavysniper = "Тяжелая СВ", 
remotesniper = "Компактная СВ", 
grenadelauncher = "Гранатомет", 
grenadelauncher_smoke = "Дымовой гранатомет", 
rpg = "РПГ", 
passenger_rocket = "Ракетница", 
airstrike_rocket = "Противовоздушная ракетница", 
stinger = "Стингер", 
minigun = "Миниган", 
grenade = "Граната", 
stickybomb = "С4", 
smokegrenade = "Дымовая граната", 
bzgas = "Слезоточивый газ", 
molotov = "Молотов", 
fireextinguisher = "Огнетушитель", 
petrolcan = "Канистра бензина", 
digiscanner = "Цифровой сканер", 
briefcase = "Портфель", 
briefcase_2 = "Портфель_2", 
ball = "Мяч", 
flare = "Сигнальная ракета"
  },
  item = {
  wbody = {
      name = "{1} arma",
      description = "Arma {1}.",
      equip = {
        title = "Equipar"
      }
    },
    medkit = {
      name = "Аптечка",
      description = "Используется для оказания первой помощи."
    },
	surgkit = {
      name = "Хирургический набор",
      description = "Все необходимое для проведения операций."
    },
    repairkit = {
      name = "Инструменты",
      description = "Используются для починки транспорта."
    },
    dirty_money = {
      name = "Неучтенные деньги",
      description = "Заплати налоги."
    },
    money = {
      name = "Деньги",
      description = "Упакованные деньги.",
      unpack = {
        title = "Распаковать",
        prompt = "Сколько распаковать ? (max {1})"
      }
    },
    money_binder = {
      name = "Money binder",
      description = "Used to bind 1000$ of money.",
      bind = {
        title = "Bind money"
      }
    },
    wbody = {
      name = "{1} body",
      description = "Ствол {1}.",
      equip = {
        title = "Экипировать"
      }
    },
    wammo = {
      name = "{1} ammo",
      name_box = "{1} ammo x{2}",
      description = "Патроны {1}.",
      load = {
        title = "Зарядить",
        prompt = "Сколько зарядить ? (max {1})"
      },
      open = {
        title = "Открыть"
      }
    },
    bulletproof_vest = {
      name = "Бронежилет",
      description = "Защищает от пуль.",
      wear = {
        title = "Надеть"
      }
    }
  },
  edible = {
    liquid = {
      action = "Выпить",
      notify = "~b~Пью {1}."
    },
    solid = {
      action = "Съесть",
      notify = "~o~Ем {1}."
    },
    drug = {
      action = "Принять",
      notify = "~g~Принимаю {1}."
    }
  },
  survival = {
    starving = "starving",
    thirsty = "thirsty",
    coma_display = [[Вы без сознания, чтобы появиться в реанимации нажмите <span class="key">[Пробел]</span> (min <span class="countdown" data-duration="{1}"></span>) или ждите медиков .<br /> <span class="countdown" data-duration="{2}"></span> .]]
  },
  money = {
    display = "{1} <span class=\"symbol\">$</span>",
    given = "Передано ~r~{1}$.",
    received = "Получено ~g~{1}$.",
    not_enough = "~r~Недостаточно средств.",
    paid = "Оплачено ~r~{1}$.",
    give = {
      title = "Передать деньги",
      description = "Передать деньги ближайшему игроку.",
      prompt = "Количество:"
    },
    transformer_recipe = "{1} $<br />"
  },
  inventory = {
    title = "Инвентарь",
    description = "Открыть инвентарь.",
    iteminfo = "({1})<br /><br />{2}<br /><em>{3} кг</em>",
    info_weight = "вес {1}/{2} кг",
    give = {
      title = "Передать",
      description = "Передать предмет игроку.",
      prompt = "Количество (max {1}):",
      given = "Передано ~r~{1} ~s~{2}.",
      received = "Получено ~g~{1} ~s~{2}.",
    },
    trash = {
     title = "Выбросить",
      description = "Разрушить предмет.",
      prompt = "Количество (max {1}):",
      done = "Выброшено ~r~{1} ~s~{2}."
    },
    missing = "~r~Отсутствует {2} {1}.",
    full = "~r~Инвентарь полный.",
    chest = {
      title = "Хранилище",
      already_opened = "~r~Кто-то уже открыл хранилище.",
      full = "~r~Хранилище полное.",
      take = {
        title = "Взять",
        prompt = "Количество (max {1}):"
      },
      put = {
        title = "Положить",
        prompt = "Количество (max {1}):"
      }
    },
    transformer_recipe = "{2} {1}<br />"
  },
  atm = {
    title = "Банкомат",
    info = {
      title = "Инфо",
      bank = "Счет: {1} $"
    },
    deposit = {
      title = "Депозит",
      description = "Перевести на счет",
      prompt = "Количество:",
      deposited = "~r~{1}$~s~ переведено на счет."
    },
    withdraw = {
      title = "Снять",
      description = "Снять деньги.",
      prompt = "Количество:",
      withdrawn = "~g~{1}$ ~s~снято.",
      not_enough = "~r~Недостаточно денег на счету."
    }
  },
  business = {
    title = "Бизнес",
    identity = {
      title = "Бизнес",
      info = "<em>Название: </em>{1}<br /><em>Капитал: </em>{2} $"
    },
    directory = {
      title = "Каталог",
      description = "Перечень компаний.",
      dprev = "> Вперед",
      dnext = "> Назад",
      info = "<em>Капитал: </em>{1} $<br /><em>Владелец: </em>{2} {3}<br /><em>Регистрация n°: </em>{4}<br /><em>Телефон: </em>{5}"
    },
    info = {
      title = "Инфо",
      info = "<em>Название: </em>{1}<br /><em>Капитал: </em>{2} $<br /><em>Перевод капитала: </em>{3} $<br /><br/>Перевод капитала - это сумма денег, переведенная за экономический период бизнеса, максимальная сумма - бизнес-капитал.."
    },
    addcapital = {
      title = "Увеличить капитал",
      description = "Увеличить капитал вашего бизнеса.",
      prompt = "Количество:",
      added = "~r~{1}$ ~s~добавлено в вашу фирму."
    },
    launder = {
      title = "Отмыть деньги",
      description = "Отмыть грязные деньги.",
      prompt = "Количество (max {1} $): ",
      laundered = "~g~{1}$ ~s~отмыто.",
      not_enough = "~r~Недостаточно денег."
    },
    open = {
      title = "Открыть бизнес",
      description = "Открыть бизнес, минимальный капитал {1} $.",
      prompt_name = "Название (невозможно изменить после создания, макс. {1} символов):",
      prompt_capital = "Начальный капитал (min {1})",
      created = "~g~Бизнес открыт."
      
    }
  },
  identity = {
    title = "Паспорт",
    citizenship = {
      title = "Паспортные данные",
      info = "<em>Фамилия: </em>{1}<br /><em>Имя: </em>{2}<br /><em>Возраст: </em>{3}<br /><em>Рег.номер n°: </em>{4}<br /><em>Телефон: </em>{5}",
    },
    cityhall = {
      title = "Паспортный стол",
      new_identity = {
        title = "Новый паспорт",
        description = "Стоимость нового паспорта = {1} $.",
        prompt_firstname = "Введите имя:",
        prompt_name = "Введите фамилию:",
        prompt_age = "Введите возраст:",
      }
    }
  },
 police = {
    title = "Полиция",
    wanted = "Уровень розыска {1}",
    not_handcuffed = "~r~Не в наручниках",
    cloakroom = {
      title = "Раздевалка",
      uniform = {
        title = "Униформа",
        description = "Снять униформу."
      }
    },
    pc = {
      title = "PC",
      searchreg = {
        title = "Поиск по регистрации",
        description = "Поиск информации по номеру регистрации.",
        prompt = "Введите номер:"
      },
      closebusiness = {
        title = "Закрыть бизнес",
        description = "Закрыть бизнес ближайшего человека.",
        request = "Вы уверены,что хотите закрыть бизнес {3} принадлежащий {1} {2} ?",
        closed = "~g~Бизнес закрыт."
      },
      trackveh = {
        title = "Отследить авто",
        description = "Отследить транспорт по регистрационному номеру.",
        prompt_reg = "Введите номер:",
        prompt_note = "Причина розыска:",
        tracking = "~b~Отслеживание началось.",
        track_failed = "~b~Отслеживание {1}~s~ ({2}) ~n~~r~Не удалось.",
        tracked = "Отслеживание успешно {1} ({2})"
      },
      records = {
        title = "Записи",
        description = "Посмотреть все полицейские записи по номеру регистрации.",
        add = {
          title = "Добавить",
          prompt = "Новая запись:"
        },
        delete = {
          title = "Удалить",
          prompt = "Номер записи ?"
        }
      }
    },
    menu = {
      handcuff = {
        title = "Наручники",
        description = "Одеть/снять наручники."
      },
      drag = {
        title = "Вести",
        description = "Вести человека в наручниках за собой."
      },
      putinveh = {
        title = "Посадить в авто",
        description = "Посадить в транспорт ближайшего человека."
      },
      getoutveh = {
        title = "Высадить из авто",
        description = "Высадить из транспорта."
      },
      askid = {
        title = "Попросить паспорт",
        description = "Попросить паспорт у ближайшего человека.",
        request = "Предоставить паспорт ?",
        request_hide = "Отдать паспорт.",
        asked = "Спрашиваю паспорт..."
      },
      check = {
        title = "Досмотреть",
        description = "Проверить ближайшего человека.",
        checked = "~b~Вас досмотрели.",
        info = {
          title = "Инфо",
          description = "<em>Деньги: </em>{1} $"
        }
      },
      seize = {
        seized = "~b~Ваше оружие и незаконные предметы были изъяты.",
        title = "Изъять оружие/нелегал",
        description = "Изъять оружие и нелегальные предметы у ближайшего человека."
      },
      jail = {
        title = "Тюрьма",
        description = "Посадить/освободить человека.",
        not_found = "~r~Рядом нет заключенных.",
        jailed = "~b~Под стражей.",
        unjailed = "~b~Освобожден.",
        notify_jailed = "~b~Вас взяли под стражу.",
        notify_unjailed = "~b~Вас освободили."
      },
      fine = {
        title = "Штраф",
        description = "Выписать штраф ближайшему человеку.",
        fined = "~b~Оштрафован ~s~{2} $ за ~b~{1}.",
        notify_fined = "~b~Вас оштрафовали ~s~ {2} $ за ~b~{1}.",
        record = "[Штраф] {2} $ за {1}"
      },
      store_weapons = {
        title = "Сложить оружие",
        description = "Сложить оружие в инвентарь."
      }
    }
  },
  emergency = {
    menu = {
      revive = {
        title = "Реанимировать",
        description = "Реанимировать ближайшего человека.",
        not_in_coma = "~r~Не в коме."
      },
	  heal = {
        title = "Лечить",
        description = "Полностью вылечить человека.",
        not_in_coma = "~r~Не в коме."
      }
    }
  },
  phone = {
    title = "Телефон",
    directory = {
      title = "Контакты",
      description = "Открыть список контактов.",
      add = {
        title = "> Добавить",
        prompt_number = "Введите номер:",
        prompt_name = "Введите имя:",
        added = "~g~Успешно."
      },
      sendsms = {
        title = "Отправить СМС",
        prompt = "Ведите сообщение (max {1} символов):",
        sent = "~g~ Отправлено n°{1}.",
        not_sent = "~r~ n°{1} недоступен."
      },
      sendpos = {
        title = "Отправить позицию",
      },
      remove = {
        title = "Удалить"
      },
      call = {
        title = "Позвонить",
        not_reached = "~r~ n°{1} недоступен."
      }
    },
    sms = {
      title = "История СМС",
      description = "История входящих сообщений.",
      info = "<em>{1}</em><br /><br />{2}",
      notify = "СМС~b~ {1}:~s~ ~n~{2}"
    },
    smspos = {
      notify = "GPS-позиция ~b~ {1}"
    },
    service = {
      title = "Службы",
      description = "Быстрый вызов полиции,медиков,механиков,такси.",
      prompt = "Причина вызова:",
      ask_call = "Вызов {1} берете его ? <em>{2}</em>",
      taken = "~r~Вызов уже обрабатывается."
    },
    announce = {
      title = "Анонс",
      description = "Ваше сообщение увидят все.",
      item_desc = "{1} $<br /><br/>{2}",
      prompt = "Введите сообщение (10-1000 chars): "
    },
    call = {
      ask = "Принять звонок от {1} ?",
      notify_to = "Звоню~b~ {1}...",
      notify_from = "Входящий вызов ~b~ {1}...",
      notify_refused = "Звонок ~b~ {1}... ~r~ отклонен."
    },
    hangup = {
      title = "Положить трубку",
      description = "Завершить звонок."
    }
  },
  emotes = {
    title = "Эмоции",
    clear = {
      title = "> Завершить",
      description = "Завершить эмоцию."
    }
  },
  home = {
    address = {
      title = "Адрес",
      info = "{1}, {2}"
    },
    buy = {
      title = "Купить",
      description = "Купить это жилье за {1} $.",
      bought = "~g~Куплено.",
      full = "~r~Нет доступного жилья.",
      have_home = "~r~У вас уже есть жилье."
    },
    sell = {
      title = "Продать",
      description = "Продать ваше жилье {1} $",
      sold = "~g~Продано.",
      no_home = "~r~У вас нет жилья здесь."
    },
    intercom = {
      title = "Домофон",
      description = "Позвонить домофон.",
      prompt = "Номер квартиры:",
      not_available = "~r~.Недоступно",
      refused = "~r~Отказано.",
      prompt_who = "Ваше имя:",
      asked = "Ожидаю...",
      request = "Кто-то хочет зайти к вам в квартиру: <em>{1}</em>"
    },
    slot = {
      leave = {
        title = "Выйти"
      },
      ejectall = {
        title = "Выгнать всех",
        description = "Выгнать всех из своего жилья."
      }
    },
    wardrobe = {
      title = "Гардероб",
      save = {
        title = "> Сохранить",
        prompt = "Название комплекта:"
      }
    },
    gametable = {
      title = "Игровой стол",
      bet = {
        title = "Сделать ставку",
        description = "Сделайте ставку с ближайшеми игроками, победитель будет выбран случайным образом.",
        prompt = "Ставка:",
        request = "[Ставка] вы хотите поставить {1} $ ?",
        started = "~g~Ставка сделана."
      }
    },
    radio = {
      title = "Радио",
      off = {
        title = "> Выключить"
      }
    }
  },
  garage = {
   title = "Гараж ({1})",
    owned = {
      title = "Собственность",
      description = "Транспорт в вашем гараже.",
      already_out = "Этот транспорт уже снаружи.",
      force_out = {
        request = "Транспорт уже снаружи, заплатить за эвакуацию к этому гаражу {1} $  ?"
      }
    },
   buy = {
      title = "Купить",
      description = "Купить транспорт.",
      info = "{1} $<br /><br />{2}"
    },
    sell = {
      title = "Продать",
      description = "Продать транспорт."
    },
    rent = {
      title = "Аренда",
      description = "Арендавать транспорт (до выхода из сессии)."
    },
    store = {
      title = "Поставить",
      description = "Поставить ваш транспорт в гараж.",
      too_far = "Транспорт слишком далеко.",
      wrong_garage = "Транспортное средство не может быть поставлено в этот гараж.",
      stored = "Транспорт в гараже."
    }
  },
  vehicle = {
    title = "Транспорт",
    no_owned_near = "~r~Нет вашего транспорта рядом.",
    trunk = {
      title = "Багажник",
      description = "Открыть багажник."
    },
    detach_trailer = {
      title = "Отцепить прицеп",
      description = "Отцепить прицеп."
    },
    detach_towtruck = {
      title = "Эвакуатор",
      description = "Снять авто с эвакуатора."
    },
    detach_cargobob = {
      title = "Каргобоб",
      description = "Отцепить от каргобоба."
    },
     lock = {
      title = "Закрыть/открыть",
      description = "Закрыть или открыть ваш транспорт.",
      locked = "Транспорт закрыт.",
      unlocked = "Транспорт открыт."
    },
    engine = {
      title = "Двигатель",
      description = "Завести или заглушить двигатель."
    },
    asktrunk = {
      title = "Попросить открыть багажник",
      asked = "~g~Жду...",
      request = "Вы хотите открыть багажник ?"
    },
    replace = {
      title = "Толкнуть транспорт",
      description = "Слегка толкнуть транспорт."
    },
    repair = {
      title = "Отремонтировать",
      description = "Отремонтировать транспорт."
    }
  },
  shop = {
    title = "Магазин ({1})",
    prompt = "Количество {1}, которое вы хотите купить:",
    info = "{1} $<br /><br />{2}"
  },
 skinshop = {
    title = "Одежда",
    info = {
      title = "Инфо",
      description = "Выберите одежду ниже.<br /><br /><em>Цена: </em>{1} $"
    },
   model = "Модель",
    texture = "Цвет",
    palette = "Гамма",
    color_primary = "Первичный цвет",
    color_secondary = "Вторичный цвет",
    opacity = "Прозрачность",
    select_description = "{1}/{2} (выбрать стрелками)"
  },
  cloakroom = {
    title = "Раздевалка ({1})",
    undress = {
      title = "> Снять"
    }
  },
  transformer = {
    recipe_description = [[{1}<br /><br />{2}<div style="color: rgb(0,255,125)">=></div>{3}]],
    empty_bar = "Пусто"
  },
  hidden_transformer = {
    informer = {
      title = "Информатор",
      description = "{1} $",
      bought = "~g~Вам выслана GPS-позиция."
    }
  },
  mission = {
    title = "Задание: ({1}) {2}/{3}",
    display = "<span class=\"name\">{1}</span> <span class=\"step\">{2}/{3}</span><br /><br />{4}",
    cancel = {
      title = "Отменить миссию"
    }
  },
  
    aptitude = {
    title = "Характеристики",
    description = "Показать характеристики.",
    lose_exp = "[Показатель] ~b~{1}/{2} ~r~-{3} ~s~exp.",
    earn_exp = "[Показатель] ~b~{1}/{2} ~g~+{3} ~s~exp.",
    level_down = "[Показатель] ~b~{1}/{2} ~r~уровень понижен ({3}).",
    level_up = "[Показатель] ~b~{1}/{2} ~g~уровень повышен ({3}).",
    display = {
      group = "{1}: ",
      aptitude = "{1} LVL {3} EXP {2}"
    },
    transformer_recipe = "[EXP] {3} {1}/{2}<br />"
  },
  radio = {
    title = "Рация вкл/выкл",
    description = "Позваляет говорить с [TEAM TEXT CHAT] и показывать местоположение,когда ВКЛ."
  }
}

return lang
