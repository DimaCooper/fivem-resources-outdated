
local cfg = {}

-- define static transformers
-- see https://github.com/ImagicTheCat/vRP modules documentation to understand the transformer concept/definition

cfg.transformers = {
  {
    -- example transformers
    title="Спорт. зал", -- menu name
    color={57,42,92}, -- color
    max_units=1000,
    units_per_minute=1000,
    position={-1202.96252441406,-1566.14086914063,4.61040639877319},
    radius=7.5, height=1.5, -- area
    recipes = {
      ["Качать силу"] = { -- action name
        description="Спорт - сила, алкоголь - могила.", -- action description
        reagents={}, 
        products={
          aptitudes={ 
            ["physical.strength"] = 2 -- "group.aptitude", give 1 exp per unit
          }
        },
      }
    }
  },
    {
    -- example transformers
    title="Спорт. зал", -- menu name
    color={57,42,92}, -- color
    max_units=1000,
    units_per_minute=1000,
    position={-928.08068847656,-172.77563476562,46.24691772461},
    radius=7.5, height=1.5, -- area
    recipes = {
      ["Качать силу"] = { -- action name
        description="Спорт - сила, алкоголь - могила.", -- action description
        reagents={}, 
        products={
          aptitudes={ 
            ["physical.strength"] = 2 -- "group.aptitude", give 1 exp per unit
          }
        },
      }
    }
  },
  


{
title="Еда нуждающимся",
    color={57,42,92},
    max_units=10,
    units_per_minute=1,
    position={439.92,-1245.09,30.35},
    radius=4,height=1.5,
    recipes = {
      ["Питьевая вода"] = {
        description="Возьми воды.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["edible|water"] = 1
          }
        },
      },
	  ["Тако"] = {
        description="Покушай.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["edible|tacos"] = 1
          }
        },
      }
    }
  },
  {
  title="Лесоповал",
    color={57,42,92},
    max_units=20,
    units_per_minute=5,
    position={-489.47,5575.41,71.11},
    radius=8,height=1.5,
    recipes = {
      ["Бревно"] = {
        description="Бревна для транспортировки.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["wood"] = 1
          }
        },
      }
    }
  },
  {
  title="Пилорама",
    color={57,42,92},
    max_units=200,
    units_per_minute=10,
    position={-513.56,5257.23,80.61},
    radius=8,height=3,
    recipes = {
      ["Пилорама"] = {
        description="Распиливает бревна на небольшие доски.",
        reagents={
          items = {
            ["wood"] = 1
          }
        },
        products={
          items = {
            ["wplank"] = 5
          }
        },
      }
    }
  },
  {
 title="Лесоповал",
    color={57,42,92},
    max_units=20,
    units_per_minute=5,
    position={-352.68167114258,5946.5732421875,44.397583007813},
    radius=8,height=1.5,
    recipes = {
      ["Бревно"] = {
        description="Бревна для транспортировки.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["wood"] = 1
          }
        },
      }
    }
  },
  {
 title="Лесоповал",
    color={57,42,92},
    max_units=20,
    units_per_minute=5,
    position={-572.08160400391,5603.6079101563,43.183216094971},
    radius=8,height=1.5,
    recipes = {
      ["Бревно"] = {
        description="Бревна для транспортировки.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["wood"] = 1
          }
        },
      }
    }
  },
  
  {
 title="Лесоповал",
    color={57,42,92},
    max_units=20,
    units_per_minute=5,
    position={-608.98815917969,5515.5434570313,50.029674530029},
    radius=8,height=1.5,
    recipes = {
      ["Бревно"] = {
        description="Бревна для транспортировки.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["wood"] = 1
          }
        },
      }
    }
  },
  
 {
 title="Лесоповал",
    color={57,42,92},
    max_units=20,
    units_per_minute=5,
    position={-676.74890136719,5482.2475585938,49.427215576172},
    radius=8,height=1.5,
    recipes = {
      ["Бревно"] = {
        description="Бревна для транспортировки.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["wood"] = 1
          }
        },
      }
    }
  },
   {
 title="Лесоповал",
    color={57,42,92},
    max_units=60,
    units_per_minute=5,
    position={-819.32537841796,5409.8295898438,34.304954528808},
    radius=8,height=1.5,
    recipes = {
      ["Бревно"] = {
        description="Бревна для транспортировки.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["wood"] = 1
          }
        },
      }
    },
	permissions = {
        "vip.vip"
      }
  },
   {
 title="Лесоповал",
    color={57,42,92},
    max_units=40,
    units_per_minute=5,
    position={-796.92803955078,5436.0698242188,34.891242980958},
    radius=8,height=1.5,
    recipes = {
      ["Бревно"] = {
        description="Бревна для транспортировки.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["wood"] = 1
          }
        },
      }
    },
	permissions = {
        "vip.vip"
      }
  },
  {
  title="Склад бревен/досок",
    color={57,42,92},
    max_units=300,
    units_per_minute=15,
    position={58.432846069336,6467.78125,31.42527961731},
    radius=5,height=1.5,
    recipes = {
      ["Сдать бревна"] = {
        description="Сдать бревна за вознаграждение.",
        reagents={
          items = {
           ["wood"] = 1
          }
        },
        products={
          items = {
            ["dirty_money"] = 5
          }
        },
      },
	  
	  ["Сдать доски"] = {
        description="Сдать доски за вознаграждение.",
        reagents={
          items = {
           ["wplank"] = 1
          }
        },
        products={
          items = {
            ["dirty_money"] = 3
          }
        },
      },
	  
    }
  },
  {
  title="Золотая жила",
    color={57,42,92},
    max_units=4,
    units_per_minute=1,
    position={-431.32,2062.96,120.97},
    radius=3,height=1.5,
    recipes = {
      ["Кусочек золота"] = {
        description="Можно сдать в банк.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["gold"] = 1
          }
        },
      }
    }
  },
  {
  title="Серебрянная жила",
    color={57,42,92},
    max_units=8,
    units_per_minute=2,
    position={-562.61,1887.42,123.06},
    radius=3,height=1.5,
    recipes = {
      ["Кусочек серебра"] = {
        description="Можно сдать в банк.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["silver"] = 1
          }
        },
      }
    }
  },
  {
  title="Прием драг.металлов",
    color={57,42,92},
    max_units=4,
    units_per_minute=1,
    position={-1212.04,-336.17,37.79},
    radius=3,height=1.5,
    recipes = {
      ["Сдать золото"] = {
        description="Можно сдать в банк.",
        reagents={
          items = {
            ["gold"] = 5
          }
        },
        products={
          items = {
            ["dirty_money"] = 300
          }
        },
      },
	  
	  ["Сдать серебро"] = {
        description="Можно сдать в банк.",
        reagents={
          items = {
            ["silver"] = 5
          }
        },
        products={
          items = {
            ["dirty_money"] = 200
          }
        },
      }
    }
  },
  {
  title="Карьер",
    color={57,42,92},
    max_units=350,
    units_per_minute=10,
    position={2926.49,2802.59,41.78},
    radius=8,height=1.5,
    recipes = {
      ["Грунт"] = {
        description="Можно переработать в удобрение.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["dirt"] = 1
          }
        },
      }
    }
  },
  {
  title="Завод минералов",
    color={57,42,92},
    max_units=300,
    units_per_minute=10,
    position={2891.65,4380.42,50.33},
    radius=8,height=1.5,
    recipes = {
      ["Минералы"] = {
        description="Немного земли и удобрение готово.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["minerals"] = 1
          }
        },
      }
    }
  },
  {
  title="Завод удобрений",
    color={57,42,92},
    max_units=300,
    units_per_minute=10,
    position={2705.41,2865.29,37.50},
    radius=8,height=1.5,
    recipes = {
      ["Создать удобрения"] = {
        description="Просто смешать",
        reagents={
          items = {
            ["dirt"] = 1 ,
			["minerals"] = 1
          }
        },
        products={
          items = {
            ["fertilizer"] = 1
          }
        },
      }
    }
  },
  {
  title="Склад удобрений",
    color={57,42,92},
    max_units=300,
    units_per_minute=15,
    position={406.48,6461.24,28.80},
    radius=8,height=1.5,
    recipes = {
      ["Сдать удобрения"] = {
        description="Сдавай удобрения и зарабатывай.",
        reagents={
          items = {
            ["fertilizer"] = 1
          }
        },
        products={
          items = {
           ["dirty_money"] = 7
          }
        },
      },
	  
	  ["Сдать грунт"] = {
        description="Сдавай грунт и зарабатывай.",
        reagents={
          items = {
            ["dirt"] = 1
          }
        },
        products={
          items = {
           ["dirty_money"] = 2
          }
        },
      }
    }
  },
  {
  title="Рыбное место",
    color={57,42,92},
    max_units=50,
    units_per_minute=8,
    position={1282.52,4117.04,29.18},
    radius=16,height=3,
    recipes = {
      ["Сырая рыба"] = {
        description="Клюет!",
        reagents={
          items = {
           
          }
        },
        products={
          items = {
            ["edible|fish"] = 1
          }
        },
      }
    }
  },
  {
  title="Рыбное место",
    color={57,42,92},
    max_units=500,
    units_per_minute=18,
    position={4260.57,4760.21,0.0},
    radius=22,height=7,
    recipes = {
      ["Сырая рыба"] = {
        description="Рыбное место!",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["edible|fish"] = 2
          }
        },
      }
    }
  },
  {
  title="Рыбзавод",
    color={57,42,92},
    max_units=30,
    units_per_minute=5,
    position={1303.59,4321.35,38.18},
    radius=8,height=2,
    recipes = {
      ["Сырая рыба"] = {
        description="Продать рыбу.",
        reagents={
          items = {
            ["edible|fish"] = 1
          }
        },
        products={
          items = {
            ["dirty_money"] = 3
          }
        },
      }
    }
  },
  {
  title="Рыбзавод",
    color={57,42,92},
    max_units=350,
    units_per_minute=15,
    position={-271.59,-2723.32,1.00},
    radius=20,height=10,
    recipes = {
      ["Сырая рыба"] = {
        description="Продать рыбу.",
        reagents={
          items = {
            ["edible|fish"] = 2
          }
        },
        products={
          items = {
            ["dirty_money"] = 8
          }
        },
      }
    }
  },
  {
  title="Костер",
    color={57,42,92},
    max_units=6,
    units_per_minute=2,
    position={3291.84,5192.40,18.40},
    radius=2,height=2,
    recipes = {
      ["Пожарить рыбу"] = {
        description="Немного соли и будет объедение!",
        reagents={
          items = {
            ["edible|fish"] = 1
          }
        },
        products={
          items = {
            ["edible|friedfish"] = 1
          }
        },
      }
    }
  },
  
  {
  title="Костер",
    color={57,42,92},
    max_units=6,
    units_per_minute=2,
    position={-2878.52,3106.15,2.82},
    radius=2,height=2,
    recipes = {
      ["Пожарить рыбу"] = {
        description="Немного соли и будет объедение!",
        reagents={
          items = {
            ["edible|fish"] = 1
          }
        },
        products={
          items = {
            ["edible|friedfish"] = 1
          }
        },
      }
    }
  },
  
  {
  title="Костер",
    color={57,42,92},
    max_units=6,
    units_per_minute=2,
    position={-2608.32,3574.75,3.60},
    radius=2,height=2,
    recipes = {
      ["Пожарить рыбу"] = {
        description="Немного соли и будет объедение!",
        reagents={
          items = {
            ["edible|fish"] = 1
          }
        },
        products={
          items = {
            ["edible|friedfish"] = 1
          }
        },
      }
    }
  },
  
  {
  title="Костер",
    color={57,42,92},
    max_units=6,
    units_per_minute=2,
    position={-2317.16,4383.17,7.82},
    radius=2,height=2,
    recipes = {
      ["Пожарить рыбу"] = {
        description="Немного соли и будет объедение!",
        reagents={
          items = {
            ["edible|fish"] = 1
          }
        },
        products={
          items = {
            ["edible|friedfish"] = 1
          }
        },
      }
    }
  },
  
  {
  title="Костер",
    color={57,42,92},
    max_units=6,
    units_per_minute=2,
    position={-835.07,5893.94,5.44},
    radius=2,height=2,
    recipes = {
      ["Пожарить рыбу"] = {
        description="Немного соли и будет объедение!",
        reagents={
          items = {
            ["edible|fish"] = 1
          }
        },
        products={
          items = {
            ["edible|friedfish"] = 1
          }
        },
      }
    }
  },
  
  {
  title="Костер",
    color={57,42,92},
    max_units=6,
    units_per_minute=2,
    position={2513.52,-1222.61,2.73},
    radius=2,height=2,
    recipes = {
      ["Пожарить рыбу"] = {
        description="Немного соли и будет объедение!",
        reagents={
          items = {
            ["edible|fish"] = 1
          }
        },
        products={
          items = {
            ["edible|friedfish"] = 1
          }
        },
      }
    }
  },
  
  {
  title="Костер",
    color={57,42,92},
    max_units=6,
    units_per_minute=2,
    position={2538.92,6619.09,2.01},
    radius=2,height=2,
    recipes = {
      ["Пожарить рыбу"] = {
        description="Немного соли и будет объедение!",
        reagents={
          items = {
            ["edible|fish"] = 1
          }
        },
        products={
          items = {
            ["edible|friedfish"] = 1
          }
        },
      }
    }
  },
  {
  title="Завод семян",
    color={57,42,92},
    max_units=300,
    units_per_minute=10,
    position={2902.71,4415.30,48.82},
    radius=8,height=1.5,
    recipes = {
      ["Семена"] = {
        description="Посади в удобренную землю и полей.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["seed"] = 1
          }
        },
      }
    }
  },
  {
  title="Источник воды",
    color={57,42,92},
    max_units=500,
    units_per_minute=10,
    position={2049.42,3953.46,31.00},
    radius=8,height=1.5,
    recipes = {
      ["Техническая вода"] = {
        description="Для технических нужд.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["edible|dirtywater"] = 1
          }
        },
      }
    }
  },
  {
  title="Поле",
    color={57,42,92},
    max_units=300,
    units_per_minute=10,
    position={270.04,6651.87,29.82},
    radius=8,height=1.5,
    recipes = {
      ["Вырастить корм"] = {
        description="Нужно немного поработать.",
        reagents={
          items = {
            ["seed"] = 1 ,
			["fertilizer"] = 1,
			["edible|dirtywater"] = 1
          }
        },
        products={
          items = {
            ["feed"] = 1
          }
        },
      }
    }
  },
  {
  title="Мясокомбинат",
    color={57,42,92},
    max_units=200,
    units_per_minute=10,
    position={-65.49,6240.96,31.08},
    radius=6,height=1.5,
    recipes = {
      ["Продать корм"] = {
        description="Достойная оплата за труды.",
        reagents={
          items = {
            ["feed"] = 1
          }
        },
        products={
          items = {
            ["dirty_money"] = 50
          }
        },
      }
    }
  },
  {
  title="Нефтяная вышка",
    color={57,42,92},
    max_units=80,
    units_per_minute=4,
    position={585.44,2935.80,40.96},
    radius=8,height=1.5,
    recipes = {
      ["Нефть"] = {
        description="Можно переработать.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["oil"] = 1
          }
        },
      }
    }
  },
  {
  title="Нефтяная вышка",
    color={57,42,92},
    max_units=60,
    units_per_minute=3,
    position={234.60,-2209.40,7.88},
    radius=8,height=1.5,
    recipes = {
      ["Нефть"] = {
        description="Можно переработать.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["oil"] = 1
          }
        },
      }
    }
  },
  {
  title="Нефтяная вышка",
    color={57,42,92},
    max_units=40,
    units_per_minute=3,
    position={1726.94,-1669.44,112.56},
    radius=8,height=1.5,
    recipes = {
      ["Нефть"] = {
        description="Можно переработать.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["oil"] = 1
          }
        },
      }
    }
  },
  {
  title="Нефтяная вышка",
    color={57,42,92},
    max_units=30,
    units_per_minute=3,
    position={1532.51,-2071.15,77.25},
    radius=8,height=1.5,
    recipes = {
      ["Нефть"] = {
        description="Можно переработать.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["oil"] = 1
          }
        },
      }
    }
  },
  {
  title="Нефтяная вышка",
    color={57,42,92},
    max_units=60,
    units_per_minute=4,
    position={1427.53,-2304.35,66.99},
    radius=8,height=1.5,
    recipes = {
      ["Нефть"] = {
        description="Можно переработать.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["oil"] = 1
          }
        },
      }
    }
  },
  --
    {
  title="Нефтяная вышка",
    color={57,42,92},
    max_units=100,
    units_per_minute=6,
    position={1025.6014,3600.5732,33.2422},
    radius=8,height=1.5,
    recipes = {
      ["Нефть"] = {
        description="Можно переработать.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["oil"] = 1
          }
        },
      }
    },
	permissions = {
        "vip.vip"
      }
  },
  
    {
  title="Нефтяная вышка",
    color={57,42,92},
    max_units=100,
    units_per_minute=6,
    position={1120.4757,3603.8537,32.9969},
    radius=8,height=1.5,
    recipes = {
      ["Нефть"] = {
        description="Можно переработать.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["oil"] = 1
          }
        },
      }
    },
	permissions = {
        "vip.vip"
      }
  },
  --
  {
  title="Нефтепереработка",
    color={57,42,92},
    max_units=200,
    units_per_minute=8,
    position={509.19,-2269.78,5.96},
    radius=8,height=1.5,
    recipes = {
      ["Переработать нефть"] = {
        description="Бензин нужен всем.",
        reagents={
          items = {
            ["oil"] = 1
          }
        },
        products={
          items = {
            ["gas"] = 1
          }
        },
      }
    }
  },
  {
  title="Склад нефтепродуктов",
    color={57,42,92},
    max_units=250,
    units_per_minute=8,
    position={2677.73,1558.88,24.50},
    radius=8,height=1.5,
    recipes = {
      ["Нефть"] = {
        description="Продать нефть.",
        reagents={
          items = {
            ["oil"] = 1
          }
        },
        products={
          items = {
            ["dirty_money"] = 3
          }
        },
      },
	  ["Бензин"] = {
        description="Продать бензин.",
        reagents={
          items = {
            ["gas"] = 1
          }
        },
        products={
          items = {
            ["dirty_money"] = 6
          }
        },
      },
	  
    }
  },
  
   {
  title="Почта",
    color={57,42,92},
    max_units=60,
    units_per_minute=4,
    position={-422.71075439454,-2786.2272949218,6.0003824234008},
    radius=8,height=1.5,
    recipes = {
      ["Почта"] = {
        description="Нужно доставить клиентам.",
        reagents={
          items = {
            
          }
        },
        products={
          items = {
            ["post"] = 1
          }
        },
      }
    }
  },
  
  
}

return cfg
