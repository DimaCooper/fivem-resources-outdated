
local cfg = {}

-- (see vRP.EXT.Inventory:defineItem)
-- map of id => {name, description, menu_builder, weight}
--- name: display name, value or genfunction(args)
--- description: value or genfunction(args) (html)
--- menu_builder: (optional) genfunction(args, menu)
--- weight: (optional) value or genfunction(args)
--
-- genfunction are functions returning a correct value as: function(args, ...)
-- where args is a list of {base_idname,args...}
cfg.items = {

  ["wood"] = {"Бревно", "<div><img src='https://i.ibb.co/8M0wM8S/image.png' alt ='image' /></div> А что если его обработать ?",nil, 0.5},
  ["wplank"] = {"Доска", "<div><img src='https://i.ibb.co/cgpj35p/image.png' alt ='image' /></div> В хозяйстве пригодится.",nil, 0.1},
  ["gold"] = {"Золото", "<div><img src='https://i.ibb.co/dDqDpbC/image.png' alt ='image' /></div> Очень красивый самородок.", nil, 0.5},
  ["silver"] = {"Серебро", "<div><img src='https://i.ibb.co/JtrKrC0/image.png' alt ='image' /></div> Говорят, что убивает вампиров. ", nil, 0.5},
  ["dirt"] = {"Земля", "<div><img src='https://i.ibb.co/4ZR45Gv/image.png' alt ='image' /></div> Обычная земля.",nil, 0.5},
  ["minerals"] = {"Минералы","<div><img src='https://i.ibb.co/6JXZ2Nv/image.png' alt ='image' /></div> Удобряют землю.", nil, 0.2},
  ["fertilizer"] = {"Удобрения", "<div><img src='https://i.ibb.co/S3gbJx6/image.png' alt ='image' /></div> Пригодятся для выращивания овощей.", nil, 0.6},
  ["feed"] = {"Корм для животных", "<div><img src='https://i.ibb.co/FWrmt6D/image.png' alt ='image' /></div> Сделан с любовью.",nil, 0.2},
  ["seed"] = {"Семена", "<div><img src='https://i.ibb.co/GWYrygB/image.png' alt ='image' /></div> Что-то да вырастет.",nil, 0.01},
  ["oil"] = {"Нефть", "<div><img src='https://i.ibb.co/74TDbzj/image.png' alt ='image' /></div> Черное золото.", nil, 0.4},
  ["gas"] = {"Бензин", "<div><img src='https://i.ibb.co/12t6M2P/image.png' alt ='image' /></div> Регуляр.", nil, 0.4},
  ["dirty_money"] = {"Неучтенные деньги","<div><img src='https://i.ibb.co/VBf6P41/image.png' alt ='image' /></div> ",nil,0.0},
  ["license"] = {"Права","<div><img src='https://i.ibb.co/Wtpx0SJ/image.png' alt ='image' /></div> Дают разрешение на управление любым наземным транспортом",nil,0.0},
  ["licensepilot"] = {"Лицензия пилота","<div><img src='https://i.ibb.co/b7HS5kc/image.png' alt ='image' /></div> Дает разрешение на управление лююбым воздушным транспортом.",nil,0.0},
  ["licensemed"] = {"Мед.справка","<div><img src='https://i.ibb.co/G9XhPsW/image.png' alt ='image' /></div> Человек полностью здоров",nil,0.0},
  ["licenseweed"] = {"Заключение психолога","<div><img src='https://i.ibb.co/zRNHqx1/image.png' alt ='image' /></div> Дает право покупать и употреблять легальную марихуану.",nil,0.0},
  ["licenseinv"] = {"Справка о инвалидности","<div><img src='https://i.ibb.co/JnNp5js/image.png' alt ='image' /></div> Паркуйся где хочешь",nil,0.0},
  ["licensecom"] = {"Коммерческая лицензия","<div><img src='https://i.ibb.co/B2L92cN/image.png' alt ='image' /></div> Разрешение на ведение коммерческой деятельности.",nil,0.0},
  ["licensegun"] = {"Лицензия на оружие","<div><img src='https://i.ibb.co/tKnYGYj/image.png' alt ='image' /></div> Разрешает носить с собой пистолеты и ружья. Автоматическое оружие запрещено.",nil,0.0},
  ["post"] = {"Почта","<div><img src='https://i.ibb.co/y4hFHXT/image.png' alt ='image' /></div> Письма и мелкие коробки.",nil,0.5},
  ["phoneitem"] = {"Телефон","<div><img src='https://i.ibb.co/0Zmyt8k/image.png' alt ='image' /></div> Ну сам подумай, для чего он!",nil,0.2},
  ["key_lspd"] = {"Ключ ЛСПД","<div><img src='https://i.ibb.co/QCWGGcQ/image.png' alt ='image' /></div> ",nil,0.01},
  ["key_staff"] = {"Ключ ЛСПД (служебный)","<div><img src='https://i.ibb.co/QCWGGcQ/image.png' alt ='image' /></div> ",nil,0.01},
  ["bbox"] = {"Бумбокс","<div><img src='' alt ='image' /></div> ",nil,0.01},
}

return cfg
