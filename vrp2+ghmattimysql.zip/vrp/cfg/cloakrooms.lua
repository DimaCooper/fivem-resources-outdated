
-- this file configure the cloakrooms on the map

local cfg = {}

-- prepare surgeries customizations
local surgery_male = { model = "mp_m_freemode_01" }
local surgery_female = { model = "mp_f_freemode_01" }

for i=0,19 do
  surgery_female[i] = {0,0}
  surgery_male[i] = {0,0}
end

-- cloakroom types (_config, map of name => customization)
--- _config:
---- map_entity: {ent,cfg} will fill cfg.title, cfg.pos
---- permissions (optional)
---- not_uniform (optional): if true, the cloakroom will take effect directly on the player, not as a uniform you can remove
cfg.cloakroom_types = {
  ["Police"] = {
    _config = { permissions = {"police.cloakroom"}, map_entity = {"PoI", {marker_id = 1}} },
    ["Daily_M"] = {
      ["drawable:3"] = {19,0},
      ["drawable:4"] = {25,0},
      ["drawable:6"] = {10,0},
      ["drawable:8"] = {58,0},
      ["drawable:11"] = {55,0},
      ["prop:2"] = {33,0},
	 
	  ["drawable:1"] = {0,0},
	  ["drawable:7"] = {0,0},
    },
    ["Daily_F"] = {
      ["drawable:3"] = {35,0},
      ["drawable:4"] = {30,0},
      ["drawable:6"] = {24,0},
      ["drawable:8"] = {6,0},
      ["drawable:11"] = {48,0},
      ["prop:2"] = {2,0},

	  ["drawable:1"] = {0,0},
	  ["drawable:7"] = {0,0},
    }
  },
  ["Emergency"] = {
    _config = { permissions = {"emergency.cloakroom"}, map_entity = {"PoI", {marker_id = 1}} },
    ["Daily_M"] = {
      ["drawable:3"] = {92,0},
      ["drawable:4"] = {20,0}, 
      ["drawable:8"] = {15,0},
      ["drawable:6"] = {42,0},
      ["drawable:11"] = {13,0},
      ["prop:1"] = {17,9},
	
	  ["drawable:1"] = {0,0},
	  ["drawable:7"] = {0,0},
      
    },
	
  },
  ["Repair"] = {
    _config = { permissions = {"repair.cloakroom"}, map_entity = {"PoI", {marker_id = 1}} },
    ["Daily_M"] = {
      ["drawable:3"] = {16,0},
      ["drawable:4"] = {39,2},
      ["drawable:8"] = {57,0},
      ["drawable:6"] = {27,0},
      ["drawable:11"] = {66,2},
   
	  ["drawable:1"] = {0,0},
	  ["drawable:7"] = {0,0},
	  ["prop:0"] = {77,9}
      
    }
  },
  ["jail"] = {
    _config = { map_entity = {"PoI", {marker_id = 1}} },
    ["Male suit"] = {
      ["drawable:3"] = {5,0},
      ["drawable:4"] = {7,15},
      ["drawable:8"] = {5,0},
      ["drawable:6"] = {12,6},
      ["drawable:11"] = {5,0}
    }
  },
  ["surgery"] = {
    _config = { not_uniform = true, map_entity = {"PoI", {marker_id = 1}} },
    ["Male"] = surgery_male,
    ["Female"] = surgery_female
  }
}

cfg.cloakrooms = {
  {"Police", 454.50079345704,-989.24658203125,30.689329147338},
  {"Police", 1840.2622070312,3690.626953125,34.286643981934},
  {"Police", -440.33374023438,5991.1186523438,31.716190338134},
 {"Emergency",269.88235473632,-1363.9315185546,24.537788391114},
 {"Emergency",1820.5954589844,3673.4426269532,10.68539428711},
 {"Emergency",336.0251159668,-579.91796875,28.791481018066},
 {"Emergency",-252.58549499512,6323.4516601562,32.436405181884},
 {"Emergency",1823.7355957032,3686.7446289062,34.271030426026},
 {"Repair",475.51849365234,-1310.642578125,29.206592559814},
 {"Repair",1188.3846435546,2636.94140625,38.439311981202},
 {"Repair",1116.9982910156,-3162.9792480468,-36.870487213134},
 
 {"surgery",-1040.2092285156,-2745.8356933594,21.359399795532},
}

return cfg
