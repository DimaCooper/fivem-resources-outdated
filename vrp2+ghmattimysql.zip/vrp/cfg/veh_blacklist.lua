
local cfg = {}

cfg.remove_interval = 150 -- number of milliseconds between two remove check

-- Veh model blacklist, names (string) or hashes (number)
cfg.veh_models = {
  "police",
  "police2",
  "police3",
  "police4",
  "SHERIFF",
  "SHERIFF2",
  "policet",
  "ambulance",
  "POLICEB",
  "fbi",
  "pranger",
  "riot",
  "pbus"
}

return cfg