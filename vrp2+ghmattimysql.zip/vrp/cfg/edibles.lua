
local cfg = {}

cfg.action_delay = 4 -- seconds, delay between two edible consume actions

cfg.solid_sound = ""
cfg.liquid_sound = ""

-- (see vRP.EXT.Edible:defineEdible)
-- map of id => {type, effects, name, description, weight}
--- type
---- default types: liquid, solid, drug
--- effects: map of effect => value
---- default effects: water (0-1), food (0-1), health (0-100)
--- name, description, weight: same as item
cfg.edibles = {
 water = {"liquid", {water = 0.25},"Питьевая вода","<div><img src='https://i.ibb.co/LCNtFRY/image.png' alt ='image' /></div> ",0.5},
milk = {"liquid", {water = 0.2},"Молоко","<div><img src='https://i.ibb.co/BBmD9G7/image.png' alt ='image' /></div> Сделано в Палето.",0.5},
coffee = {"liquid", {water = 0.15},"Кофе","<div><img src='https://i.ibb.co/x1w8s4R/image.png' alt ='image' /></div> Отлично бодрит.",0.2},
tea = {"liquid", {water = 0.3},"Горячий чай","<div><img src='https://i.ibb.co/VgD0Lrc/image.png' alt ='image' /></div> Согревает и бодрит.",0.2},
icetea = {"liquid", {water = 0.15},"Холодный чай","<div><img src='https://i.ibb.co/p1Lh3Rr/image.png' alt ='image' /></div> ", 0.5},
orangejuice = {"liquid", {water = 0.2},"Апельсиновый сок","<div><img src='https://i.ibb.co/25XxJkB/image.png' alt ='image' /></div> Свежевыжатый",0.5},
gocagola = {"liquid", {water = 0.2},"Кола","<div><img src='https://i.ibb.co/kGnXf8f/image.png' alt ='image' /></div> Вкус легенды.",0.3},
redgull = {"liquid", {water = 0.25},"Энергетик","<div><img src='https://i.ibb.co/1RNR85W/image.png' alt ='image' /></div> Окрыляет?!?!",0.3},
lemonlimonad = {"liquid", {water = 0.25},"Лимонад","<div><img src='https://i.ibb.co/b5vy7Y9/image.png' alt ='image' /></div> Экологически чистый.",0.3},
vodka = {"alco", {water = 0.3},"Водка","<div><img src='https://i.ibb.co/FbH8Scd/image.png' alt ='image' /></div> Из России с любовью <3",0.5},
dirtywater = {"liquid", {water = -0.55},"Неочищенная вода", "<div><img src='https://i.ibb.co/bb76Qgk/image.png' alt ='image' /></div> НЕ ПЕЙ!",0.3},
minwater = {"liquid", {water = 0.2},"Минералка","<div><img src='https://i.ibb.co/tQQ8PFx/image.png' alt ='image' /></div> ",0.5},
applejuise = {"liquid", {water = 0.2},"Яблочный сок","<div><img src='https://i.ibb.co/25XxJkB/image.png' alt ='image' /></div> Лучший из лучших.",0.5},
beer = {"liquid", {water = 0.3},"Пиво","<div><img src='https://i.ibb.co/cbRXP64/image.png' alt ='image' /></div> Холодное,как сердце твоей бывшей.",0.5},
wine = {"liquid", {water = 0.35},"Вино","<div><img src='https://i.ibb.co/34fWMm4/image.png' alt ='image' /></div> С местных виноградников.",0,5},
americano = {"liquid", {water = 0.2},"Американо","<div><img src='https://i.ibb.co/QK4fm2w/image.png' alt ='image' /></div> Очень горячий.",0.4},
espresso = {"liquid", {water = 0.15},"Эспрессо","<div><img src='https://i.ibb.co/6mRRL0w/image.png' alt ='image' /></div> Крепкий и бодрящий.",0.2},
rastvorcoffe = {"liquid", {water = 0.1},"Растворимый кофе","<div><img src='https://i.ibb.co/z5wxTN3/image.png' alt ='image' /></div> А стоит ли?",0.4},
spirt = {"alco", {water = 0.05},"Спирт","<div><img src='https://i.ibb.co/znQ6J2Q/image.png' alt ='image' /></div> Исключительно для мед.целей.",0.2},
pinakolada = {"liquid", {water = 0.15},"Пина колада","<div><img src='https://i.ibb.co/R0QNZ2m/image.png' alt ='image' /></div> ",0.1},
daikiri = {"liquid", {water = 0.15},"Дайкири","<div><img src='https://i.ibb.co/nssY7PB/image.png' alt ='image' /></div> ",0.1},
oazis = {"liquid", {water = 0.15},"Оазис","<div><img src='https://i.ibb.co/YPHPW6R/image.png' alt ='image' /></div> ",0.1},
b52 = {"alco", {water = 0.05},"Б-52 ","<div><img src='https://i.ibb.co/prYTQMN/52.png' alt ='image' /></div> ",0.1},
mohito = {"liquid", {water = 0.25},"Мохито","<div><img src='https://i.ibb.co/VSPm3VY/image.png' alt ='image' /></div> ",0.1},
otvertka = {"alco", {water = 0.15},"Отвертка","<div><img src='https://i.ibb.co/mCxg39c/image.png' alt ='image' /></div> ",0.1},
strawliker = {"liquid", {water = 0.15},"Клубничный ликер","<div><img src='https://i.ibb.co/FVKG4H2/image.png' alt ='image' /></div> ",0.1},
djin = {"liquid", {water = 0.15},"Шипучий Джин","<div><img src='https://i.ibb.co/zxrdKKV/image.png' alt ='image' /></div> ",0.1},
djintonik = {"alco", {water = 0.25},"Джин-тоник","<div><img src='https://i.ibb.co/3dgmWnX/image.png' alt ='image' /></div> ",0.1},
strawkiss = {"liquid", {water = 0.15},"Клубничный поцелуй","<div><img src='https://i.ibb.co/P4Hv27b/image.png' alt ='image' /></div> ",0.1},

--FOOD

-- create Breed item
bread = {"solid", {food = 0.15},"Хлеб","<div><img src='https://i.ibb.co/3T9MLGn/image.png' alt ='image' /></div> Свежий, вкусный.",0.5},
donut = {"solid", {food = 0.1},"Пончик","<div><img src='https://i.ibb.co/fCP3s2r/image.png' alt ='image' /></div> Почему их так любят копы?",0.2},
tacos = {"solid", {food = 0.2},"Тако","<div><img src='https://i.ibb.co/whfTnvQ/image.png' alt ='image' /></div> Острый,но очень вкусный",0.2},
sandwichbecon = {"solid", {food = 0.2},"Сэндвич с беконом","<div><img src='https://i.ibb.co/W3TcL5T/image.png' alt ='image' /></div> Хороший перекус,отличный вкус.",0.3},
sandwichchease = {"solid", {food = 0.2},"Сэндвич с сыром","<div><img src='https://i.ibb.co/Ns6Jk5B/image.png' alt ='image' /></div> Хороший перекус,отличный вкус.",0.3},
kebab = {"solid", {food = 0.1},"Кебаб","<div><img src='https://i.ibb.co/0qFZZW2/image.png' alt ='image' /></div> Что может быть лучше мяса?",0.8},
pdonut = {"solid", {food = 0.15},"Большой пончик","<div><img src='https://i.ibb.co/qm56j1T/image.png' alt ='image' /></div> Кинг сайз.", 0.4},
fish = {"solid", {food = 0.2, water = -0.35},"Сырая рыба", "<div><img src='https://i.ibb.co/7YsjHgr/image.png' alt ='image' /></div> Не рекомендуется есть сырой.",0.4},
friedfish = {"solid", {food = 0.2, water = -0.05},"Жаренная рыба", "<div><img src='https://i.ibb.co/gR70QCq/image.png' alt ='image' /></div> Как вкусно! ", 0.25},
cheaps = {"solid", {food = 0.1},"Чипсы","<div><img src='https://i.ibb.co/mTjnS65/image.png' alt ='image' /></div> С пивом пойдет.",0.2},
spagetti = {"solid", {food = 0.4},"Лапша с курицей","<div><img src='https://i.ibb.co/DwPGWXT/image.png' alt ='image' /></div> Коробочка, терияки.Ничего лишнего.",0.5},
spagettibecon = {"solid", {food = 0.4},"Лапша с говядиной","<div><img src='https://i.ibb.co/xDMcHSW/image.png' alt ='image' /></div> Палочки в комплекте не идут.",0.5},
chikensoup = {"solid", {food = 0.4, water = 0.4},"Куриный суп","<div><img src='https://i.ibb.co/gv00hJG/image.png' alt ='image' /></div> Легкий и полезный.",0.4},
borsh = {"solid", {food = 0.6, water = 0.5},"Борщ","<div><img src='https://i.ibb.co/TbRBtfP/image.png' alt ='image' /></div> Со сметанкой.",0.5},
gamburger = {"solid", {food = 0.2},"Гамбургер","<div><img src='https://i.ibb.co/yhT6ghw/image.png' alt ='image' /></div> Классика фастфуда.",0.4},
naggets = {"solid", {food = 0.2},"Нагетсы","<div><img src='https://i.ibb.co/2374SFZ/image.png' alt ='image' /></div> С Сычуанским соусом",0.3},
pizzaananas = {"solid", {food = 0.3},"Пицца с ананасами","<div><img src='https://i.ibb.co/F5QQsr7/image.png' alt ='image' /></div> Кто вообще такое ест?!",0.6},
pizza4 = {"solid", {food = 0.3},"Пицца 4 сыра","<div><img src='https://i.ibb.co/NNB9jtG/4.png' alt ='image' /></div> Больше сыра!",0.6},
cheasesnek = {"solid", {food = 0.15},"Сырная закуска","<div><img src='https://i.ibb.co/GHf7XQN/image.png' alt ='image' /></div> Для посиделок с вином.",0.3},
yogurt = {"solid", {food = 0.1},"Йогурт","<div><img src='https://i.ibb.co/FgRvBZN/image.png' alt ='image' /></div> Полезно и питательно",0.2},
chezar = {"solid", {food = 0.3},"Салат Цезарь","<div><img src='https://i.ibb.co/3Wwvx7D/image.png' alt ='image' /></div> Без лишних слов.",0.4},
grecheskii = {"solid", {food = 0.3},"Салат Греческий","<div><img src='https://i.ibb.co/HCw9qdx/image.png' alt ='image' /></div> Гастрономическое путешествие.",0.4},
fri = {"solid", {food = 0.2},"Картошка Фри","<div><img src='https://i.ibb.co/zXMRKvP/image.png' alt ='image' /></div> С сырным соусом.",0.2},
plombir = {"solid", {food = 0.1},"Пломбир","<div><img src='https://i.ibb.co/K5Fy8NZ/image.png' alt ='image' /></div> Вкус детства.", 0.1},
plombirbrown = {"solid", {food = 0.1},"Шоколадное мороженое","<div><img src='https://i.ibb.co/Tb7cRdc/image.png' alt ='image' /></div> И никакого расизма.", 0.1},
plombiryellow = {"solid", {food = 0.1},"Банановое мороженое","<div><img src='https://i.ibb.co/9mPS9GP/image.png' alt ='image' /></div> Очень вкусно.", 0.1},
plombirgreen = {"solid", {food = 0.1},"Фисташковое мороженое","<div><img src='https://i.ibb.co/gDfyvzK/image.png' alt ='image' /></div> Лидер продаж.", 0.1},
plombirextra = {"solid", {food = 0.1},"Мороженое Экстра","<div><img src='https://i.ibb.co/mFxgqx5/image.png' alt ='image' /></div> Сахарная бомба.", 0.1},


orange = {"solid", {food = 0.05, water = 0.05},"Апельсин","<div><img src='https://i.ibb.co/TTLrKNX/image.png' alt ='image' /></div> ",0.1},
apple = {"solid", {food = 0.05, water = 0.05},"Яблоко","<div><img src='https://i.ibb.co/x7SxZNN/image.png' alt ='image' /></div> ",0.1},
banana = {"solid", {food = 0.05, water = 0.05},"Банан","<div><img src='https://i.ibb.co/RS7Lfd4/image.png' alt ='image' /></div> ",0.1},
pears = {"solid", {food = 0.05, water = 0.05},"Груша","<div><img src='https://i.ibb.co/47q25GD/image.png' alt ='image' /></div> ",0.1},
grape = {"solid", {food = 0.05, water = 0.05},"Виноград","<div><img src='https://i.ibb.co/9sv8K7Y/image.png' alt ='image' /></div> ",0.1},
pineapple = {"solid", {food = 0.05, water = 0.05},"Ананас","<div><img src='https://i.ibb.co/JcjQsdm/image.png' alt ='image' /></div> ",0.3},
potato = {"solid", {food = 0.05, water = 0.05},"Картофель","<div><img src='https://i.ibb.co/CtH1Sj6/image.png' alt ='image' /></div> ",0.1},
carrot = {"solid", {food = 0.05, water = 0.05},"Морковь","<div><img src='https://i.ibb.co/sPSmRs5/image.png' alt ='image' /></div> ",0.1},
kale = {"solid", {food = 0.05, water = 0.05},"Капуста","<div><img src='https://i.ibb.co/p1ZjxWW/image.png' alt ='image' /></div> ",0.3},
mashrooms = {"solid", {food = 0.05, water = 0.05},"Грибы","<div><img src='https://i.ibb.co/744mS77/image.png' alt ='image' /></div> ",0.1},
barrys = {"solid", {food = 0.05, water = 0.05},"Ягоды","<div><img src='https://i.ibb.co/xSSJQw8/image.png' alt ='image' /></div> ",0.1},

  -- drugs
pills = {"solid", {health = 15}, "Таблетки","<div><img src='https://i.ibb.co/b3CghyS/image.png' alt ='image' /></div> Медицина творит чудеса.", 0.1},
  
weed = {"drug",{food = -0.1, water = -0.1, health = 5},"Конопля", "<div><img src='https://i.ibb.co/tC5JRw3/image.png' alt ='image' /></div> ", 0.05},  -- no choices
lsd = {"drug",{food = 0.15, water = -0.05, health = 5},"LSD","<div><img src='https://i.ibb.co/C6CD75f/image.png' alt ='image' /></div> ",0.05},
Legalweed = {"drug",{food = -0.1, water = -0.1, health = 5},"Марихуана","<div><img src='https://i.ibb.co/GQqN6S0/image.png' alt ='image' /></div> Только по рецепту врача.",0.01},
coca = {"drug",{food = 0.15, water = -0.05, health = 5},"Кокаин", "<div><img src='https://i.ibb.co/xJBhXhJ/image.png' alt ='image' /></div> ",0.05},
}

return cfg
