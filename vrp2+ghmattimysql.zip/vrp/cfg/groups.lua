
local cfg = {}

-- define each group with a set of permissions
-- _config property:
--- title (optional): group display name
--- gtype (optional): used to have only one group with the same gtype per player (example: a job gtype to only have one job)
--- onspawn (optional): function(user) (called when the character spawn with the group)
--- onjoin (optional): function(user) (called when the character join the group)
--- onleave (optional): function(user) (called when the character leave the group)

function police_init(user)
  local weapons = {}
  weapons["WEAPON_STUNGUN"] = {ammo=1000}
  weapons["WEAPON_COMBATPISTOL"] = {ammo=50}
  weapons["WEAPON_NIGHTSTICK"] = {ammo=0}
  weapons["WEAPON_FLASHLIGHT"] = {ammo=0}
  
  vRP.EXT.PlayerState.remote._giveWeapons(user.source,weapons,true)
  vRP.EXT.Police.remote._setCop(user.source,true)
end

function police_onjoin(user)
  police_init(user)
end

function police_onleave(user)
  vRP.EXT.PlayerState.remote._giveWeapons(user.source,{},true)
  vRP.EXT.Police.remote._setCop(user.source,false)
  vRP.EXT.PlayerState.remote._setArmour(user.source,0)
  user:removeCloak()
end

function police_onspawn(user)
  police_init(user)
end

cfg.groups = {
  ["superadmin"] = {
    _config = {onspawn = function(user) vRP.EXT.Base.remote._notify(user.source, "You are superadmin.") end},
    "player.group.add",
    "player.group.remove",
    "player.givemoney",
    "player.giveitem",
	
  },
  ["admin"] = {
  "player.group.add",
    "player.group.remove",
    "player.givemoney",
    "player.giveitem",
    "admin.tickets",
    "admin.announce",
    "player.list",
    "player.whitelist",
    "player.unwhitelist",
    "player.kick",
    "player.ban",
    "player.unban",
    "player.noclip",
    "player.custom_emote",
    "player.custom_model",
    "player.custom_sound",
    "player.display_custom",
    "player.coords",
    "player.tptome",
	"custom.custom",
    "player.tpto"
  },
  ["Bris"] = {
    "admin.tickets",
    "admin.announce",
    "player.list",
    "player.group.add",
    "player.group.remove",
    "player.noclip",
   -- "player.custom_emote",
	"player.custom_model",
   -- "player.custom_sound",
    --"player.display_custom",
    "player.coords",
    "player.tptome",
	"player.givemoney",
    "player.giveitem",
	"player.kick",
    "player.tpto",
	"custom.custom",
  },
  ["moder"] = {
    "admin.tickets",
	"player.kick",
    "admin.announce",
	"player.group.remove",
    "player.list",
    "player.whitelist",
    "player.noclip",
	"player.ban",
    "player.custom_emote",
    "player.display_custom",
    "player.coords",
    "player.tptome",
	"custom.custom",
    "player.tpto"
  },
  ["god"] = {
    "admin.god" -- reset survivals/health periodically
  },
  ["skin"] = {
    "player.custom_model",
  },
  ["vip"] = {
    "vip.vip",
  },
  ["user"] = {
    "player.phone",
    "player.calladmin",
	"player.coords",
	"police.askid",
	"vip.vip",
    "player.store_weapons",
    "police.seizable" -- can be seized
  },
  ["police"] = {
    _config = {
      title = "Police",
      gtype = "job",
      onjoin = police_onjoin,
      onspawn = police_onspawn,
      onleave = police_onleave
    },
    "police.menu",
    "police.askid",
    "police.cloakroom",
    "police.pc",
    "police.handcuff",
   -- "police.drag",
    "police.putinveh",
    "police.getoutveh",
    "police.check",
    "police.service",
    "police.wanted",
    "police.seize",
    "police.jail",
    "police.fine",
    "police.announce",
    "police.vehicle",
    "police.chest_seized",
    "player.store_weapons",
	"mission.police.patrol",
	"emergency.revive",
    "-police.seizable" -- negative permission, police can't seize itself, even if another group add the permission
--    "mission.paycheck.police" -- basic mission
  },
    ["sheriff"] = {
    _config = {
      title = "Sheriff",
      gtype = "job",
      onjoin = police_onjoin,
      onspawn = police_onspawn,
      onleave = police_onleave
    },
    "police.menu",
    "police.askid",
    "police.cloakroom",
    "police.pc",
    "police.handcuff",
   -- "police.drag",
    "police.putinveh",
    "police.getoutveh",
    "police.check",
    "police.service",
    "police.wanted",
    "police.seize",
    "police.jail",
    "police.fine",
    "police.announce",
    "police.vehicle",
    "police.chest_seized",
    "player.store_weapons",
	"mission.sheriff.patrol",
	"emergency.revive",
    "-police.seizable" -- negative permission, police can't seize itself, even if another group add the permission
--    "mission.paycheck.police" -- basic mission
  },
  ["emergency"] = {
    _config = {
      title = "Emergency",
      gtype = "job"
    },
    "emergency.revive",
    "emergency.shop",
    "emergency.service",
    "emergency.vehicle",
	"emergency.surg",
	"mission.delivery.pills",
    "emergency.cloakroom"
  },
  ["repair"] = {
    _config = {
      title = "Repair",
      gtype = "job"
    },
    "vehicle.repair",
    "vehicle.replace",
    "repair.service",
	"mission.repair",
	"mission.repair_1",
	"repair.cloakroom",
    "mission.repair",
    "mission.repair_1",
  },
  ["taxi"] = {
    _config = {
      title = "Таксист",
      gtype = "freelance"
    },
    "taxi.service",
    "taxi.vehicle"
  },
  ["post"] = {
    _config = {
      title = "Почтальон",
      gtype = "ch_job"
    },
    "mission.delivery.post",
    
  },
  ["food"] = {
    _config = {
      title = "Доставщик еды",
      gtype = "ch_job"
    },
    "mission.delivery.food",
    
  },
  ["tune"] = {
    _config = {
      title = "Тюнинг",
      
    },
    "tune.tune",
	"custom1.custom1"
    
  },
  ["police_job"] = {
    _config = {
      title = "Полиция",
      gtype = "ch_job"
    },
	"emergency.revive",
    "ch.police",
    
  },
    ["sheriff_job"] = {
    _config = {
      title = "Шериф",
      gtype = "ch_job"
    },
	"emergency.revive",
    "ch.sheriff",
    
  },
  ["emergency_job"] = {
    _config = {
      title = "Медики",
      gtype = "ch_job"
    },
	"emergency.revive",
    "ch.emerg",
    
  },
  ["repair_job"] = {
    _config = {
      title = "Механики",
      gtype = "ch_job"
    },
	
    "ch.repair",
    
  },
  
  ["biker"] = {
    _config = {
      title = "Байкеры",
    gtype = "ch_job"
    },
	"biker.biker",
	"mission.delivery.coca",
	"guns.guns"
	
  },
  ["ballas"] = {
    _config = {
      title = "Балласы",
    gtype = "ch_job"
    },
	"ballas.ballas",
	"mission.delivery.weed",
	"guns.guns",
	"custom1.custom1"
	
  },
  ["green"] = {
    _config = {
      title = "Фэмилис",
    gtype = "ch_job"
    },
	"green.green",
	"mission.delivery.weed",
	"guns.guns",
	"custom1.custom1"
	
  },
  ["mafia"] = {
    _config = {
      title = "Мафия",
    gtype = "ch_job"
    },
	"mission.delivery.lsd",
	"mafia.mafia",
	"guns.guns"
	
  },
  
  ["vagos"] = {
    _config = {
      title = "Вагосы",
    gtype = "ch_job"
    },
	"mission.delivery.coca",
	"vagos.vagos",
	"guns.guns",
	"custom1.custom1"
	
  },
  
  
  ["Noogle"] = {
    _config = {
      title = "Noogle",
      
    },
	"Noogle.Noogle"
  },
  
  ["MacroSoft"] = {
    _config = {
      title = "MacroSoft",
      
    },
	"MacroSoft.MacroSoft"
  },
  
  ["YouCube"] = {
    _config = {
      title = "YouCube",
      
    },
	"YouCube.YouCube"
  },
  
  ["LanFlix"] = {
    _config = {
      title = "LanFlix",
      
    },
	"LanFlix.LanFlix"
  },
  
  ["PonrBuh"] = {
    _config = {
      title = "PonrBuh",
      
    },
	"PonrBuh.PonrBuh"
  },
  
  ["Odnokyrsniki"] = {
    _config = {
      title = "Odnokyrsniki",
      
    },
	"Odnokyrsniki.Odnokyrsniki"
  },
  
  ["Somy"] = {
    _config = {
      title = "Somy",
      
    },
	"Somy.Somy"
  },
  
  ["FiveN"] = {
    _config = {
      title = "FiveN",
      
    },
	"FiveN.FiveN"
  },
  
  ["AmazingAndCorp"] = {
    _config = {
      title = "AmazingAndCorp",
      
    },
	"AmazingAndCorp.AmazingAndCorp"
  },
  
  
  ["weed"] = {
  _config = {
  title = "weed",
  gtype = "narco",
  },
  "mission.delivery.weed"
  },
  
  ["lsd"] = {
  _config = {
  title = "lsd",
  gtype = "narco"
  },
  "mission.delivery.lsd"
  },
  
  ["coca"] = {
  _config = {
  title = "coca",
  gtype = "narco"
  },
  "mission.delivery.coca"
  },
  ["citizen"] = {
    _config = {
      title = "Не на смене",
      gtype = "job"
    }
  },
  ["noJob"] = {
    _config = {
      title = "Безработный",
      gtype = "ch_job"
    }
  },
  ["noJob_taxi"] = {
    _config = {
      title = "Уволиться с такси",
      gtype = "freelance"
    }
  }
}

-- groups are added dynamically using the API or the menu, but you can add group when a character is loaded here
-- groups for everyone
cfg.default_groups = {
  "user"
}

-- groups per user
-- map of user id => list of groups
cfg.users = {
  [1] = { -- give superadmin and admin group to the first created user in the database
    "superadmin",
    "admin"
  }
}

-- group selectors
-- _config
--- x,y,z, map_entity, permissions (optional)
---- map_entity: {ent,cfg} will fill cfg.title, cfg.pos

cfg.selectors = {
  ["Работа"] = { 
    _config = {x = -268.363739013672, y = -957.255126953125, z = 31.22313880920410, map_entity = {"PoI", {blip_id = 351, blip_color = 47, marker_id = 1}}},
    "taxi",
    
    "emergency_job",
    "repair_job",
	"food",
	"post",
	"noJob_taxi",
    "noJob"
  },
  ["Работы"] = { 
    _config = {x = -1038.193359375, y = -2742.2998046875, z = 20.16928100586, map_entity = {"PoI", {blip_id = 351, blip_color = 47, marker_id = 1}}},
    "taxi",
    
    "emergency_job",
    "repair_job",
	"food",
	"post",
	"noJob_taxi",
    "noJob"
  },
 
  ["Смена Полицейского"] = {
    _config = {x = 440.57653808594,y = -975.87060546875, z = 30.689599990845, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.police"}},
    "police",
    "citizen"
	
  },
  ["Смена_Шерифа"] = { 
    _config = {x = 1853.4654541016,y = 3691.5153808594, z = 34.286655426026, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.sheriff"}},
    "sheriff",
   "citizen"
	
 },
   ["Смена Шерифа"] = { 
    _config = {x = -450.21850585938,y = 6011.30078125, z = 31.71633720398, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.sheriff"}},
    "sheriff",
   "citizen"
	
 },
  ["Механик"] = {
    _config = {x = 1116.1137695312,y = -3161.0187988282, z = -36.870491027832, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.repair"}},
    "repair",
    "citizen"
  },
  ["Смена Механика"] = {
    _config = {x = 471.76037597656,y = -1309.5825195313, z = 29.227674484253, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.repair"}},
    "repair",
    "citizen"
  },
  ["Смена_Механика"] = {
    _config = {x = 1186.6040039062,y = 2636.6059570312, z = 38.40187072754, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.repair"}},
    "repair",
    "citizen"
  },
  ["Смена_Врача"] = {
    _config = {x=267.50997924805,y=-1361.7902832031,z=24.537790298462, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.emerg"}},
    "emergency",
    "citizen"
	
  },
  ["Смена_Врача_"] = {
    _config = {x=1826.5498046875,y=3687.2534179688,z=34.271030426026, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.emerg"}},
    "emergency",
    "citizen"
	
  },
    ["_Смена_Врача_"] = {  
    _config = {x=-264.7541809082,y=6314.041015625,z=32.436374664306, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.emerg"}},
    "emergency",
    "citizen"
	
  },
  ["Смена Врача"] = {
    _config = {x=339.40908813476,y=-581.26727294922,z=28.791471481324, map_entity = {"PoI", { marker_id = 1}}, permissions = {"ch.emerg"}},
    "emergency",
    "citizen"
	
  }
}

-- identity display gtypes
-- used to display gtype groups in the identity
-- map of gtype => title
cfg.identity_gtypes = {
  job = "Job"
}

-- count display

cfg.count_display_interval = 15 -- seconds

cfg.count_display_css = [[
.div_group_count_display{
  position: absolute;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: row;
  padding: 2px;
  padding-right: 5px;
}

.div_group_count_display > div{
  padding-left: 7px;
  color: white;
  font-weight: bold;
  line-height: 22px;
}

.div_group_count_display > div > img{
  margin-right: 2px;
  vertical-align: bottom;
}
]]

-- list of {permission, img_src}
cfg.count_display_permissions = {
 -- {"!group.user", "https://i.imgur.com/tQ2VHAi.png"},
 -- {"!group.admin", "https://i.imgur.com/cpSYyN0.png"},
 -- {"!group.police", "https://i.imgur.com/dygLDfC.png"},
  {"!group.emergency", "https://i.imgur.com/K5lXutO.png"},
  {"!group.repair", "https://i.imgur.com/QEjFgzM.png"},
  {"!group.taxi", "https://i.imgur.com/yY4yrZN.png"}
}

return cfg