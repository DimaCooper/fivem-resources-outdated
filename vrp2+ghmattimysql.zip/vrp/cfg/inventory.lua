
local cfg = {}

cfg.inventory_weight_per_strength = 4 -- weight for an user inventory per strength level (no unit, but thinking in "kg" is a good norm)

cfg.lose_inventory_on_death = true

-- list of static chest types (map of name => {.title,.map_entity,.weight, .permissions (optional)})
-- map_entity: {ent,cfg} will fill cfg.pos, cfg.title
-- static chests are local to the server
cfg.static_chest_types = {
  ["police_seized"] = {
    title = "Seized chest",
    map_entity = {"PoI", {marker_id = 1}},
    weight = 500,
    permissions = {"police.chest_seized"}
  },
  
  ["PDchest"] = { -- example of a static chest
    title = "Хранилище улик",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"police.pc"},
    weight = 500
  }, 
  ["PDchest_2"] = { -- example of a static chest
    title = "Мед. хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"police.pc"},
    weight = 500
  },
  ["PDchest_3"] = { -- example of a static chest
    title = "Холодильник",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"police.pc"},
    weight = 500
  },
  ["SDchest"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"police.pc"},
    weight = 500
  },
    ["PalDchest"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"police.pc"},
    weight = 500
  },
      ["PalDchest_2"] = { -- example of a static chest
    title = "Хранилище улик",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"police.pc"},
    weight = 500
  },
  ["MDchest"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"emergency.surg"},
    weight = 500
  },
    ["MDchest2"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"emergency.surg"},
    weight = 500
  },
      ["MDchest3"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"emergency.surg"},
    weight = 500
  },
        ["MDchest4"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"emergency.surg"},
    weight = 500
  },
  ["Mechchest"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"repair.service"},
    weight = 500
  },
  ["Ballas"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"Ballas.for.life"},
    weight = 500
  },
  ["Bikers"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"biker.biker"},
    weight = 500
  },
  ["Vagos"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"vagos.vagos"},
    weight = 500
  },
  ["FIB"] = { -- example of a static chest  
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"FIB.FIB"},
    weight = 500
  },
  ["Bikers_irland"] = { -- example of a static chest
    title = "Хранилище",
	map_entity = {"PoI", { marker_id = 1}},
    permissions = {"biker.biker"},
    weight = 500
  },
}

-- list of static chest points
cfg.static_chests = {
  --{"police_seized", 452.44293212891,-980.17449951172,30.689586639404},
  {"PDchest", 480.93743896484,-985.24926757812,24.914691925048},
  {"PDchest_2", 436.17379760742,-974.02380371094,26.668552398682},
  {"PDchest_3", 464.7395324707,-990.0219116211,30.689641952514},
  {"SDchest", 1850.3342285156,3685.7026367188,34.286598205566},
  {"PalDchest", -433.18838500976,6001.8178710938,31.716205596924},
  {"PalDchest_2", -441.4006652832,5987.1489257812,31.716192245484},
  {"MDchest", 238.09301757812,-1359.3404541016,39.534378051758},
  {"MDchest2", -255.72361755372,6319.75390625,32.433517456054},
  {"MDchest3", 335.28009033204,-585.44299316406,28.791458129882},
  {"Mechchest", 474.65408325196,-1309.3166503906,29.206623077392},
  {"Ballas", 78.272407531738,-1964.5657958984,21.117897033692},
  {"Bikers", 977.03045654296,-104.02365875244,74.845184326172},
  {"Vagos", 353.29516601562,-2055.080078125,22.245290756226},
  {"FIB",155.33610534668,-742.84252929688,258.15188598632},
  {"Bikers_irland",1111.1114501954,-3147.1247558594,-37.062767028808 },
  {"MDchest4", 1825.1994628906,3687.4943847656,34.271030426026},
}

return cfg
