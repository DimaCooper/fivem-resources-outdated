local cfg = {}

cfg.warp_delay = 3 -- seconds, delay before being able to trigger another warp (prevent loop)

-- default warp map entities by mode
-- map of mode => {ent,cfg} (will fill cfg.pos)
cfg.default_map_entities = {
 -- [0] = {"Warp", {color = {255,0,0,125}}},
 [1] = {"Warp", {color = {50, 207, 120, 125}}},
 -- [2] = {"Warp", {color = {0,0,255,125}}}
}

-- list of warps {pos, target, cfg}
-- pos: {x,y,z}
-- target: {x,y,z}
-- cfg: (optional)
--- mode: (optional) integer, 0: player warp, 1: vehicle warp, 2: both (default: 0)
--- permissions: (optional)
--- map_entity: (optional) replace the default map entity
cfg.warps = {
  -- A to B
 -- {{-542.68975830078,-238.42790222168,36.749378204346},{-535.21960449219,-253.25895690918,35.796085357666},{mode = 0}},
  -- B to A
 -- {{-535.21960449219,-253.25895690918,35.796085357666},{-542.68975830078,-238.42790222168,36.749378204346},{mode = 0}},
  -- C to D (with vehicle only)
  {{2522.3002929688,4112.7646484375,38.630760192872},{1109.0070800782,-3160.3210449218,-37.518604278564},{mode = 1}},
  -- D to C (with vehicle only)
 {{1109.0070800782,-3160.3210449218,-37.518604278564},{2522.3002929688,4112.7646484375,38.630760192872},{mode = 1}}
}

return cfg
