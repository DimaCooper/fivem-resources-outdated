
local cfg = {}

-- start wallet/bank values
cfg.open_wallet = 2000
cfg.open_bank = 4000

cfg.lose_wallet_on_death = true

cfg.money_display = true

-- money display css
cfg.display_css = [[
.div_money{
  position: absolute;
  top: 2.9vh;
  right: 1.0vw;
  font-size: 1.2em;
  font-weight: bold;
  color: white;
  text-shadow: 2px 2px 1px rgba(0, 0, 0, 0.80);
}

.div_money .symbol{
  font-size: 1.0em;
  color: #00ac51; 
}
]]

return cfg
