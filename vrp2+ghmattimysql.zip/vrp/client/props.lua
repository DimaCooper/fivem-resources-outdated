
if not vRP.modules.props then return end

-- this module define some police tools and functions
local Props = class("Props", vRP.Extension)

function Props:lockpickVehicle(wait,any)
		local pos = GetEntityCoords(GetPlayerPed(-1))
		local entityWorld = GetOffsetFromEntityInWorldCoords(GetPlayerPed(-1), 0.0, 20.0, 0.0)

		local rayHandle = CastRayPointToPoint(pos.x, pos.y, pos.z, entityWorld.x, entityWorld.y, entityWorld.z, 10, GetPlayerPed(-1), 0)
		local _, _, _, _, vehicleHandle = GetRaycastResult(rayHandle)
		if DoesEntityExist(vehicleHandle) then
		  if GetVehicleDoorsLockedForPlayer(vehicleHandle,PlayerId()) or any then
			local prevObj = GetClosestObjectOfType(pos.x, pos.y, pos.z, 10.0, GetHashKey("prop_weld_torch"), false, true, true)
			if(IsEntityAnObject(prevObj)) then
				SetEntityAsMissionEntity(prevObj)
				DeleteObject(prevObj)
			end
			
			StartVehicleAlarm(vehicleHandle)
			TaskStartScenarioInPlace(GetPlayerPed(-1), "WORLD_HUMAN_WELDING", 0, true)

			Citizen.Wait(wait*1000)
			SetVehicleDoorsLocked(vehicleHandle, 1)
			for i = 1,64 do 
				SetVehicleDoorsLockedForPlayer(vehicleHandle, GetPlayerFromServerId(i), false)
			end 
			ClearPedTasksImmediately(GetPlayerPed(-1))
			
			vRP.EXT.Base:notify("Success") -- lang.lockpick.toofar()) -- lang.lockpick.success()
			
		  else
			vRP.EXT.Base:notify("Unlocked") -- lang.lockpick.toofar()
		  end
		else
			vRP.EXT.Base:notify("Not close enough") -- lang.lockpick.toofar()
	end
end

function Props:fixNearestVehicleEngine(radius)
  local veh = self:getNearestVehicle(radius)
  if IsEntityAVehicle(veh) then
    SetVehicleEngineHealth(veh, 1000)
  end
end
function Props:cleanNearestVehicle(radius)
  local veh = self:getNearestVehicle(radius)
  if IsEntityAVehicle(veh) then
  	SetVehicleDirtLevel(veh, 0.0)
	SetVehicleUndriveable(veh, false)
    
  end
end
--Add Props

function Props:setPropBarrier(prop)
    local ped = GetPlayerPed(-1)
    x, y, z = table.unpack(GetEntityCoords(ped, true))
	h = GetEntityHeading(ped)
	ox, oy, oz = table.unpack(GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0))
	prop = GetHashKey(prop)
	local heading = GetEntityHeading(GetPlayerPed(-1))

    RequestModel(prop)
    while not HasModelLoaded(prop) do
      Citizen.Wait(1)
    end

    local object = CreateObject(prop, ox, oy, oz, true, true, false)
    PlaceObjectOnGroundProperly(object)
    SetEntityHeading(object,heading)
    FreezeEntityPosition(object, true)
end

function Props:setPropBbox(prop)
    local ped = GetPlayerPed(-1)
    x, y, z = table.unpack(GetEntityCoords(ped, true))
	h = GetEntityHeading(ped)
	ox, oy, oz = table.unpack(GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0))
	prop = GetHashKey(prop)
	local heading = GetEntityHeading(GetPlayerPed(-1))

    RequestModel(prop)
    while not HasModelLoaded(prop) do
      Citizen.Wait(1)
    end

    local object = CreateObject(prop, ox, oy, oz, true, true, false)
	self.remote._setAudio()
    PlaceObjectOnGroundProperly(object)
    SetEntityHeading(object,heading)
    FreezeEntityPosition(object, false)	
end

function Props:setProp(prop)
    local ped = GetPlayerPed(-1)
    x, y, z = table.unpack(GetEntityCoords(ped, true))
	h = GetEntityHeading(ped)
	ox, oy, oz = table.unpack(GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0))
	prop = GetHashKey(prop)
	local heading = GetEntityHeading(GetPlayerPed(-1))

    RequestModel(prop)
    while not HasModelLoaded(prop) do
      Citizen.Wait(1)
    end

    local object = CreateObject(prop, ox, oy, oz, true, true, false)
    PlaceObjectOnGroundProperly(object)
    SetEntityHeading(object,heading)
    FreezeEntityPosition(object, false)	
end

function Props:setPropStat(prop)
    local ped = GetPlayerPed(-1)
    x, y, z = table.unpack(GetEntityCoords(ped, true))
	h = GetEntityHeading(ped)
	ox, oy, oz = table.unpack(GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0))
	prop = GetHashKey(prop)
	local heading = GetEntityHeading(GetPlayerPed(-1))

    RequestModel(prop)
    while not HasModelLoaded(prop) do
      Citizen.Wait(1)
    end

    local object = CreateObject(prop, ox, oy, oz, true, true, false)
    PlaceObjectOnGroundProperly(object)
    SetEntityHeading(object,heading)
    FreezeEntityPosition(object, true)	
end

function Props:setPropFire(prop)
    local ped = GetPlayerPed(-1)
    x, y, z = table.unpack(GetEntityCoords(ped, true))
	h = GetEntityHeading(ped)
	ox, oy, oz = table.unpack(GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, -1.53))
	prop = GetHashKey(prop)
	local heading = GetEntityHeading(GetPlayerPed(-1))

    RequestModel(prop)
    while not HasModelLoaded(prop) do
      Citizen.Wait(1)
    end

    local object = CreateObject(prop, ox, oy, oz, true, false, true)
	SetEntityHeading(object, heading)
  --  PlaceObjectOnGroundProperly(object)
   	
end


function Props:closeProp(prop)
    local ped = GetPlayerPed(-1)
    x, y, z = table.unpack(GetEntityCoords(ped, true))
	ox, oy, oz = table.unpack(GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, -2.0))
    if DoesObjectOfTypeExistAtCoords(ox, oy, oz, 0.9, GetHashKey(prop), true) then
	  return true
	else 
	  return false
	end
end

function Props:removeProp(prop)
    local ped = GetPlayerPed(-1)
    x, y, z = table.unpack(GetEntityCoords(ped, true))
	ox, oy, oz = table.unpack(GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0))
    if DoesObjectOfTypeExistAtCoords(ox, oy, oz, 0.9, GetHashKey(prop), true) then
        prop = GetClosestObjectOfType(ox, oy, oz, 0.9, GetHashKey(prop), false, false, false)
        SetEntityAsMissionEntity(prop, true, true)
        DeleteObject(prop)
		self.remote._stopAudio()
	end
end



-- TUNNEL
Props.tunnel = {}

-- PROPS
Props.tunnel.setProp = Props.setProp
Props.tunnel.setPropStat = Props.setPropStat
Props.tunnel.setPropBbox = Props.setPropBbox
Props.tunnel.setPropFire = Props.setPropFire
Props.tunnel.closeProp = Props.closeProp	
Props.tunnel.removeProp = Props.removeProp
Props.tunnel.putplate = Props.putplate
Props.tunnel.cleanNearestVehicle = Props.cleanNearestVehicle
Props.tunnel.fixNearestVehicleEngine = Props.fixNearestVehicleEngine
Props.tunnel.removeplate = Props.removeplate

vRP:registerExtension(Props)
