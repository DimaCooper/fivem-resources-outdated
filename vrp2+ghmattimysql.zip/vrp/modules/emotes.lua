if not vRP.modules.emotes then return end

-- this module define the emotes menu

local lang = vRP.lang

local ActionDelay = module("vrp", "lib/ActionDelay")

local Emotes = class("Emotes", vRP.Extension)

-- SUBCLASS

Emotes.User = class("User")

function Emotes.User:__construct()
  self.emotes_action = ActionDelay()
end

-- METHODS

function Emotes:__construct()
  vRP.Extension.__construct(self)

  self.cfg = module("vrp", "cfg/emotes")

  self:log(#self.cfg.works.." emotes from config")
  self:log(#self.cfg.dance.." emotes from config")

  local function m_works(menu, value)
    local user = menu.user

    local emote = self.cfg.works[value]
    if user.emotes_action:perform(emote[5] or 0) then
      vRP.EXT.Base.remote._playAnim(user.source,emote[2],emote[3],emote[4])
    else
      vRP.EXT.Base.remote._notify(user.source, lang.common.must_wait({user.emotes_action:remaining()}))
    end
  end
  
  local function m_dance(menu, value)
    local user = menu.user

    local emote_dance = self.cfg.dance[value]
    if user.emotes_action:perform(emote_dance[5] or 0) then
      vRP.EXT.Base.remote._playAnim(user.source,emote_dance[2],emote_dance[3],emote_dance[4])
    else
      vRP.EXT.Base.remote._notify(user.source, lang.common.must_wait({user.emotes_action:remaining()}))
    end
  end
  
    local function m_positions(menu, value)
    local user = menu.user

    local emote_positions = self.cfg.positions[value]
    if user.emotes_action:perform(emote_positions[5] or 0) then
      vRP.EXT.Base.remote._playAnim(user.source,emote_positions[2],emote_positions[3],emote_positions[4])
    else
      vRP.EXT.Base.remote._notify(user.source, lang.common.must_wait({user.emotes_action:remaining()}))
    end
  end
  
    local function m_sit(menu, value)
    local user = menu.user

    local emote_sit = self.cfg.sit[value]
    if user.emotes_action:perform(emote_sit[5] or 0) then
      vRP.EXT.Base.remote._playAnim(user.source,emote_sit[2],emote_sit[3],emote_sit[4])
    else
      vRP.EXT.Base.remote._notify(user.source, lang.common.must_wait({user.emotes_action:remaining()}))
    end
  end
  
      local function m_others(menu, value)
    local user = menu.user

    local emote_others = self.cfg.others[value]
    if user.emotes_action:perform(emote_others[5] or 0) then
      vRP.EXT.Base.remote._playAnim(user.source,emote_others[2],emote_others[3],emote_others[4])
    else
      vRP.EXT.Base.remote._notify(user.source, lang.common.must_wait({user.emotes_action:remaining()}))
    end
  end
  
        local function m_popul(menu, value)
    local user = menu.user

    local emote_popul = self.cfg.popul[value]
    if user.emotes_action:perform(emote_popul[5] or 0) then
      vRP.EXT.Base.remote._playAnim(user.source,emote_popul[2],emote_popul[3],emote_popul[4])
    else
      vRP.EXT.Base.remote._notify(user.source, lang.common.must_wait({user.emotes_action:remaining()}))
    end
  end
  
          local function m_sport(menu, value)
    local user = menu.user

    local emote_sport = self.cfg.sport[value]
    if user.emotes_action:perform(emote_sport[5] or 0) then
      vRP.EXT.Base.remote._playAnim(user.source,emote_sport[2],emote_sport[3],emote_sport[4])
    else
      vRP.EXT.Base.remote._notify(user.source, lang.common.must_wait({user.emotes_action:remaining()}))
    end
  end
            local function m_moutions(menu, value)
    local user = menu.user

    local emote_moutions = self.cfg.moutions[value]
    if user.emotes_action:perform(emote_moutions[5] or 0) then
      vRP.EXT.Base.remote._playAnim(user.source,emote_moutions[2],emote_moutions[3],emote_moutions[4])
    else
      vRP.EXT.Base.remote._notify(user.source, lang.common.must_wait({user.emotes_action:remaining()}))
    end
  end

  local function m_clear(menu)
    vRP.EXT.Base.remote._stopAnim(menu.user.source,true) -- upper
    vRP.EXT.Base.remote._stopAnim(menu.user.source,false) -- full
  end

  vRP.EXT.GUI:registerMenuBuilder("works", function(menu)
    menu.title = "Работы"
    menu.css.header_color = "rgba(57,46,92,0.80)"

    -- add emotes
    for i,emote in ipairs(self.cfg.works) do
      if menu.user:hasPermissions(emote.permissions or {}) then
        menu:addOption(emote[1], m_works, nil, i)
      end
    end
	

    -- add clear current emotes
    menu:addOption(lang.emotes.clear.title(), m_clear, lang.emotes.clear.description())
  end)
  
  vRP.EXT.GUI:registerMenuBuilder("dance", function(menu)
    menu.title = "Танцы"
    menu.css.header_color = "rgba(57,46,92,0.80)"

    -- add emotes
	
	for i,emote_dance in ipairs(self.cfg.dance) do
      if menu.user:hasPermissions(emote_dance.permissions or {}) then
        menu:addOption(emote_dance[1], m_dance, nil, i)
      end
    end

    -- add clear current emotes
    menu:addOption(lang.emotes.clear.title(), m_clear, lang.emotes.clear.description())
  end)
  
    vRP.EXT.GUI:registerMenuBuilder("positions", function(menu)
    menu.title = "Стойки"
    menu.css.header_color = "rgba(57,46,92,0.80)"

    -- add emotes
	
	for i,emote_positions in ipairs(self.cfg.positions) do
      if menu.user:hasPermissions(emote_positions.permissions or {}) then
        menu:addOption(emote_positions[1], m_positions, nil, i)
      end
    end

    -- add clear current emotes
    menu:addOption(lang.emotes.clear.title(), m_clear, lang.emotes.clear.description())
  end)
  
      vRP.EXT.GUI:registerMenuBuilder("sit", function(menu)
    menu.title = "Сесть/Лечь"
    menu.css.header_color = "rgba(57,46,92,0.80)"

    -- add emotes
	
	for i,emote_sit in ipairs(self.cfg.sit) do
      if menu.user:hasPermissions(emote_sit.permissions or {}) then
        menu:addOption(emote_sit[1], m_sit, nil, i)
      end
    end

    -- add clear current emotes
    menu:addOption(lang.emotes.clear.title(), m_clear, lang.emotes.clear.description())
  end)
  
        vRP.EXT.GUI:registerMenuBuilder("others", function(menu)
    menu.title = "Разное"
    menu.css.header_color = "rgba(57,46,92,0.80)"

    -- add emotes
	
	for i,emote_others in ipairs(self.cfg.others) do
      if menu.user:hasPermissions(emote_others.permissions or {}) then
        menu:addOption(emote_others[1], m_others, nil, i)
      end
    end

    -- add clear current emotes
    menu:addOption(lang.emotes.clear.title(), m_clear, lang.emotes.clear.description())
  end)
  
          vRP.EXT.GUI:registerMenuBuilder("popul", function(menu)
    menu.title = "Популярное"
    menu.css.header_color = "rgba(57,46,92,0.80)"

    -- add emotes
	
	for i,emote_popul in ipairs(self.cfg.popul) do
      if menu.user:hasPermissions(emote_popul.permissions or {}) then
        menu:addOption(emote_popul[1], m_popul, nil, i)
      end
    end

    -- add clear current emotes
    menu:addOption(lang.emotes.clear.title(), m_clear, lang.emotes.clear.description())
  end)
  
            vRP.EXT.GUI:registerMenuBuilder("sport", function(menu)
    menu.title = "Спорт"
    menu.css.header_color = "rgba(57,46,92,0.80)"

    -- add emotes
	
	for i,emote_sport in ipairs(self.cfg.sport) do
      if menu.user:hasPermissions(emote_sport.permissions or {}) then
        menu:addOption(emote_sport[1], m_sport, nil, i)
      end
    end

    -- add clear current emotes
    menu:addOption(lang.emotes.clear.title(), m_clear, lang.emotes.clear.description())
  end)
              vRP.EXT.GUI:registerMenuBuilder("moutions", function(menu)
    menu.title = "Жесты"
    menu.css.header_color = "rgba(57,46,92,0.80)"

    -- add emotes
	
	for i,emote_moutions in ipairs(self.cfg.moutions) do
      if menu.user:hasPermissions(emote_moutions.permissions or {}) then
        menu:addOption(emote_moutions[1], m_moutions, nil, i)
      end
    end

    -- add clear current emotes
    menu:addOption(lang.emotes.clear.title(), m_clear, lang.emotes.clear.description())
  end)

  vRP.EXT.GUI:registerMenuBuilder("main", function(menu)
    menu:addOption("Эмоции", function(menu)
      menu.user:openMenu("emotes")
    end)
  end)
      vRP.EXT.GUI:registerMenuBuilder("emotes", function(menu)
    menu:addOption("Популярное", function(menu)
      menu.user:openMenu("popul")
    end)
  end)
  vRP.EXT.GUI:registerMenuBuilder("emotes", function(menu)
    menu:addOption("Работы", function(menu)
      menu.user:openMenu("works")
    end)
  end)
    vRP.EXT.GUI:registerMenuBuilder("emotes", function(menu)
    menu:addOption("Жесты", function(menu)
      menu.user:openMenu("moutions")
    end)
  end)
    vRP.EXT.GUI:registerMenuBuilder("emotes", function(menu)
    menu:addOption("Сесть/Лечь", function(menu)
      menu.user:openMenu("sit")
    end)
  end)
    vRP.EXT.GUI:registerMenuBuilder("emotes", function(menu)
    menu:addOption("Стойки", function(menu)
      menu.user:openMenu("positions")
    end)
  end)
    vRP.EXT.GUI:registerMenuBuilder("emotes", function(menu)
    menu:addOption("Танцы", function(menu)
      menu.user:openMenu("dance")
    end)
  end)
  
    vRP.EXT.GUI:registerMenuBuilder("emotes", function(menu)
    menu:addOption("Разное", function(menu)
      menu.user:openMenu("others")
    end)
  end)

      vRP.EXT.GUI:registerMenuBuilder("emotes", function(menu)
    menu:addOption("Спорт", function(menu)
      menu.user:openMenu("sport")
    end)
  end)
end

-- add a new emote
-- see cfg/emotes.lua
function Emotes:add(config)
  table.insert(self.cfg.works, config)
  table.insert(self.cfg.dance, config)
  table.insert(self.cfg.positions, config)
  table.insert(self.cfg.sit, config)
  table.insert(self.cfg.others, config)
  table.insert(self.cfg.popul, config)
  table.insert(self.cfg.sport, config)
  table.insert(self.cfg.moutions, config)
end

vRP:registerExtension(Emotes)
