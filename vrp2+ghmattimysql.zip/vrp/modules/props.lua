if not vRP.modules.props then return end

local lang = vRP.lang
local htmlEntities = module("vrp", "lib/htmlEntities")

-- this module define some police tools and functions
local Props = class("Props", vRP.Extension)

-- SUBCLASS

Props.User = class("User")



local function define_items(self)
  
  
  local function m_buisness_noogle(menu)
    local user = menu.user
    
    if user:tryTakeItem("Noogle", 1) then -- take vest
      user:addGroup("Noogle")

      local namount = user:getItemAmount("Noogle")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  local function m_buisness_MacroSoft(menu)
    local user = menu.user
    
    if user:tryTakeItem("MacroSoft", 1) then -- take vest
      user:addGroup("MacroSoft")

      local namount = user:getItemAmount("MacroSoft")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  local function m_buisness_YouCube(menu)
    local user = menu.user
    
    if user:tryTakeItem("YouCube", 1) then -- take vest
      user:addGroup("YouCube")

      local namount = user:getItemAmount("YouCube")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  local function m_buisness_LanFlix(menu)
    local user = menu.user
    
    if user:tryTakeItem("LanFlix", 1) then -- take vest
      user:addGroup("LanFlix")

      local namount = user:getItemAmount("LanFlix")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  local function m_buisness_PonrBuh(menu)
    local user = menu.user
    
    if user:tryTakeItem("PonrBuh", 1) then -- take vest
      user:addGroup("PonrBuh")

      local namount = user:getItemAmount("PonrBuh")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  local function m_buisness_Odnokyrsniki(menu)
    local user = menu.user
    
    if user:tryTakeItem("Odnokyrsniki", 1) then -- take vest
      user:addGroup("Odnokyrsniki")

      local namount = user:getItemAmount("Odnokyrsniki")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  local function m_buisness_Somy(menu)
    local user = menu.user
    
    if user:tryTakeItem("Somy", 1) then -- take vest
      user:addGroup("Somy")

      local namount = user:getItemAmount("Somy")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  local function m_buisness_FiveN(menu)
    local user = menu.user
    
    if user:tryTakeItem("FiveN", 1) then -- take vest
      user:addGroup("FiveN")

      local namount = user:getItemAmount("FiveN")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  local function m_buisness_AmazingAndCorp(menu)
    local user = menu.user
    
    if user:tryTakeItem("AmazingAndCorp", 1) then -- take vest
      user:addGroup("AmazingAndCorp")

      local namount = user:getItemAmount("AmazingAndCorp")
      if namount > 0 then
        user:actualizeMenu()
      else
        user:closeMenu(menu)
      end
    end
  end
  
  


  local function m_scone(menu)
    local user = menu.user
    local prop = "prop_roadcone02b"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_fire(menu)
    local user = menu.user
    local prop = "prop_beach_fire"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setPropFire(user.source, prop)

    end
end

local function m_chair(menu)
    local user = menu.user
    local prop = "prop_chair_02"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_barrier(menu)
    local user = menu.user
    local prop = "prop_barrier_work05"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_worklight(menu)
    local user = menu.user
    local prop = "prop_worklight_03b"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_gazebo(menu)
    local user = menu.user
    local prop = "prop_gazebo_02"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_bbox(menu)
    local user = menu.user
    local prop = "prop_boombox_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
	
        self.remote.removeProp(user.source, prop)
		
    elseif not closeby then
        self.remote.setPropBbox(user.source, prop)
		

    end
end

local function m_sign1(menu)
    local user = menu.user
    local prop = "prop_06_sig1_m"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_sign2(menu)
    local user = menu.user
    local prop = "prop_06_sig1_n"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_sign3(menu)
    local user = menu.user
    local prop = "prop_06_sig1_0"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end


local function m_barrier2(menu)
    local user = menu.user
    local prop = "prop_barier_conc_02c"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_barrier21(menu)
    local user = menu.user
    local prop = "prop_barier_conc_02c"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setPropStat(user.source, prop)

    end
end

local function m_barrier3(menu)
    local user = menu.user
    local prop = "prop_barrier_work01a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end
local function m_barrier4(menu)
    local user = menu.user
    local prop = "prop_barrier_work04a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end
local function m_barrier5(menu)
    local user = menu.user
    local prop = "prop_barrier_work06a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_bbq1(menu)
    local user = menu.user
    local prop = "prop_bbq_4"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_bbq2(menu)
    local user = menu.user
    local prop = "prop_bbq_5"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_lilo1(menu)
    local user = menu.user
    local prop = "prop_beach_lilo_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_lilo2(menu)
    local user = menu.user
    local prop = "prop_beach_lilo_02"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_ring(menu)
    local user = menu.user
    local prop = "prop_beach_ring_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_parasol1(menu)
    local user = menu.user
    local prop = "prop_beach_parasol_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_ball1(menu)
    local user = menu.user
    local prop = "prop_beach_volball01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_ball2(menu)
    local user = menu.user
    local prop = "prop_beach_volball02"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_ball3(menu)
    local user = menu.user
    local prop = "prop_beachball_1"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_bong(menu)
    local user = menu.user
    local prop = "prop_bong_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_pin(menu)
    local user = menu.user
    local prop = "prop_bowling_pin"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_vedro(menu)
    local user = menu.user
    local prop = "prop_buck_spade_04"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_burger(menu)
    local user = menu.user
    local prop = "prop_burgerstand_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_bench(menu)
    local user = menu.user
    local prop = "prop_byard_bench01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_chair2(menu)
    local user = menu.user
    local prop = "prop_chair_01b"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_coffin(menu)
    local user = menu.user
    local prop = "prop_coffin_02b"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_dummy(menu)
    local user = menu.user
    local prop = "prop_dummy_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_fireex(menu)
    local user = menu.user
    local prop = "prop_fire_exting_1a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_flamingo(menu)
    local user = menu.user
    local prop = "prop_flamingo"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_flat(menu)
    local user = menu.user
    local prop = "prop_flattruck_01a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_gas(menu)
    local user = menu.user
    local prop = "prop_gascyl_03a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_gnome1(menu)
    local user = menu.user
    local prop = "prop_gnome1"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_gnome2(menu)
    local user = menu.user
    local prop = "prop_gnome2"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_gnome3(menu)
    local user = menu.user
    local prop = "prop_gnome3"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_target(menu)
    local user = menu.user
    local prop = "prop_range_target_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_patio(menu)
    local user = menu.user
    local prop = "prop_patio_lounger1"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_parasol2(menu)
    local user = menu.user
    local prop = "prop_parasol_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_box(menu)
    local user = menu.user
    local prop = "prop_mp_drug_pack_blue"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_stove(menu)
    local user = menu.user
    local prop = "prop_hobo_stove_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_tent(menu)
    local user = menu.user
    local prop = "prop_skid_tent_cloth"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_ball4(menu)
    local user = menu.user
    local prop = "prop_swiss_ball_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_telescope(menu)
    local user = menu.user
    local prop = "prop_t_telescope_01b"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_corpse(menu)
    local user = menu.user
    local prop = "prop_water_corpse_02"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_worklight3(menu)
    local user = menu.user
    local prop = "prop_worklight_04c"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant1(menu)
    local user = menu.user
    local prop = "prop_fbibombplant"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant2(menu)
    local user = menu.user
    local prop = "prop_fib_plant_01"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant3(menu)
    local user = menu.user
    local prop = "prop_peyote_highland_02"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant4(menu)
    local user = menu.user
    local prop = "prop_plant_int_01a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant5(menu)
    local user = menu.user
    local prop = "prop_plant_int_01b"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant6(menu)
    local user = menu.user
    local prop = "prop_plant_int_03a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant7(menu)
    local user = menu.user
    local prop = "prop_plant_int_02a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant8(menu)
    local user = menu.user
    local prop = "prop_plant_int_04a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant9(menu)
    local user = menu.user
    local prop = "prop_plant_int_04b"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant10(menu)
    local user = menu.user
    local prop = "prop_pot_plant_01a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end


local function m_plant12(menu)
    local user = menu.user
    local prop = "prop_pot_plant_05a"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end

local function m_plant13(menu)
    local user = menu.user
    local prop = "prop_pot_plant_05b"
    local closeby = self.remote.closeProp(user.source, prop)

    if closeby then
        self.remote.removeProp(user.source, prop)
    elseif not closeby then
        self.remote.setProp(user.source, prop)

    end
end




 --[[ local function m_cleanveh(menu)
    local user = menu.user

    -- anim and repair
    if user then
      vRP.EXT.Base.remote._playAnim(user.source,false,{task="CODE_HUMAN_POLICE_INVESTIGATE"},false)
      SetTimeout(15000, function()
        self.remote._cleanNearestVehicle(user.source,7)
        vRP.EXT.Base.remote._stopAnim(user.source,false)
      end)
    end
  end
    local function m_repaireng(menu)
    local user = menu.user

    -- anim and repair
    if user:tryTakeItem("engoil",1) then
      vRP.EXT.Base.remote._playAnim(user.source,false,{task="WORLD_HUMAN_WELDING"},false)
      SetTimeout(15000, function()
        self.remote._fixNearestVehicleEngine(user.source,7)
        vRP.EXT.Base.remote._stopAnim(user.source,false)
      end)
    end
  end]]



-- Deployable Items
  local function i_cleanveh(args, menu)
    menu:addOption("Помыть",m_cleanveh )
  end
  local function i_repaireng(args, menu)
    menu:addOption("Залить",m_repaireng )
  end

  local function i_buisness_noogle(args, menu)
    menu:addOption("Активировать", m_buisness_noogle)
  end
  local function i_buisness_MacroSoft(args, menu)
    menu:addOption("Активировать", m_buisness_MacroSoft)
  end
  local function i_buisness_YouCube(args, menu)
    menu:addOption("Активировать", m_buisness_YouCube)
  end
  local function i_buisness_LanFlix(args, menu)
    menu:addOption("Активировать", m_buisness_LanFlix)
  end
  local function i_buisness_PonrBuh(args, menu)
    menu:addOption("Активировать", m_buisness_PonrBuh)
  end
  local function i_buisness_Odnokyrsniki(args, menu)
    menu:addOption("Активировать", m_buisness_Odnokyrsniki)
  end
  local function i_buisness_Somy(args, menu)
    menu:addOption("Активировать", m_buisness_Somy)
  end
  local function i_buisness_FiveN(args, menu)
    menu:addOption("Активировать", m_buisness_FiveN)
  end
  local function i_buisness_AmazingAndCorp(args, menu)
    menu:addOption("Активировать", m_buisness_AmazingAndCorp)
  end
  
  

  local function i_scone(args, menu)
    menu:addOption("Использовать/Убрать", m_scone)
  end
  local function i_fire(args, menu)
    menu:addOption("Использовать/Убрать", m_fire)
  end
  local function i_chair(args, menu)
    menu:addOption("Использовать/Убрать", m_chair)
  end
  local function i_barrier(args, menu)
    menu:addOption("Использовать/Убрать", m_barrier)
  end 
  local function i_worklight(args, menu)
    menu:addOption("Использовать/Убрать", m_worklight)
  end
  local function i_gazebo(args, menu)
    menu:addOption("Использовать/Убрать", m_gazebo)
  end
  local function i_bbox(args, menu)
    menu:addOption("Использовать/Убрать", m_bbox)
  end
  local function i_sign1(args, menu)
    menu:addOption("Использовать/Убрать", m_sign1)
  end
  local function i_sign2(args, menu)
    menu:addOption("Использовать/Убрать", m_sign2)
  end
  local function i_sign3(args, menu)
    menu:addOption("Использовать/Убрать", m_sign3)
  end

  local function i_barrier2(args, menu)
    menu:addOption("Использовать/Убрать", m_barrier2)
  end
    local function i_barrier21(args, menu)
    menu:addOption("Использовать/Убрать", m_barrier21)
  end
  local function i_barrier3(args, menu)
    menu:addOption("Использовать/Убрать", m_barrier3)
  end
  local function i_barrier4(args, menu)
    menu:addOption("Использовать/Убрать", m_barrier4)
  end
  local function i_barrier5(args, menu)
    menu:addOption("Использовать/Убрать", m_barrier5)
  end
  local function i_bbq1(args, menu)
    menu:addOption("Использовать/Убрать", m_bbq1)
  end
  local function i_bbq2(args, menu)
    menu:addOption("Использовать/Убрать", m_bbq2)
  end
    local function i_lilo1(args, menu)
    menu:addOption("Использовать/Убрать", m_lilo1)
  end
    local function i_lilo2(args, menu)
    menu:addOption("Использовать/Убрать", m_lilo2)
  end
  local function i_ring(args, menu)
    menu:addOption("Использовать/Убрать", m_ring)
  end
    local function i_parasol1(args, menu)
    menu:addOption("Использовать/Убрать", m_parasol1)
  end
      local function i_ball1(args, menu)
    menu:addOption("Использовать/Убрать", m_ball1)
  end
      local function i_ball2(args, menu)
    menu:addOption("Использовать/Убрать", m_ball2)
  end
      local function i_ball3(args, menu)
    menu:addOption("Использовать/Убрать", m_ball3)
  end
  local function i_bong(args, menu)
    menu:addOption("Использовать/Убрать", m_bong)
  end
  local function i_pin(args, menu)
    menu:addOption("Использовать/Убрать", m_pin)
  end
    local function i_vedro(args, menu)
	menu:addOption("Использовать/Убрать", m_vedro)
  end
    local function i_burger(args, menu)
    menu:addOption("Использовать/Убрать", m_burger)
  end
    local function i_bench(args, menu)
    menu:addOption("Использовать/Убрать", m_bench)
  end
    local function i_chair2(args, menu)
    menu:addOption("Использовать/Убрать", m_chair2)
  end
    local function i_coffin(args, menu)
    menu:addOption("Использовать/Убрать", m_coffin)
  end
    local function i_dummy(args, menu)
    menu:addOption("Использовать/Убрать", m_dummy)
  end
    local function i_fireex(args, menu)
    menu:addOption("Использовать/Убрать", m_fireex)
  end
    local function i_flamingo(args, menu)
    menu:addOption("Использовать/Убрать", m_flamingo)
  end
    local function i_flat(args, menu)
    menu:addOption("Использовать/Убрать", m_flat)
  end
      local function i_gas(args, menu)
    menu:addOption("Использовать/Убрать", m_gas)
  end
      local function i_gnome1(args, menu)
    menu:addOption("Использовать/Убрать", m_gnome1)
  end
      local function i_gnome2(args, menu)
    menu:addOption("Использовать/Убрать", m_gnome2)
  end
      local function i_gnome3(args, menu)
    menu:addOption("Использовать/Убрать", m_gnome3)
  end
      local function i_target(args, menu)
    menu:addOption("Использовать/Убрать", m_target)
  end
      local function i_patio(args, menu)
    menu:addOption("Использовать/Убрать", m_patio)
  end
        local function i_parasol2(args, menu)
    menu:addOption("Использовать/Убрать", m_parasol2)
  end
        local function i_box(args, menu)
    menu:addOption("Использовать/Убрать", m_box)
  end
        local function i_stove(args, menu)
    menu:addOption("Использовать/Убрать", m_stove)
  end
        local function i_tent(args, menu)
    menu:addOption("Использовать/Убрать", m_tent)
  end
        local function i_ball4(args, menu)
    menu:addOption("Использовать/Убрать", m_ball4)
  end
        local function i_telescope(args, menu)
    menu:addOption("Использовать/Убрать", m_telescope)
  end
          local function i_corpse(args, menu)
    menu:addOption("Использовать/Убрать", m_corpse)
  end
          local function i_worklight3(args, menu)
    menu:addOption("Использовать/Убрать", m_worklight3)
  end
            local function i_plant1(args, menu)
    menu:addOption("Использовать/Убрать", m_plant1)
  end
             local function i_plant2(args, menu)
    menu:addOption("Использовать/Убрать", m_plant2)
  end
             local function i_plant3(args, menu)
    menu:addOption("Использовать/Убрать", m_plant3)
  end
             local function i_plant4(args, menu)
    menu:addOption("Использовать/Убрать", m_plant4)
  end
             local function i_plant5(args, menu)
    menu:addOption("Использовать/Убрать", m_plant5)
  end
             local function i_plant6(args, menu)
    menu:addOption("Использовать/Убрать", m_plant6)
  end
             local function i_plant7(args, menu)
    menu:addOption("Использовать/Убрать", m_plant7)
  end
             local function i_plant8(args, menu)
    menu:addOption("Использовать/Убрать", m_plant8)
  end
             local function i_plant9(args, menu)
    menu:addOption("Использовать/Убрать", m_plant9)
  end
             local function i_plant10(args, menu)
    menu:addOption("Использовать/Убрать", m_plant10)
  end

             local function i_plant12(args, menu)
    menu:addOption("Использовать/Убрать", m_plant12)
  end
              local function i_plant13(args, menu)
    menu:addOption("Использовать/Убрать", m_plant13)
  end

  

  vRP.EXT.Inventory:defineItem("scone", "Конус", "<div><img src='https://i.ibb.co/P6Fx7tT/image.png' alt ='image' /></div> ", i_scone, 0.3)
  vRP.EXT.Inventory:defineItem("bfire", "Набор для костра", "<div><img src='https://i.ibb.co/23JmSXz/image.png' alt ='image' /></div> ", i_fire, 0.5)
  vRP.EXT.Inventory:defineItem("chair", "Стул", "<div><img src='https://i.ibb.co/gygtFRj/image.png' alt ='image' /></div> ", i_chair, 0.3)
  vRP.EXT.Inventory:defineItem("barrier", "Барьер", "<div><img src='https://i.ibb.co/88Qdd9c/image.png' alt ='image' /></div> ", i_barrier, 1.0)
  vRP.EXT.Inventory:defineItem("worklight", "Прожектор(б)", "<div><img src='https://i.ibb.co/hfsbh8m/image.png' alt ='image' /></div> ", i_worklight, 1.0)
  vRP.EXT.Inventory:defineItem("gazebo", "Тент", "<div><img src='https://i.ibb.co/8xJ4xVc/image.png' alt ='image' /></div> ", i_gazebo, 2.0)
  vRP.EXT.Inventory:defineItem("bbox", "Бумбокс", "<div><img src='' alt ='image' /></div> ", i_bbox, 1.0)
  vRP.EXT.Inventory:defineItem("sign1", "Знак Не сёрфить", "<div><img src='' alt ='image' /></div> ", i_sign1, 1.0)
  vRP.EXT.Inventory:defineItem("sign2", "Знак Обрыв", "<div><img src='' alt ='image' /></div> ", i_sign2, 1.0)
 -- vRP.EXT.Inventory:defineItem("sign3", "Знак КПП", "<div><img src='' alt ='image' /></div> ", i_sign3, 1.0)
  vRP.EXT.Inventory:defineItem("barrier2", "Барьер большой", "<div><img src='https://i.ibb.co/RTBRfL4/image.png' alt ='image' /></div> ", i_barrier2, 5.0)
  vRP.EXT.Inventory:defineItem("barrier21", "Барьер большой стат", "<div><img src='https://i.ibb.co/RTBRfL4/image.png' alt ='image' /></div> ", i_barrier21, 25.0)
  vRP.EXT.Inventory:defineItem("barrier3", "Барьер мал.", "<div><img src='https://i.ibb.co/9wXNh1H/image.png' alt ='image' /></div> ", i_barrier3, 1.0)
  vRP.EXT.Inventory:defineItem("barrier4", "Барьер дорожн.раб.", "<div><img src='' alt ='image' /></div> ", i_barrier4, 2.0)
  vRP.EXT.Inventory:defineItem("barrier5", "Пластик.барьер", "<div><img src='https://i.ibb.co/Pm2MfnG/image.png' alt ='image' /></div> ", i_barrier5, 0.5)
  vRP.EXT.Inventory:defineItem("bbq1", "Гриль мал.", "<div><img src='https://i.ibb.co/3NV381v/image.png' alt ='image' /></div> ", i_bbq1, 2.0)
  vRP.EXT.Inventory:defineItem("bbq2", "Гриль большой", "<div><img src='https://i.ibb.co/fH8YgvY/image.png' alt ='image' /></div> ", i_bbq2, 7.0)
  vRP.EXT.Inventory:defineItem("lilo1", "Надувной матрац роз.", "<div><img src='https://i.ibb.co/4KTJrD9/image.png' alt ='image' /></div> ", i_lilo1, 0.2)
  vRP.EXT.Inventory:defineItem("lilo2", "Надувной матрац голуб.", "<div><img src='https://i.ibb.co/jGVdftK/image.png' alt ='image' /></div> ", i_lilo2, 0.2)
  vRP.EXT.Inventory:defineItem("ring", "Надувной круг", "<div><img src='https://i.ibb.co/12Gw5mw/image.png' alt ='image' /></div> ", i_ring, 0.2)
  vRP.EXT.Inventory:defineItem("parasol1", "Пляжный зонт", "<div><img src='https://i.ibb.co/yWw4VqS/image.png' alt ='image' /></div> ", i_parasol1, 2.0)
  vRP.EXT.Inventory:defineItem("ball1", "Мяч волейбольный", "<div><img src='https://i.ibb.co/6sTNzyy/image.png' alt ='image' /></div> ", i_ball1, 0.1)
  vRP.EXT.Inventory:defineItem("ball2", "Мяч волейбольный цвет.", "<div><img src='https://i.ibb.co/t4K9TtH/image.png' alt ='image' /></div> ", i_ball2, 0.1)
 -- vRP.EXT.Inventory:defineItem("ball3", "Мяч пляжный", "<div><img src='' alt ='image' /></div> ", i_ball3, 0.1)
  vRP.EXT.Inventory:defineItem("bong", "Бульбулятор", "<div><img src='https://i.ibb.co/82PvCY6/image.png' alt ='image' /></div> ", i_bong, 0.2)
  vRP.EXT.Inventory:defineItem("pin", "Кегля", "<div><img src='https://i.ibb.co/k04HTk9/image.png' alt ='image' /></div> ", i_pin, 0.2)
  vRP.EXT.Inventory:defineItem("vedro", "Ведерко", "<div><img src='https://i.ibb.co/Bq8KbHw/image.png' alt ='image' /></div> ", i_vedro, 0.3)
  vRP.EXT.Inventory:defineItem("burger", "Фастфуд", "<div><img src='' alt ='image' /></div> ", i_burger, 30.0)
  vRP.EXT.Inventory:defineItem("bench", "Барьер деревянный", "<div><img src='https://i.ibb.co/HVYzZb3/image.png' alt ='image' /></div> ", i_bench, 2.0)
  vRP.EXT.Inventory:defineItem("chair2", "Стул метал.", "<div><img src='https://i.ibb.co/KbW26DJ/image.png' alt ='image' /></div> ", i_chair2, 1.0)
  vRP.EXT.Inventory:defineItem("coffin", "Гроб", "<div><img src='https://i.ibb.co/BTg2RMB/image.png' alt ='image' /></div> ", i_coffin, 5.0)
  vRP.EXT.Inventory:defineItem("dummy", "Маникен", "<div><img src='https://i.ibb.co/cwdMFPx/image.png' alt ='image' /></div> ", i_dummy, 1.0)
  vRP.EXT.Inventory:defineItem("fireex", "Огнетушитель", "<div><img src='https://i.ibb.co/C0CSLzN/image.png' alt ='image' /></div> ", i_fireex, 2.0)
  vRP.EXT.Inventory:defineItem("flamingo", "Фламинго", "<div><img src='https://i.ibb.co/TrQY0jR/image.png' alt ='image' /></div> ", i_flamingo, 1.0)
  vRP.EXT.Inventory:defineItem("flat", "Строительная тележка", "<div><img src='https://i.ibb.co/Zf735fx/image.png' alt ='image' /></div> ", i_flat, 4.0)
  vRP.EXT.Inventory:defineItem("gas", "Баллон газа", "<div><img src='https://i.ibb.co/VxYKWRY/image.png' alt ='image' /></div> ", i_gas, 10.0)
  vRP.EXT.Inventory:defineItem("gnome1", "Гном 1", "<div><img src='https://i.ibb.co/mRshF7B/1.png' alt ='image' /></div> ", i_gnome1, 0.5)
  vRP.EXT.Inventory:defineItem("gnome2", "Гном 2", "<div><img src='https://i.ibb.co/BVGjRPQ/2.png' alt ='image' /></div> ", i_gnome2, 0.5)
  vRP.EXT.Inventory:defineItem("gnome3", "Гном 3", "<div><img src='https://i.ibb.co/JsGYKyh/3.png' alt ='image' /></div> ", i_gnome3, 0.5)
  vRP.EXT.Inventory:defineItem("target", "Мишень", "<div><img src='https://i.ibb.co/Ky6xDfp/image.png' alt ='image' /></div> ", i_target, 2.0)
  vRP.EXT.Inventory:defineItem("patio", "Шезлонг", "<div><img src='https://i.ibb.co/V2wPgHb/image.png' alt ='image' /></div> ", i_patio, 2.0)
  vRP.EXT.Inventory:defineItem("parasol2", "Парасоль", "<div><img src='https://i.ibb.co/VpbjdSK/image.png' alt ='image' /></div> ", i_parasol2, 7.0)
  vRP.EXT.Inventory:defineItem("box", "Коробка", "<div><img src='https://i.ibb.co/M7BpC5s/image.png' alt ='image' /></div> ", i_box, 0.5)
  vRP.EXT.Inventory:defineItem("stove", "Костер в бочке", "<div><img src='https://i.ibb.co/qM3tX69/image.png' alt ='image' /></div> ", i_stove, 2.0)
  vRP.EXT.Inventory:defineItem("tent", "Палатка", "<div><img src='https://i.ibb.co/dj0v1bv/image.png' alt ='image' /></div> ", i_tent, 4.0)
  vRP.EXT.Inventory:defineItem("ball4", "Шар большой", "<div><img src='https://i.ibb.co/W5dr858/image.png' alt ='image' /></div> ", i_ball4, 0.2)
  vRP.EXT.Inventory:defineItem("telescope", "Телескоп", "<div><img src='https://i.ibb.co/7Wnj41p/image.png' alt ='image' /></div> ", i_telescope, 3.0)
  vRP.EXT.Inventory:defineItem("corpse", "Маникен 2", "<div><img src='https://i.ibb.co/Hxsgxjc/2.png' alt ='image' /></div> ", i_corpse, 1.0)
  vRP.EXT.Inventory:defineItem("worklight3", "Прожектор средний", "<div><img src='https://i.ibb.co/pn1p8Cv/image.png' alt ='image' /></div> ", i_worklight3, 1.0)
  vRP.EXT.Inventory:defineItem("plant1", "Растение1", "<div><img src='https://i.ibb.co/RY7c53j/1.png' alt ='image' /></div> ", i_plant1, 1.0)
  vRP.EXT.Inventory:defineItem("plant2", "Растение2", "<div><img src='https://i.ibb.co/hshyzd2/2.png' alt ='image' /></div> ", i_plant2, 1.0)
  vRP.EXT.Inventory:defineItem("plant3", "Растение3", "<div><img src='https://i.ibb.co/ngHyyzs/3.png' alt ='image' /></div> ", i_plant3, 1.0)
  vRP.EXT.Inventory:defineItem("plant4", "Растение4", "<div><img src='https://i.ibb.co/hD9pKnZ/4.png' alt ='image' /></div> ", i_plant4, 1.0)
  vRP.EXT.Inventory:defineItem("plant5", "Растение5", "<div><img src='https://i.ibb.co/xsjTrfX/5.png' alt ='image' /></div> ", i_plant5, 1.0)
  vRP.EXT.Inventory:defineItem("plant6", "Растение6", "<div><img src='https://i.ibb.co/5Ff6WCN/6.png' alt ='image' /></div> ", i_plant6, 1.0)
  vRP.EXT.Inventory:defineItem("plant7", "Растение7", "<div><img src='https://i.ibb.co/tsrxyJB/7.png' alt ='image' /></div> ", i_plant7, 1.0)
  vRP.EXT.Inventory:defineItem("plant8", "Растение8", "<div><img src='https://i.ibb.co/Fx8tp7L/8.png' alt ='image' /></div> ", i_plant8, 1.0)
  vRP.EXT.Inventory:defineItem("plant9", "Растение9", "<div><img src='https://i.ibb.co/68tJs2Q/9.png' alt ='image' /></div> ", i_plant9, 1.0)
  vRP.EXT.Inventory:defineItem("plant10", "Растение10", "<div><img src='https://i.ibb.co/tDBzjcw/10.png' alt ='image' /></div> ", i_plant10, 1.0)
  vRP.EXT.Inventory:defineItem("plant12", "Растение12", "<div><img src='https://i.ibb.co/MgGyvr3/12.png' alt ='image' /></div> ", i_plant12, 1.0)
  vRP.EXT.Inventory:defineItem("plant13", "Растение13", "<div><img src='https://i.ibb.co/19S1SLy/13.png' alt ='image' /></div> ", i_plant13, 1.0)

 -- vRP.EXT.Inventory:defineItem("cleanveh", "Тряпка", "Можно что-нибудь помыть.<div><img src='' alt ='image' /></div> ", i_cleanveh, 0.5)
 -- vRP.EXT.Inventory:defineItem("engoil", "Присадка в двигатель", "Заведется???.<div><img src='' alt ='image' /></div> ", i_repaireng, 5.5)
--  vRP.EXT.Inventory:defineItem("", "", "<div><img src='' alt ='image' /></div> ", i_, 0.0)

 
  
  
  vRP.EXT.Inventory:defineItem("Noogle", "Акции Noogle", "<div><img src='https://i.ibb.co/4F3Ypfc/Noogle.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_noogle, 0.1)
  vRP.EXT.Inventory:defineItem("MacroSoft", "Акции MacroSoft", "<div><img src='https://i.ibb.co/bFfWfbr/Macro-Soft.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_MacroSoft, 0.1)
  vRP.EXT.Inventory:defineItem("YouCube", "Акции YouCube", "<div><img src='https://i.ibb.co/kH1pzq3/YouCube.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_YouCube, 0.1)
  vRP.EXT.Inventory:defineItem("LanFlix", "Акции LanFlix", "<div><img src='https://i.ibb.co/Vw0YrmN/LanFlix.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_LanFlix, 0.1)
  vRP.EXT.Inventory:defineItem("PonrBuh", "Акции PonrBuh", "<div><img src='https://i.ibb.co/r6djG6V/PonrBuh.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_PonrBuh, 0.1)
  vRP.EXT.Inventory:defineItem("Odnokyrsniki", "Акции Odnokyrsniki", "<div><img src='https://i.ibb.co/8cK5DT3/Odnokyrsniki.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_Odnokyrsniki, 0.1)
  vRP.EXT.Inventory:defineItem("Somy", "Акции Somy", "<div><img src='https://i.ibb.co/b2h588R/Somy.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_Somy, 0.1)
  vRP.EXT.Inventory:defineItem("FiveN", "Акции FiveN", "<div><img src='https://i.ibb.co/XbnvzxY/FiveN.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_FiveN, 0.1)
  vRP.EXT.Inventory:defineItem("AmazingAndCorp", "Акции AmazingAndCorp", "<div><img src='https://i.ibb.co/1KK4bHt/Amazing-And.png' alt ='image' /></div> От 0.5 до 1 процента в час.Одинаковые акции не стакаются.", i_buisness_AmazingAndCorp, 0.1)
 
end

function Props:__construct()
  vRP.Extension.__construct(self)

  -- items
  define_items(self)

end

Props.event = {}
Props.tunnel = {}

vRP:registerExtension(Props)


